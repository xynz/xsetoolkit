/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/*
**  <avl.h>
**
**  AVL tree library definitions
*/

#ifndef _AVL_H_
#define _AVL_H_

/* defines for ah_cmp */
#define AVC_NONE      ((int (*)(void *, void *)) 0)     /* none or string */
#define AVC_INT       ((int (*)(void *, void *)) 1)	/* int */

typedef enum {    /* flags for ah_debug */
    AVD_NUL=0,    /* No debug action */
    AVD_CHK=1,    /* Check tree after updates */
    AVD_DMP=2     /* Dump & check tree after updates */
} AvlDFlags;

typedef enum {    /* return values from avlinsert() */
    AVL_THERE=0,  /* Node already there */
    AVL_NOMEM=1,  /* No memory for node */
    AVL_INSERT=2  /* Node inserted */
} AvlInsVal;

typedef struct _avlhdr avlhdr;
typedef struct _anode anode;

struct _avlhdr {             /* Header structure */
    anode    *ah_top;        /* Ptr to top node */
    int     (*ah_cmp)(void *, void *);       /* Ptr to comparison function   */
    void    (*ah_delete)(avlhdr *, anode *); /* Ptr to optional del function */
    int     (*ah_print)(anode *, int, void *);  /* Ptr to optional printer   */
    char     *ah_user;       /* For use by the user */
    AvlDFlags ah_debug;      /* Debug flag */
};

struct _anode {          /* Internal node */
    anode *an_left;      /* Pointer to left subtree */
    anode *an_right;     /* Pointer to right subtree */
    anode *an_up;        /* Pointer to parent */
    char   an_balance;   /* Balance factor */
    char   an_flags[sizeof(long) - sizeof(char)];  /* User data */
    void  *an_tag;       /* Pointer to tag string */
    void  *an_data;      /* Pointer to data string */
};

#define an_next an_left         /* For free list */

extern anode     *avlget(avlhdr *ahp, void *tag);
extern AvlInsVal  avlinsert (avlhdr *ahp, void *tag, void *data, anode **anpp);
extern void       avldelete (avlhdr *ahp, anode *anp);
extern void       avlfree   (avlhdr *ahp);
extern int        avldepth  (avlhdr *ahp,
                            int (*func)(anode *anp, int depth, void *param),
                            void *param);
extern int        avlbrdth  (avlhdr *ahp,
                            int (*func)(anode *anp, int depth, void *param),
                            void *param);
extern int        avlcheck  (avlhdr *ahp, anode *anp, anode *parent);
extern avlhdr    *avlinit   (void);
extern anode     *avlfirst  (avlhdr *ahp);
extern anode     *avlnext   (avlhdr *ahp, anode *anp, int delete_it);
extern anode     *avlprev   (avlhdr *ahp, anode *anp, int delete_it);
extern anode     *avllast   (avlhdr *ahp);

#endif /* _AVL_H_ */
