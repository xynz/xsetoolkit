================
 SE Toolkit FAQ
================

FAQ: Last update: 9/26/01

-------------------------------------

Q: What is the SE Toolkit?

A: <a href="http://www.setoolkit.com/aboutse.html>
    http://www.setoolkit.com/aboutse.html </a>

-------------------------------------

Q: I downloaded this RICHPse.tar.gz file. Now what do I do with it?

A: As root, do this:

::

  # gunzip RICHPse.tar.gz
  # tar xf RICHPse.tar
  # pkgadd -d . RICHPse

This much will get the SE Toolkit installed in /opt/RICHPse. Now, to
run the scripts, do this (assuming you're using ksh).

::

  # export PATH=$PATH:/opt/RICHPse/bin
  # export SEPATH=/opt/RICHPse/examples:/opt/RICHPse/toptool
  # se disks.se

disks.se isn't very interesting. I'll assume you're using some kind
of graphical user interface. Do this:

::

  # se zoom.se

or

::

  # se toptool.se

The examples are in /opt/RICHPse/examples. There are specific applications
in the toptool and perfmon directories.

Note: you don't have to be root to run SE, just to install it.

-------------------------------------

Q: SE doesn't see my network interface. Is there a way to add it on the fly?

A: 1) Run dumpkstats.se and find the paragraph that describes the interface.
      Let's say it's the xyz card, you'd see a "xyz.0.xyz0" paragraph.

   2) Graft the paragraph into the kstat.se file with the same syntax as the
      other NIC structures.  Something like:

::

   kstat struct "xyz:" ks_xyz_network {
       int    number$;       /* linear interface number */
       string name$;         /* name of the interface   */

       // graft the dumpkstats paragraph here
   };

   3) Make sure the syntax in kstat.se is correct.  If the structure has any
      members like "number of input bytes" make sure you declare it as

      ulong_t "number of input bytes";

      See the users manual for more info on this.

   4) Edit netif.se and make the same type of changes that you see for all the
      other interface types.

   5) Run net.se and see if the new interface shows up.

-------------------------------------

Q: I am having problems with colours. When I run zoom.se I get:

::

   gui_get_pixel: Cannot find color: orange
   gui_get_pixel: Cannot find color: yellow2
   gui_get_pixel: Cannot find color: light blue
   gui_get_pixel: Cannot find color: midnight blue
   gui_get_pixel: Cannot find color: dark olive green
   gui_get_pixel: Cannot find color: pale goldenrod
   gui_get_pixel: Cannot find color: navy

A: This is a very basic failure of the color allocation functions in the X lib.
   The number of colors available simultaneously is a function of the depth of
   the frame buffer. By default, Sun workstations have an 8 bit frame buffer.
   What this means to X applications is that the default color map has 2^8
   colors at its disposal. This is 256. Not very many for a modern window
   system.

By increasing the depth of the frame buffer to 24, you increase the number of
colors available to 2^24 or 16,777,216. This is more like it.  Newer Sun
workstations are capable of this. Here's how to proceed.

::

   # cd /usr/sbin
   # ls *config

among the files found on my Ultra 5 was "m64config". This is an application
that allows you to configure the hardware parameters of the frame buffer.
Running "m64config -?" yields:

::

   m64config: Option -? is ambigous.  Possible values are: 

   Usage:

           m64config [-dev devname] [-file machine | system ]
                     [-res video-mode [now] [noconfirm] [nocheck] [try]]
                     [-depth 8|24]
                     [-defaults] 
                     [-propt] [-prconf] [-help]

So, as root if I run "m64config -depth 24", I've configured the frame buffer
to 24 bits.  It's probably a good idea to specify the "-res" parameter as
well.  I've got my machine configured to 1152x900x76 at 24 bits per pixel.
The 76 means the vertical refresh rate is set to 76 Hertz. The performance of
the parts on the frame buffer will limit the refresh rate depending on the
horizontal x vertical resolution. So even if the frame buffer has enough
memory to display 1280x1024 at 24 bits, it may not have the horsepower (or
there may be some other physical constraint that prevents the card from
performing this function) to do it at 80 Hz. m64config will let you know if
you're trying to make the frame buffer do something that it cannot.

Once this is done, restart the window system.  Run xdpyinfo and see if the
default depth of the root window is 24 planes. If not, do this:

::

   # cp /usr/dt/config/Xservers /etc/dt/config
   # cd /etc/dt/config
   # vi Xservers

modify the last line, which invokes the X server, to include at the end of
the line "-dev /dev/fb defdepth 24". This will instruct the Xserver to
come up in 24 bit mode.  See "man Xsun" if this confuses you.

You will need to restart the dtlogin stuff like this:

::

   # cd /etc/init.d
   # ./dtlogin stop
   # ./dtlogin start ; exit

At this point, you really should be in 24 bit mode. Run xdpyinfo to make
sure. Once this is accomplished, a lot of stuff will work better. Like
netscape will work with dtmail without gutting half of the colors.

If you're not using CDE there are many different ways to proceed. You'll
need to figure that out on your own.

-------------------------------------

Q: All my disk volumes are Veritas volumes. Why can't SE see them?

A: Veritas volumes will be invisible to applications until Vertias gets a
   clue and puts the disk stats in the kstat chain like everyone else.
   I guess there's noone working at Veritas with enough engineering
   ability to get that done.

-------------------------------------

Q: When I run zoom.se I get these errors. What am I doing wrong?

::

   "/opt/RICHPse/include/live_rules.se", line 67: Can't find include file inst_to_path.se
   "/opt/RICHPse/include/live_rules.se", line 392: error: assignment type mismatch
   "/opt/RICHPse/examples/zoom.se", line 757: error: invalid member name: pr_sname
   "/opt/RICHPse/examples/zoom.se", line 757: error: operands have incompatible types: op "=="
   "/opt/RICHPse/examples/zoom.se", line 758: error: invalid member name: pr_sname
   "/opt/RICHPse/examples/zoom.se", line 758: error: assignment type mismatch
   "/opt/RICHPse/examples/zoom.se", line 765: error: invalid member name: pr_ttyname
   "/opt/RICHPse/examples/zoom.se", line 765: error: argument type mismatch: arg #5: fprintf
   "/opt/RICHPse/examples/zoom.se", line 1488: fatal: Errors detected.
   Exiting.

A: You have a package mismatch. Since SE 3.2, what used to be many packages
   is now only one. You need to delete all the old packages and reinstall
   SE 3.2 or newer.

::

   # pkgrm RICHPtt ANCrules RICHPsex RICHPse
   # /bin/rm -fr /opt/RICHPse
   # pkgadd -d . RICHPse

-------------------------------------

Q: When I run zoom.se I get this ld.so.1 error. What's happening?

::

   "/opt/RICHPse/include/gui_lib.se", line 91: error: dlopen(/opt/RICHPse/lib/sparcv9/libsegui.so): ld.so.1: /opt/RICHPse/bin/se.sparcv9.5.7: fatal: gui_create_frame: can't find symbol
   "/opt/RICHPse/examples/zoom.se", line 1615: fatal: Errors detected.  Exiting.

A: Sun bugid 4369472 states "Patch 108376-12 installs 32bit ELF libX11.so.4
   in lib/sparcv9 breaks 64bit apps". Patch 106541-15 fixes this problem
   by installing patch 108376-21 which restores the 64-bit libX11.so.4.

-------------------------------------

Q: I just installed SE 3.2 and the scripts don't start at boot. Why?

A: SE 3.2 no longer installs the init files in /etc/init.d. If you'd
   like to have scripts start at boot, go to /opt/RICHPse/etc copy the
   init files of your liking to the appropriate places in /etc. For
   instance, if you want mon_cm.se to start at boot, do this:

::

   # cd /opt/RICHPse/etc
   # tar cf - */*mon_cm | (cd /etc ; tar xvf -)

-------------------------------------

Q: When I run zoom.se, I get this subscript error. How do I fix this?

::

   Fatal: subscript: 1 out of range for: GLOBAL_net[1]: Near line 178

A: Edit /opt/RICHPse/etc/se_defines and add this line

   force MAX_IF 2

   and keep increasing the value until you don't get the error anymore.

-------------------------------------

Q: When I run some of the scripts, I get this permission problem. Help!

::

   Fatal: cannot open /dev/ip

or

::

   Warning: cannot open /dev/ip

A: From the README.RELEASE file:

   Many changes have occurred in Solaris over the years and it's made
   quite a puzzle for SE. The most problematic are the permissions of
   the network pseudo-devices in /dev. The permissions change, how they
   work changes, etc. By default, the SE binaries will be installed with
   a group id of sys. When you run the applications, you'll see that some
   things don't work. Reading mib variables, especially. The simple fix to
   this is:

::

	   # cd /opt/RICHPse/bin
	   # chgrp sys se.*.5.*
	   # chmod g+s se.*.5.*

   This will make the binaries setegid sys. It will allow reading of any
   file that has the read bit set and whose group ownership is sys.

   THIS MUST BE THE DECISION OF THE SYSADMIN. IF YOU DON'T WANT PROGRAMS
   HANGING AROUND YOUR SYSTEM THAT ARE SETEGID SYS, DON'T DO THIS!

   The effect of not doing this is that mib variables will not be readable.
   There is no other good work-around. If you look at /bin/netstat, you'll
   see that it's setegid sys. That's how it does it, that's how the SE
   binaries must do it.

-------------------------------------

Q: When I run some of the scripts, I get this permission problem. Help!

::

   Warning: Cannot init kvm: Permission denied

A: It's the same answer as the previous question.

-------------------------------------

Q: I want to monitor my nfs mounts with the disk tools. Can I do that?

A: Edit /opt/RICHPse/etc/se_defines and add the line

::

   disk nfs

This will add the nfs "disks" to the list of monitored disks.

-------------------------------------

Q: How do I add a new ndd structure on the fly?

A: Let's say you have a new xyz interface. Do this as root:

::

  # ndd /dev/xyz
  name to get/set? ?
  foo		(read only)
  bar		(read only)
  ...
  name to get/set? ^D

So, when asked for a name respond with "?" and a list of variables will
be shown. Most of these variables are type "int". If you're unsure,
enter the variable name and ndd will print it out. If it's a string,
it'll be pretty obvious.

Cut and paste this list of variables into another file. Now, edit the
ndd.se include file. Add a new structure at the end of the file like
this:

::

  ndd struct "/dev/xyz" ndd_xyz_t {

and then add the variables that you pasted into the other file. Don't
forget to add the ending

::
 
  };

Make sure you edit all of the variables in the new structure to be
syntactically correct. And don't add the ? line, it's not really a
variable. Here's what it looks like adding /dev/arp (don't do this,
it's already there).

::

  # ndd /dev/arp
  name to get/set? ?
  ?                             (read only)
  arp_cache_report              (read only)
  arp_debug                     (read and write)
  arp_cleanup_interval          (read and write)

[ I'm unsure as to what arp_cache_report is, it looks like it may be
a string. I'll check it out ]

::

  name to get/set ? arp_cache_report  
  value ? 
  length ? 
  ifname   proto addr      proto mask      hardware addr     flags
  hme0     224.000.000.000 240.000.000.000 01:00:5e:00:00:00 PERM MAPPING
  hme0     blah blah blah

[ Note: I just hit return for the value ? and length ? questions. Yes,
it's a string. Now I can move on. ]

Now I edit /opt/RICHPse/include/ndd.se and add this structure:

::

  ndd struct "/dev/arp" ndd_arp_t {
    string arp_cache_report;
    int    arp_debug;
    int    arp_cleanup_interval;
  };

DON'T FORGET to send me any additions that you make so I can integrate it
back into the base.

-------------------------------------

Q: When I run zoom.se I get these font errors. What is this?

::

  Warning: Cannot convert string "-dt-interfacesystem-medium-r-normal-l*-*-*-*-*-*-*-*-*" to type FontSet
  Warning: Unable to load any usable fontset
  Warning:
      Name: FONTLIST_DEFAULT_TAG_STRING
      Class: XmRendition
      Conversion failed.  Cannot load font.

A: Before logging into CDE, choose Options->Language->C instead of the
   en_US.UTF-8 locale. If you're not using CDE, do whatever it takes
   to get out of the U.S. Unicode character set.
