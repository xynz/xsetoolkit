/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <string.h>
#include "avl.h"
#include "se.h"

void
se_refresh_extern_variable(T_VARIABLE *vp)
{
  int i;
  int size;
  void *array;
  T_VARIABLE var;
  caddr_t address;

  if (vp->var_subscript) {
    /* subscripted array */
    i = se_compute_subscript(vp, 1);
    array = vp->var_un.var_array;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      ((unsigned char *) array)[i] = ((unsigned char *) vp->var_address)[i];
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      ((unsigned short *) array)[i] = ((unsigned short *) vp->var_address)[i];
      break;
    case VAR_LONG:
    case VAR_ULONG:
      ((unsigned int *) array)[i] = ((unsigned int *) vp->var_address)[i];
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ((T_ULLONG *) array)[i] = ((T_ULLONG *) vp->var_address)[i];
      break;
    case VAR_DOUBLE:
      ((double *) array)[i] = ((double *) vp->var_address)[i];
      break;
    case VAR_STRING:
      se_new_string(((char **) array) + i, ((char **) vp->var_address)[i]);
      break;
    case VAR_USER:
      var = *vp;
      var.var_subscript = 0;
      var.var_dimension = 0;
      var.var_un.var_user = ((T_STRUCT **) vp->var_un.var_array)[i];
      address = vp->var_address + (vp->var_struct->st_size * i);
      se_area_into_struct((uchar_t *) address, &var);
      break;
    }
  } else if (vp->var_dimension) {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      size = sizeof(char);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      size = sizeof(short);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      size = sizeof(int);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      size = sizeof(T_LLONG);
      break;
    case VAR_DOUBLE:
      size = sizeof(double);
      break;
    case VAR_STRING:
      size = sizeof(char *);
      break;
    case VAR_USER:
      se_area_into_struct((uchar_t *) vp->var_address, vp);
      size = 0;
      break;
    }
    if (vp->var_type == VAR_STRING) {
      array = vp->var_un.var_array;
      for(i=0; i<vp->var_dimension; i++)
        se_new_string(((char **) array) + i, ((char **) vp->var_address)[i]);
    } else if (size)
      memcpy(vp->var_un.var_array, vp->var_address, size * vp->var_dimension);
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      vp->var_un.var_udigit = *((unsigned char *) vp->var_address);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      vp->var_un.var_udigit = *((unsigned short *) vp->var_address);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit = *((unsigned int *) vp->var_address);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = *((T_ULLONG *) vp->var_address);
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = *((double *) vp->var_address);
      break;
    case VAR_STRING:
      se_new_string(&vp->var_un.var_string, *((char **) vp->var_address));
      break;
    case VAR_USER:
      se_area_into_struct(*((uchar_t **) vp->var_address), vp);
      break;
    }
  }
}

void
se_update_extern_variable(T_VARIABLE *vp)
{
  char *p;
  int i;
  int size;
  void *array;
  T_VARIABLE var;
  caddr_t address;

  if (vp->var_subscript) {
    /* subscripted array */
    i = se_compute_subscript(vp, 1);
    array = vp->var_un.var_array;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      ((unsigned char *) vp->var_address)[i] = ((unsigned char *) array)[i];
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      ((unsigned short *) vp->var_address)[i] = ((unsigned short *) array)[i];
      break;
    case VAR_LONG:
    case VAR_ULONG:
      ((unsigned int *) vp->var_address)[i] = ((unsigned int *) array)[i];
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ((T_ULLONG *) vp->var_address)[i] = ((T_ULLONG *) array)[i];
      break;
    case VAR_DOUBLE:
      ((double *) vp->var_address)[i] = ((double *) array)[i];
      break;
    case VAR_STRING:
      p = ((char **) vp->var_address)[i];
      if (p)
        strncpy(p, ((char **) array)[i], strlen(p));
      break;
    case VAR_USER:
      /* mustn't send unresolved variables to the struct/area functions */
      var = *vp;
      var.var_subscript = 0;
      var.var_dimension = 0;
      var.var_un.var_user = ((T_STRUCT **) vp->var_un.var_array)[i];
      array = se_struct_into_area(&var, 0);
      address = vp->var_address + (vp->var_struct->st_size * i);
      memcpy(address, array, vp->var_struct->st_size);
      se_free(array);
      break;
    }
  } else if (vp->var_dimension) {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      size = sizeof(char);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      size = sizeof(short);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      size = sizeof(int);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      size = sizeof(T_LLONG);
      break;
    case VAR_DOUBLE:
      size = sizeof(double);
      break;
    case VAR_STRING:
      size = sizeof(char *);
      break;
    case VAR_USER:
      array = se_struct_into_area(vp, 0);
      size = vp->var_struct->st_size;
      memcpy(vp->var_address, array, size * vp->var_dimension);
      se_free(array);
      size = 0;
      break;
    }
    if (vp->var_type == VAR_STRING) {
      array = vp->var_un.var_array;
      for(i=0; i<vp->var_dimension; i++) {
        p = ((char **) vp->var_address)[i];
        if (p)
          strncpy(p, ((char **) array)[i], strlen(p));
      }
    } else if (size)
      memcpy(vp->var_address, vp->var_un.var_array, size * vp->var_dimension);
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      *((unsigned char *) vp->var_address) = vp->var_un.var_udigit;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      *((unsigned short *) vp->var_address) = vp->var_un.var_udigit;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      *((unsigned int *) vp->var_address) = vp->var_un.var_udigit;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      *((T_ULLONG *) vp->var_address) = vp->var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      *((double *) vp->var_address) = vp->var_un.var_rdigit;
      break;
    case VAR_STRING:
      p = *((char **) vp->var_address);
      if (p)
        strncpy(p, vp->var_un.var_string, strlen(p));
      break;
    case VAR_USER:
      array = se_struct_into_area(vp, 0);
      memcpy(*((void **) vp->var_address), array, vp->var_struct->st_size);
      se_free(array);
      break;
    }
  }
}
