/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stdarg.h>
#include "avl.h"
#include "se.h"

char *
se_string_saven(char *s, size_t n)
{
  char *p;

  if (s == 0)
    return 0;
  p = (char *) se_alloc(n + 1);
  memcpy(p, s, n);
  p[n] = '\0';
  return p;
}

char *
se_string_save(char *s)
{
  if (s == 0)
    return 0;
  return se_string_saven(s, strlen(s));
}

#undef se_new_string

/* safe string replacer so I don't se_string_save free'ed memory */
void
se_new_string(char **old, char *newer)
{
  char *p = se_string_save(newer);

  if (*old)
    se_free(*old);
  *old = p;
}

#undef _se_new_stringn

void
se_new_stringn(char **old, char *newer, size_t n)
{
  char *p = se_string_saven(newer, n);

  if (*old)
    se_free(*old);
  *old = p;
}

#ifdef _NS_DEBUG
void
_se_new_string(char *file, int line, char **old, char *new)
{
  printf("NEW_STRING: File: %s  Line: %d\n", file, line);
  se_new_string(old, new);
}
void
_se_new_stringn(char *file, int line, char **old, char *new, size_t n)
{
  printf("NEW_STRING: File: %s  Line: %d\n", file, line);
  se_new_stringn(old, new, n);
}
#endif

void
yyerror(char *s, ...)
{
  char buf[BUFSIZ];
  char *t = "error";
  char *file_name;
  int unknown = 0;
  T_SE_ERROR code;
  va_list args;

  va_start(args, s);
  code = va_arg(args, T_SE_ERROR);

  /* yacc code */
  if (strcmp(s, "syntax error") == 0)
    code = ERR_NONFATAL;
  switch (code) {
  case ERR_LATER:
  case ERR_FATAL:
    t = "fatal";
    Se_errors++;
    break;
  case ERR_WARNING:
    if (Se_flags & SE_WARNING)
      return;
    t = "warning";
    break;
  case ERR_NONFATAL:
    Se_errors++;
    break;
  default:
    Se_errors++;
    unknown = 1;
    break;
  }

  if (Lex_currentFile[0])
    file_name = Lex_currentFile;
  else
    file_name = "stdin";

  fprintf(stderr, "\"%s\", line %d: ", file_name, Lex_line_no);
  fprintf(stderr, "%s: %s", t, s);
  if (unknown)
    fprintf(stderr, " before or at: %s\n", Lex_currtok);
  else
    putc('\n', stderr);

  switch (code) {
  case ERR_FATAL:
  case ERR_LATER:
    if (Lex_input) {
      while(read(fileno(Lex_input), buf, sizeof buf) > 0)
        ;
      if (Lex_input != stdin)
        pclose(Lex_input);
    }
    if (code == ERR_FATAL)
      fprintf(stderr, "%s: cannot recover: exiting\n", Se_programName);
    exit(1);
  }
}

#ifdef _FREE_CHECK
static avlhdr *mem_tree;

#define FC_MALLOC      ((void *) 1)
#define FC_FREE        ((void *) 2)

static void init_mem_tree(void)
{
  if (mem_tree == 0) {
    mem_tree = avlinit();
    if (mem_tree == 0)
      yyerror("Out of memory", ERR_FATAL);
    mem_tree->ah_cmp = AVC_INT;
  }
}
#endif

#ifdef _MEM_DEBUG
static int debugging = 0;
static int alloced = 0;
static int freed = 0;

#define ALLOCED 1
#define FREED   2

static int last_op;

void
se_mem_debug(int on_off)
{
  debugging = on_off;
}
#endif

#undef se_alloc
#undef se_free

void *
se_alloc(int n)
{
  void *p = malloc(n);

  if (p == 0)
    yyerror("Out of memory", ERR_FATAL);
#ifdef _MEM_DEBUG
  if (debugging) {
    printf("0x%x allocated - %d\n", p, ++alloced - freed);
    if (last_op == ALLOCED) {
      char ans[16];

      if ((debugging != -1) && ((alloced - freed) >= debugging)) {
        printf("two allocs, continue? ");
        gets(ans);
        if (ans[0] == 'n')
          abort();
      } else
        puts("<----------------------------> MULTIPLE ALLOCS");
    }
    last_op = ALLOCED;
  }
#endif
#ifdef _FREE_CHECK
  {
    anode *anp;

    init_mem_tree();
    switch(avlinsert(mem_tree, p, FC_MALLOC, &anp)) {
    case AVL_THERE:
      if (anp->an_data != FC_FREE)
        printf("0x%x already malloc'ed\n", p);
      anp->an_tag = p;
      anp->an_data = FC_MALLOC;
      break;
    case AVL_INSERT:
      break;
    case AVL_NOMEM:
      yyerror("free_check: alloc: out of memory", ERR_FATAL);
      break;
    }
  }
#endif
  memset(p, '\0', n);
  return p;
}

void
se_free(void *p)
{
  if (p == 0)
    return;
#ifdef _MEM_DEBUG
  if (debugging) {
    printf("0x%x freed - %d\n", p, alloced - ++freed);
    if (last_op == FREED)
      puts("<----------------------------> MULTIPLE FREES");
    last_op = FREED;
  }
#endif
#ifdef _FREE_CHECK
  {
    anode *anp;

    init_mem_tree();
    switch(avlinsert(mem_tree, p, 0, &anp)) {
    case AVL_INSERT:
      printf("free unallocated: 0x%x\n", p);
      break;
    case AVL_THERE:
      if (anp->an_data != FC_MALLOC)
        printf("free already free: 0x%x\n", p);
      anp->an_tag = p;
      anp->an_data = FC_FREE;
      break;
    case AVL_NOMEM:
      yyerror("free_check: free: out of memory", ERR_FATAL);
      break;
    }
  }
#endif
  free(p);
}

#ifdef _ALLOC_DEBUG
void *
_se_alloc(char *file, int line, int n)
{
  printf("ALLOC: File: %s  Line: %d\n", file, line);
  return se_alloc(n);
}
#endif

#ifdef _FREE_DEBUG
void
_se_free(char *file, int line, void *p)
{
  printf("FREE: File: %s  Line: %d\n", file, line);
  se_free(p);
}
#endif

#ifdef _MALLOC_METER

#include <dlfcn.h>

static void *my_handle = 0;
static void *(*malloc_fn)(size_t);
static void (*free_fn)(void *);
static int balance_of_power = 0;
static int print_base = 0;

static void
mm_init(void)
{
  char error_buf[256];
  char *p;

#ifdef _LP64
  my_handle = dlopen("/usr/lib/64/libc.so", RTLD_LAZY);
#else
  my_handle = dlopen("/usr/lib/libc.so", RTLD_LAZY);
#endif
  if (my_handle == 0) {
    snprintf(error_buf, sizeof error_buf, "dlopen(libc): %s", dlerror());
    yyerror(error_buf, ERR_FATAL);
  }
  malloc_fn = (void *(*)(size_t)) dlsym(my_handle, "malloc");
  free_fn   = (void  (*)(void *)) dlsym(my_handle, "free");
  if (malloc_fn == 0) {
    snprintf(error_buf, sizeof error_buf, "dlsym(malloc): %s", dlerror());
    yyerror(error_buf, ERR_FATAL);
  }
  if (free_fn == 0) {
    snprintf(error_buf, sizeof error_buf, "dlsym(free): %s", dlerror());
    yyerror(error_buf, ERR_FATAL);
  }
  p = getenv("PRINT_BASE");
  if (p)
    print_base = atoi(p);
}

void *
malloc(size_t n)
{
  if (my_handle == 0)
    mm_init();
  balance_of_power++;
  if (balance_of_power > print_base)
    fprintf(stderr, "parity: %10d\r", balance_of_power);
  fflush(stderr);
  return (*malloc_fn)(n);
}

void
free(void *p)
{
  if (my_handle == 0)
    yyerror("free() without malloc() ever being called", ERR_FATAL);
  balance_of_power--;
  if (balance_of_power > print_base)
    fprintf(stderr, "parity: %10d\r", balance_of_power);
  fflush(stderr);
  (*free_fn)(p);
}

#endif
