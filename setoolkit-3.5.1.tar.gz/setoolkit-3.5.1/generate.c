/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <stdarg.h>
#include <string.h>
#include "avl.h"
#include "se.h"

static char *clean_string(char *);
static char *clean_char(int);
static void  dump_struct(T_STRUCT *);
static int   dump_variable(T_VARIABLE *);
static void  dump_variable_declaration(T_VARIABLE *);
static void  dump_block(T_BLOCK *);
static void  dump_expression(T_EXPR *);
static void  dump_aggregate(T_VARIABLE *);
static void  dump_aggregate_member(T_VARIABLE *);
static void  dump_value(T_VARIABLE *);
static void  dump_call(T_FCALL *);
static void  dump_statement_list(T_STATEMENT *, int);
static void  dump_statement(T_STATEMENT *, int);
static void  dump_lexpression(T_LEXPR *);
static void  dump(char *format, ...);

static void  dump_block_deps(T_BLOCK *);
static void  dump_statement_deps(T_STATEMENT *);
static void  dump_expression_deps(T_EXPR *);
static void  dump_lexpression_deps(T_LEXPR *);
static void  dump_variable_deps(T_VARIABLE *);

static int   lib_finder(anode *, int, void *);
static int   node_dumper(anode *, int, void *);
static int   attach_dumper(anode *, int, void *);
static int   lib_dumper(anode *, int, void *);
static int   struct_dumper(anode *, int, void *);

static char *map_type_name(T_VARIABLE *);

static FILE *code_fp;

void
se_generate(char *output_file)
{
  avlhdr *lib_tree;

  if (strcmp(output_file, "-") == 0)
    code_fp = stdout;
  else
    code_fp    = fopen(output_file, "w");
  if (code_fp == 0)
    yyerror("cannot open output file", ERR_FATAL);
  lib_tree = avlinit();
  if (lib_tree == 0)
    yyerror("cannot grow lib_tree", ERR_FATAL);

  avldepth(Se_symbol_table, lib_finder, lib_tree);
  avldepth(lib_tree, lib_dumper, (void *) 0); /* find structs */
  avldepth(lib_tree, lib_dumper, (void *) 1); /* dump funcs   */
  avlfree(lib_tree);
  avldepth(Se_symbol_table, node_dumper, (void *) SYM_STRUCT);
  avldepth(Se_symbol_table, node_dumper, (void *) SYM_VARIABLE);
  avldepth(Se_symbol_table, node_dumper, (void *) SYM_BLOCK);

  fclose(code_fp);
}

static int
struct_dumper(anode *anp, int depth, void *param)
{
  int n;
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_BLOCK *bp;
  T_VARIABLE *vp;
  anode *ap = (anode *) param;
  char *lib_name = (char *) ap->an_tag;

  switch(sp->sym_type) {
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if ((bp->b_attachment == 0) || ((bp->b_flags & B_REFERENCED) == 0))
      return 0;
    if (strcmp(lib_name, bp->b_attach_lib))
      return 0;
    if (bp->b_return && (bp->b_return->var_type == VAR_USER))
      dump_struct(bp->b_return->var_struct);
    for(vp=bp->b_parameters; vp; vp=vp->var_next)
      if (vp->var_type == VAR_USER)
        dump_struct(vp->var_struct);
    return 0;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    n = vp->var_flags & (VF_EXTERN|VF_REFERENCED);
    if (n != (VF_EXTERN|VF_REFERENCED))
      return 0;
    if (strcmp(lib_name, vp->var_attach_lib))
      return 0;
    if (vp->var_type == VAR_USER)
      dump_struct(vp->var_struct);
    return 0;
  default:
    return 0;
  }
}

static int
attach_dumper(anode *anp, int depth, void *param)
{
  int n;
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_BLOCK *bp;
  T_VARIABLE *vp;
  anode *ap = (anode *) param;
  char *lib_name = (char *) ap->an_tag;

  switch(sp->sym_type) {
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if ((bp->b_attachment == 0) || ((bp->b_flags & B_REFERENCED) == 0))
      return 0;
    if (strcmp(lib_name, bp->b_attach_lib))
      return 0;
    if (ap->an_flags[0] == 0) {
      dump("attach \"%s\" {\n", lib_name);
      ap->an_flags[0] = 1;
    }
    if (bp->b_return)
      dump("%s ", map_type_name(bp->b_return));
    dump("%s(", bp->b_name);
    for(vp=bp->b_parameters; vp; vp=vp->var_next) {
      dump_variable(vp);
      if (vp->var_next)
        dump(", ");
    }
    dump(");\n");
    return 0;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    n = vp->var_flags & (VF_EXTERN|VF_REFERENCED);
    if (n != (VF_EXTERN|VF_REFERENCED))
      return 0;
    if (strcmp(lib_name, vp->var_attach_lib))
      return 0;
    if (ap->an_flags[0] == 0) {
      dump("attach \"%s\" {\n", lib_name);
      ap->an_flags[0] = 1;
    }
    dump("extern ");
    dump_variable_declaration(vp);
    return 0;
  default:
    return 0;
  }
}

static int
lib_dumper(anode *anp, int depth, void *param)
{
  if (param) {
    avldepth(Se_symbol_table, attach_dumper, anp);
    dump("};\n");
  } else
    avldepth(Se_symbol_table, struct_dumper, anp);
  return 0;
}

static int
lib_finder(anode *anp, int depth, void *param)
{
  char *attach_lib;
  int n;
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_BLOCK *bp;
  T_VARIABLE *vp;
  avlhdr *tree = (avlhdr *) param;
  anode *ap;

  switch(sp->sym_type) {
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if ((bp->b_attachment == 0) || ((bp->b_flags & B_REFERENCED) == 0))
      return 0;
    attach_lib = bp->b_attach_lib;
    break;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    n = vp->var_flags & (VF_EXTERN|VF_REFERENCED);
    if (n != (VF_EXTERN|VF_REFERENCED))
      return 0;
    attach_lib = vp->var_attach_lib;
    break;
  default:
    return 0;
  }
  if (avlinsert(tree, attach_lib, 0, &ap) == AVL_NOMEM)
    yyerror("out of lib_tree node memory", ERR_FATAL);
  ap->an_flags[0] = 0;
  return 0;
}

static int
node_dumper(anode *anp, int depth, void *param)
{
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_SYMTYPE arg = (T_SYMTYPE) param;
  T_STRUCT *ssp;
  T_VARIABLE *vp;
  T_BLOCK *bp;

  switch(sp->sym_type | arg) {
  case SYM_STRUCT:
    ssp = sp->sym_un.sym_struct;
    if (ssp && (ssp->st_flags & SF_REFERENCED))
      dump_struct(ssp);
    break;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    if (vp && (vp->var_flags & VF_REFERENCED)) {
      dump_variable_declaration(vp);
      if (vp->var_flags & VF_PRAGMA_REF)
        dump("pragma referenced %s;\n", vp->var_name);
    }
    break;
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if (bp && (bp->b_attachment == 0))
      dump_block(bp);
    break;
  }
  return 0;
}

static void
dump_struct(T_STRUCT *sp)
{
  int flags;
  T_VARIABLE *vp;

  if ((sp == 0) || (sp->st_flags & SF_GENERATED))
    return;
  sp->st_flags |= SF_GENERATED;
  if (sp->st_class)
    dump_block_deps(sp->st_class);
  for(vp=sp->st_members; vp; vp=vp->var_next)
    if (vp->var_type == VAR_USER)
      dump_struct(vp->var_struct);
  if (sp->st_local_vars)
    for(vp=sp->st_local_vars->var_un.var_user->st_members; vp; vp=vp->var_next)
      if (vp->var_type == VAR_USER)
        dump_struct(vp->var_struct);
  flags = (int) (sp->st_flags & (SF_KSTAT | SF_MIB | SF_NDD));
  switch(flags) {
  case SF_KSTAT:
    dump("kstat ");
    break;
  case SF_MIB:
    dump("mib ");
    break;
  case SF_NDD:
    dump("ndd ");
    break;
  default:
    break;
  }
  dump("%s ", sp->st_class ? "class" : "struct");
  if (sp->st_kname)
    dump("\"%s\" ", sp->st_kname);
  dump("%s {\n", sp->st_name);
  for(vp=sp->st_members; vp; vp=vp->var_next) {
    dump_variable(vp);
    dump(";  ");
    if (Se_flags & SE_DEBUG)
      dump("// var_offset == %d\n", vp->var_offset);
    else
      dump("\n");
  }
  if (sp->st_class)
    dump_block(sp->st_class);
  dump("};\n");
}

static char *
map_type_name(T_VARIABLE *vp)
{
  switch(vp->var_type) {
  case VAR_CHAR:
    return "char";
    break;
  case VAR_UCHAR:
    return "uchar";
    break;
  case VAR_SHORT:
    return "short";
    break;
  case VAR_USHORT:
    return "ushort";
    break;
  case VAR_LONG:
    return "int";
    break;
  case VAR_ULONG:
    return "uint";
    break;
  case VAR_LONGLONG:
    return "longlong";
    break;
  case VAR_ULONGLONG:
    return "ulonglong";
    break;
  case VAR_DOUBLE:
    return "double";
    break;
  case VAR_STRING:
    return "string";
    break;
  case VAR_USER:
    return vp->var_struct->st_name;
    break;
  }
}

static void
dump_variable_declaration(T_VARIABLE *vp)
{
  if (dump_variable(vp)) {
    if (vp->var_initial) {
      dump(" = ");
      dump_expression(vp->var_initial);
    } else if (vp->var_flags & VF_AGGREGATE) {
      dump(" = ");
      dump_aggregate(vp);
      vp->var_flags &= ~VF_AGGREGATE;
      for(vp=vp->var_instances; vp; vp=vp->var_next)
        vp->var_flags &= ~VF_AGGREGATE;
    }
    dump(";\n");
  }
}

static int
dump_variable(T_VARIABLE *vp)
{
  if ((vp == 0) || (vp->var_flags & VF_GENERATED))
    return 0;
  vp->var_flags |= VF_GENERATED;
  if (vp->var_type == VAR_ELLIPSIS)
    dump("...");
  else {
    if (vp->var_special == SS_KVM)
      dump("kvm ");
    if (vp->var_qname)
      dump("%s \"%s\"", map_type_name(vp), vp->var_qname);
    else
      dump("%s %s", map_type_name(vp), vp->var_name);
    switch(vp->var_dimension) {
    case 0:
      break;
    case -1:
      dump("[]");
      break;
    default:
      dump("[%d]", vp->var_dimension);
      break;
    }
  }
  return 1;
}

static void
dump_call(T_FCALL *cp)
{
  T_EXPR *ep;

  dump("%s(", cp->c_name);
  for(ep=cp->c_args; ep; ep=ep->e_next) {
    dump_expression(ep);
    if (ep->e_next)
      dump(", ");
  }
  dump(")");
}

static void
dump_block(T_BLOCK *bp)
{
  T_STATEMENT *sp;
  T_VARIABLE *vp;

  if ((bp == 0) || (bp->b_flags & B_GENERATED) || (bp->b_statements == 0))
    return;
  bp->b_flags |= B_GENERATED;

  /* get these dependencies out of the way */
  dump_block_deps(bp);

  if (bp->b_return)
    dump("%s\n", map_type_name(bp->b_return));
  dump("%s(", bp->b_name);
  for(vp=bp->b_parameters; vp; vp=vp->var_next) {
    dump_variable(vp);
    if (vp->var_next)
      dump(", ");
  }
  dump(")\n{\n");
  for(vp=bp->b_variables; vp; vp=vp->var_next)
    if (vp->var_flags & VF_REFERENCED)
      dump_variable_declaration(vp);
  dump_statement_list(bp->b_statements, 1);
  dump("}\n");
}

static void
dump_lexpression(T_LEXPR *ep)
{
  static char *ops[] = {
   0, " == ", " != ", " < ", " > ", " >= ", " <= ", " =~ ", " !=~ "
  };

  if (ep == 0)
    return;
  switch(ep->le_op) {
  case LE_EQ:
  case LE_NE:
  case LE_LT:
  case LE_GT:
  case LE_GE:
  case LE_LE:
  case LE_RE_EQ:
  case LE_RE_NEQ:
    dump_expression(ep->le_left);
    dump(ops[ep->le_op]);
    dump_expression(ep->le_right);
    break;
  case LE_AND:
    dump_lexpression((T_LEXPR *) ep->le_left);
    dump(" && ");
    dump_lexpression((T_LEXPR *) ep->le_right);
    break;
  case LE_OR:
    dump_lexpression((T_LEXPR *) ep->le_left);
    dump(" || ");
    dump_lexpression((T_LEXPR *) ep->le_right);
    break;
  case LE_PREC:
    dump("(");
    dump_lexpression((T_LEXPR *) ep->le_left);
    dump(")");
    break;
  case LE_NOT:
    dump("!(");
    dump_lexpression((T_LEXPR *) ep->le_left);
    dump(")");
    break;
  }
}

static void
dump_statement_list(T_STATEMENT *sp, int terminate)
{
  if (sp == 0) {
    dump(";\n");
    return;
  }
  for(; sp; sp=sp->s_next) {
    if (terminate == ',' && sp->s_next == 0)
      terminate = 0;
    dump_statement(sp, terminate);
  }
}

static void
dump_statement(T_STATEMENT *sp, int terminate)
{
  char term_char = ';';
  int i;
  T_FCALL *cp;
  T_ASSIGN *ap;
  T_VARIABLE *vp;
  T_STATEMENT st;
  T_STATEMENT *ssp;
  T_RETURN *rp;
  T_SWITCH *sw;
  T_CASE *csp;
  T_DO *dp;
  T_WHILE *wp;
  T_FOR *fp;
  T_IF *ip;
  avlhdr *case_tree;
  anode *anp;

  if (terminate == 0)
    term_char = ' ';
  else if (terminate == ',')
    term_char = ',';

again:
  if (sp->s_type >= S_BUILTIN_START) {
    dump_call(sp->s_un.s_call);
    dump("%c\n", term_char);
  } else if (sp->s_type >= S_STATEMENT_START) {
    switch(sp->s_type) {
    case S_CALL:
      cp = sp->s_un.s_call;
      if (strcmp(cp->c_name, "se_lazy_lvalue")) {
        dump_call(cp);
        dump("%c\n", term_char);
        break;
      }
      /* lazy_lvalue */
      sp = (T_STATEMENT *) cp->c_args->e_variable->var_un.var_register;
      goto again;
    case S_ASSIGN:
      ap = sp->s_un.s_assign;
      dump_value(ap->a_variable);
      switch(ap->a_op) {
      case A_ASSIGN:
        dump(" = ");
        break;
      case A_ADD:
        dump(" += ");
        break;
      case A_SUBTRACT:
        dump(" -= ");
        break;
      case A_MULTIPLY:
        dump(" *= ");
        break;
      case A_DIVIDE:
        dump(" /= ");
        break;
      case A_MODULUS:
        dump(" %%= ");
        break;
      case A_BIT_AND:
        dump(" &= ");
        break;
      case A_BIT_OR:
        dump(" |= ");
        break;
      case A_BIT_XOR:
        dump(" ^= ");
        break;
      case A_SHIFT_LEFT:
        dump(" <<= ");
        break;
      case A_SHIFT_RIGHT:
        dump(" >>= ");
        break;
      }
      if ((ap->a_expression->e_type == E_VALUE) &&
          (ap->a_expression->e_variable->var_flags & VF_AGGREGATE))
        dump_aggregate(ap->a_expression->e_variable);
      else
        dump_expression(ap->a_expression);
      dump("%c\n", term_char);
      break;
    case S_INCREMENT:
      dump_value(sp->s_un.s_variable);
      dump("++%c\n", term_char);
      break;
    case S_DECREMENT:
      dump_value(sp->s_un.s_variable);
      dump("--%c\n", term_char);
      break;
    case S_ATTACHMENT:
      dump_call(cp);
      dump("%c\n", term_char);
      break;
    case S_ADDR_OF:
    case S_LAZY_VALUE:
    case S_LAZY_LVALUE:
      break;
    case S_NULL:
      dump("%c\n", term_char);
      break;
    }
  } else {  /* control structures */
    switch(sp->s_type) {
    case S_IF:
      ip = sp->s_un.s_if;
      dump("if (");
      dump_lexpression(ip->i_if);
      dump(") {\n");
      dump_statement_list(ip->i_then, 1);
      dump("} ");
      if (ip->i_else) {
        dump("else {\n");
        dump_statement_list(ip->i_else, 1);
        dump("}");
      }
      dump("\n");
      break;
    case S_WHILE:
      wp = sp->s_un.s_while;
      dump("while(");
      dump_lexpression(wp->w_expr);
      dump(") {\n");
      dump_statement_list(wp->w_statements, 1);
      dump("}\n");
      break;
    case S_FOR:
      fp = sp->s_un.s_for;
      dump("for(");
      if (fp->f_before)
        dump_statement_list(fp->f_before, ',');
      dump("; ");
      if (fp->f_while)
        dump_lexpression(fp->f_while);
      dump("; ");
      if (fp->f_after)
        dump_statement_list(fp->f_after, ',');
      dump(") {\n");
      dump_statement_list(fp->f_statements, 1);
      dump("}\n");
      break;
    case S_DO:
      dp = sp->s_un.s_do;
      dump("do {\n");
      dump_statement_list(dp->do_statements, 1);
      dump("} while(");
      dump_lexpression(dp->do_while);
      dump(");\n");
      break;
    case S_SWITCH:
      sw = sp->s_un.s_switch;
      dump("switch(");
      dump_expression(sw->sw_expr);
      dump(") {\n");
      case_tree = avlinit();
      if (case_tree == 0)
        yyerror("cannot grow case_tree", ERR_FATAL);
      case_tree->ah_cmp = AVC_INT;
      for(csp=sw->sw_case_list; csp; csp=csp->ca_next)
        if (avlinsert(case_tree, csp->ca_statements, 0, &anp) == AVL_NOMEM)
          yyerror("out of case_tree node memory", ERR_FATAL);
      csp = sw->sw_default;
      if (csp)
        if (avlinsert(case_tree, csp->ca_statements, 0, &anp) == AVL_NOMEM)
          yyerror("out of case_tree node memory", ERR_FATAL);
      for(csp=sw->sw_case_list; csp; csp=csp->ca_next) {
        if (csp->ca_value) {
          dump("case ");
          dump_aggregate_member(csp->ca_value);
          dump(":\n");
        } else
          dump("default:\n");
        if ((csp->ca_flags & CA_STATEMENTS) == 0)
          continue;
        for(i=0, ssp=csp->ca_statements; ssp; ssp=ssp->s_next, i=1) {
          if (i && avlget(case_tree, ssp))
            break;
          dump_statement(ssp, 1);
        }
      }
      dump("}\n");
      avlfree(case_tree);
      break;
    case S_RETURN:
      rp = sp->s_un.s_return;
      dump("return ");
      dump_expression(rp->ret_expr);
      dump(";\n");
      break;
    case S_BREAK:
      dump("break;\n");
      break;
    case S_CONTINUE:
      dump("continue;\n");
      break;
    }
  }
}

static void
dump_value(T_VARIABLE *vp)
{
  if (vp->var_parent) {
    dump_value(vp->var_parent);
    dump(".");
  }
  dump(vp->var_name);
  if (vp->var_subscript) {
    dump("[");
    dump_expression(vp->var_subscript);
    dump("]");
  }
}

static void
dump_expression(T_EXPR *ep)
{
  T_VARIABLE *vp;
  T_FCALL *cp;
  T_EXPR *xp;
  T_STATEMENT st;

  if (ep == 0)
    return;
  switch(ep->e_type) {
  case E_VALUE:
    vp = ep->e_variable;
    if (vp->var_name)
      dump_value(vp);
    else
      dump_aggregate_member(vp);
    break;
  case E_INCRA:
  case E_LAZY_INCRA:
    vp = ep->e_variable;
    dump_value(vp);
    dump("++");
    break;
  case E_INCRB:
  case E_LAZY_INCRB:
    vp = ep->e_variable;
    dump("++");
    dump_value(vp);
    break;
  case E_DECRA:
  case E_LAZY_DECRA:
    vp = ep->e_variable;
    dump_value(vp);
    dump("--");
    break;
  case E_DECRB:
  case E_LAZY_DECRB:
    vp = ep->e_variable;
    dump("--");
    dump_value(vp);
    break;
  case E_CALL:
    cp = ep->e_call;
    if (strcmp(cp->c_name, "se_lazy_value") == 0) {
      dump_expression(cp->c_args);
      break;
    } else if (strcmp(cp->c_name, "address_of") == 0) {
      dump("&");
      dump_value(cp->c_args->e_variable);
      break;
    } else if (strcmp(cp->c_name, "type_cast") == 0) {
      dump("((%s) ", map_type_name(cp->c_block->b_return));
      dump_expression(cp->c_args);
      dump(")");
      break;
    } else if (strcmp(cp->c_name, "indirection") == 0) {
      dump("*((%s *) ", map_type_name(cp->c_block->b_return));
      dump_expression(cp->c_args);
      dump(")");
      break;
    } else if (strcmp(cp->c_name, "new") == 0) {
      dump("new %s[", map_type_name(cp->c_block->b_return));
      dump_expression(cp->c_args->e_variable->var_initial);
      dump("]");
      break;
    } else if (strcmp(cp->c_name, "renew") == 0) {
      dump("renew %s[", cp->c_args->e_variable->var_name);
      dump_expression(cp->c_args->e_next);
      dump("]");
      break;
    }
    dump_call(cp);
    break;
  case E_EXPRESSION:
    if (ep->e_right == 0) {
      dump("(");
      dump_expression(ep->e_left);
      dump(")");
      break;
    }
    dump_expression(ep->e_left);
    switch(ep->e_op) {
    case EO_ADD:
      dump(" + ");
      break;
    case EO_SUBTRACT:
      dump(" - ");
      break;
    case EO_MULTIPLY:
      dump(" * ");
      break;
    case EO_DIVIDE:
      dump(" / ");
      break;
    case EO_MODULUS:
      dump(" %% ");
      break;
    case EO_BIT_AND:
      dump(" & ");
      break;
    case EO_BIT_OR:
      dump(" | ");
      break;
    case EO_BIT_XOR:
      dump(" ^ ");
      break;
    case EO_SHIFT_LEFT:
      dump(" << ");
      break;
    case EO_SHIFT_RIGHT:
      dump(" >> ");
      break;
    }
    dump_expression(ep->e_right);
    break;
  case E_QCOP:
    dump("(");
    dump_lexpression(ep->e_lexpr);
    dump(" ? ");
    dump_expression(ep->e_left);
    dump(" : ");
    dump_expression(ep->e_right);
    dump(")");
    break;
  case E_ASSIGN:
    dump("(");
    memset(&st, '\0', sizeof(st));
    st.s_type = S_ASSIGN;
    st.s_un.s_assign = ep->e_assign;
    dump_statement(&st, 0);
    dump(")");
    break;
  }
}

static char *
clean_char(int c)
{
  static char b[4];

  switch(c) {
  case 0:
    memcpy(b, "\\0", 3);
    return b;
  case '\'':
    memcpy(b, "\\'", 3);
    return b;
  default:
    break;
  }
  b[0] = (char) c;
  b[1] = '\0';
  return clean_string(b);
}

static char *
clean_string(char *s)
{
  static char buf[BUFSIZ*2];
  char *p;
  int i = 0;

  for(p=s; *p; p++) {
    switch(*p) {
    case '\b':
      buf[i++] = '\\';
      buf[i++] = 'b';
      break;
    case '\f':
      buf[i++] = '\\';
      buf[i++] = 'f';
      break;
    case '\n':
      buf[i++] = '\\';
      buf[i++] = 'n';
      break;
    case '\t':
      buf[i++] = '\\';
      buf[i++] = 't';
      break;
    case '\r':
      buf[i++] = '\\';
      buf[i++] = 'r';
      break;
    case '\0':
      buf[i++] = '\\';
      buf[i++] = '0';
      break;
    case '"':
      buf[i++] = '\\';
      buf[i++] = '"';
      break;
    default:
      if (isprint(*p) == 0) {
        buf[i++] = '\\';
        buf[i++] = 'x';
        sprintf(&buf[i++], "%x", *p);
      } else
        buf[i++] = *p;
    }
  }
  buf[i] = '\0';
  return buf;
}

static void
dump_aggregate_member(T_VARIABLE *xp)
{
  char buf[BUFSIZ];
  char *p;

  switch(xp->var_type) {
  case VAR_CHAR:
    if (xp->var_dimension)
      dump("\"%s\"", clean_string(xp->var_un.var_string));
    else
      dump("'%s'", clean_char(xp->var_un.var_digit));
    break;
  case VAR_SHORT:
  case VAR_LONG:
    dump("%d", xp->var_un.var_digit);
    break;
  case VAR_UCHAR:
  case VAR_USHORT:
  case VAR_ULONG:
    dump("%u", xp->var_un.var_udigit);
    break;
  case VAR_LONGLONG:
    dump("%lld", xp->var_un.var_ldigit);
    break;
  case VAR_ULONGLONG:
    dump("%llu", xp->var_un.var_uldigit);
    break;
  case VAR_DOUBLE:
    snprintf(buf, sizeof buf, "%g", xp->var_un.var_rdigit);
    if ((strchr(buf, '.') == 0) && (strchr(buf, 'e') == 0))
      dump("%s.0", buf);
    else
      dump("%s", buf);
    break;
  case VAR_STRING:
    if (xp->var_un.var_string) {
      p = buf;
      snprintf(buf, sizeof buf, "\"%s\"", clean_string(xp->var_un.var_string));
    } else
      p = "nil";
    dump("%s", p);
    break;
  }
}

static void
dump_aggregate(T_VARIABLE *vp)
{
  char buf[BUFSIZ];
  char *p;
  int i;
  void *array;
  T_VARIABLE *xp;
  T_VARIABLE var;

  if (vp->var_type == VAR_CHAR) {
    memset(buf, '\0', sizeof buf);
    memcpy(buf, vp->var_un.var_string, vp->var_dimension);
    dump("\"%s\"", clean_string(buf));
    return;
  }
  dump("{\n");
  if ((vp->var_type == VAR_USER) && (vp->var_dimension == 0)) {
    for(xp=vp->var_un.var_user->st_members; xp; xp=xp->var_next) {
      if ((xp->var_dimension && (xp->var_type != VAR_CHAR))
       || (xp->var_type == VAR_USER)) {
        dump_aggregate(xp);
        if (xp->var_next)
          dump(", ");
        continue;
      }
      dump_aggregate_member(xp);
      if (xp->var_next)
        dump(", ");
    }
  } else {
    /* it's an array */
    array = vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++) {
      switch(vp->var_type) {
      case VAR_CHAR:
        /* handled on first statement of function */
        break;
      case VAR_UCHAR:
        dump("%u", ((unsigned char *) array)[i]);
        break;
      case VAR_SHORT:
        dump("%d", ((short *) array)[i]);
        break;
      case VAR_USHORT:
        dump("%u", ((unsigned short *) array)[i]);
        break;
      case VAR_LONG:
        dump("%d", ((int *) array)[i]);
        break;
      case VAR_ULONG:
        dump("%u", ((unsigned int *) array)[i]);
        break;
      case VAR_LONGLONG:
        dump("%lld", ((T_LLONG *) array)[i]);
        break;
      case VAR_ULONGLONG:
        dump("%llu", ((T_ULLONG *) array)[i]);
        break;
      case VAR_DOUBLE:
        snprintf(buf, sizeof buf, "%g", ((double *) array)[i]);
        if ((strchr(buf, '.') == 0) && (strchr(buf, 'e') == 0))
          dump("%s.0", buf);
        else
          dump("%s", buf);
        break;
      case VAR_STRING:
        if (((char **) array)[i]) {
          p = buf;
          snprintf(buf, sizeof buf,
            "\"%s\"", clean_string(((char **) array)[i]));
        } else
          p = "nil";
        dump("%s", p);
        break;
      case VAR_USER:
        memset(&var, '\0', sizeof var);
        var.var_type = VAR_USER;
        var.var_un.var_user = ((T_STRUCT **) array)[i];
        dump_aggregate(&var);
        break;
      }
      if (i < (vp->var_dimension - 1))
        dump(", ");
    }
  }
  dump("\n}\n");
}

static void
dump(char *format, ...)
{
  va_list args;

  if (code_fp == 0)
    code_fp = stdout;
  va_start(args, format);
  vfprintf(code_fp, format, args);
}

static void
dump_block_deps(T_BLOCK *bp)
{
  T_VARIABLE *vp;
  T_STATEMENT *sp;

  /* if the block returns a struct, it must be declared first */
  if (bp->b_return && (bp->b_return->var_type == VAR_USER))
    dump_struct(bp->b_return->var_struct);

  /* if a parameter to the block is a struct, it must be declared first */
  for(vp=bp->b_parameters; vp; vp=vp->var_next)
    if (vp->var_type == VAR_USER)
      dump_struct(vp->var_struct);

  /* if a local variable is a struct, it must be declared first */
  for(vp=bp->b_variables; vp; vp=vp->var_next) {
    if (vp->var_type == VAR_USER)
      dump_struct(vp->var_struct);

    /* if a local variable has an initialization check it's dependencies */
    if (vp->var_initial)
      dump_expression_deps(vp->var_initial);
  }

  /* now lets hunt down references to global vars and functions in the code */
  for(sp=bp->b_statements; sp; sp=sp->s_next)
    dump_statement_deps(sp);
}

static void
dump_variable_deps(T_VARIABLE *vp)
{
  while(vp->var_parent)
    vp = vp->var_parent;
  if (vp->var_name && (vp->var_flags & VF_GLOBAL)) {
    if (vp->var_type == VAR_USER)
      dump_struct(vp->var_struct);
    vp = se_get_variable(vp->var_name);
    dump_variable_declaration(vp);
  }
}

static void
dump_expression_deps(T_EXPR *ep)
{
  T_VARIABLE *vp;
  T_FCALL *cp;
  T_EXPR *xp;

  if (ep == 0)
    return;
  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    dump_variable_deps(ep->e_variable);
    break;
  case E_CALL:
    cp = ep->e_call;
    if (strcmp(cp->c_name, "se_lazy_value") == 0) {
      dump_expression_deps(cp->c_args);
      break;
    } else if (strcmp(cp->c_name, "address_of") == 0) {
      dump_variable_deps(cp->c_args->e_variable);
      break;
    }
    if ((cp->c_builtin == 0) && cp->c_block && cp->c_block->b_return)
      dump_block(cp->c_block);
    for(xp=cp->c_args; xp; xp=xp->e_next)
      dump_expression_deps(xp);
    break;
  case E_EXPRESSION:
  case E_QCOP:
    dump_expression_deps(ep->e_left);
    if (ep->e_right)
      dump_expression_deps(ep->e_right);
    break;
  case E_ASSIGN:
    dump_variable_deps(ep->e_assign->a_variable);
    dump_expression_deps(ep->e_assign->a_expression);
    break;
  }
}

static void
dump_lexpression_deps(T_LEXPR *ep)
{
  if (ep == 0)
    return;
  switch(ep->le_op) {
  case LE_EQ:
  case LE_NE:
  case LE_LT:
  case LE_GT:
  case LE_GE:
  case LE_LE:
    dump_expression_deps(ep->le_left);
    dump_expression_deps(ep->le_right);
    break;
  case LE_AND:
  case LE_OR:
    dump_lexpression_deps((T_LEXPR *) ep->le_left);
    dump_lexpression_deps((T_LEXPR *) ep->le_right);
    break;
  case LE_PREC:
    dump_lexpression_deps((T_LEXPR *) ep->le_left);
    break;
  }
}

static void
dump_statement_deps(T_STATEMENT *sp)
{
  int i;
  T_EXPR *ep;
  T_FCALL *cp;
  T_ASSIGN *ap;
  T_VARIABLE *vp;
  T_STATEMENT st;
  T_STATEMENT *ssp;
  T_RETURN *rp;
  T_SWITCH *sw;
  T_CASE *csp;
  T_DO *dp;
  T_WHILE *wp;
  T_FOR *fp;
  T_IF *ip;

again:
  if (sp->s_type >= S_BUILTIN_START) {
    cp = sp->s_un.s_call;
    for(ep=cp->c_args; ep; ep=ep->e_next)
      dump_expression_deps(ep);
  } else if (sp->s_type >= S_STATEMENT_START) {
    switch(sp->s_type) {
    case S_CALL:
      cp = sp->s_un.s_call;
      if (strcmp(cp->c_name, "se_lazy_lvalue")) {
        if ((cp->c_builtin == 0) && cp->c_block && cp->c_block->b_return)
          dump_block(cp->c_block);
        for(ep=cp->c_args; ep; ep=ep->e_next)
          dump_expression_deps(ep);
        break;
      }
      /* lazy_lvalue */
      sp = (T_STATEMENT *) cp->c_args->e_variable->var_un.var_register;
      goto again;
    case S_ASSIGN:
      ap = sp->s_un.s_assign;
      dump_variable_deps(ap->a_variable);
      dump_expression_deps(ap->a_expression);
      break;
    case S_INCREMENT:
    case S_DECREMENT:
      dump_variable_deps(sp->s_un.s_variable);
      break;
    case S_ATTACHMENT:
      for(ep=cp->c_args; ep; ep=ep->e_next)
        dump_expression_deps(ep);
      break;
    /* don't see these as s_type values */
    case S_ADDR_OF:
    case S_LAZY_VALUE:
    case S_LAZY_LVALUE:
      break;
    }
  } else {  /* control structures */
    switch(sp->s_type) {
    case S_IF:
      ip = sp->s_un.s_if;
      dump_lexpression_deps(ip->i_if);
      for(sp=ip->i_then; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      for(sp=ip->i_else; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      break;
    case S_WHILE:
      wp = sp->s_un.s_while;
      dump_lexpression_deps(wp->w_expr);
      for(sp=wp->w_statements; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      break;
    case S_FOR:
      fp = sp->s_un.s_for;
      if (fp->f_before)
        dump_statement_deps(fp->f_before);
      if (fp->f_while)
        dump_lexpression_deps(fp->f_while);
      if (fp->f_after)
        dump_statement_deps(fp->f_after);
      for(sp=fp->f_statements; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      break;
    case S_DO:
      dp = sp->s_un.s_do;
      for(sp=dp->do_statements; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      dump_lexpression_deps(dp->do_while);
      break;
    case S_SWITCH:
      sw = sp->s_un.s_switch;
      dump_expression_deps(sw->sw_expr);
      for(sp=sw->sw_case_list->ca_statements; sp; sp=sp->s_next)
        dump_statement_deps(sp);
      break;
    case S_RETURN:
      rp = sp->s_un.s_return;
      dump_expression_deps(rp->ret_expr);
      break;
    case S_BREAK:
    case S_CONTINUE:
      break;
    }
  }
}
