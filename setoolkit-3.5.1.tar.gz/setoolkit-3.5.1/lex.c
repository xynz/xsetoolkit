/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ctype.h>
#include <fcntl.h>
#include <string.h>
#include <regexpr.h>
#include <stropts.h>
#include <poll.h>
#include <sys/stat.h>
#include <sys/signal.h>
#include <kstat.h>
#include <math.h>
#include <limits.h>
#include <errno.h>
#include "avl.h"
#include "se.h"
#include "se-parser.h"

#define USE_CUSTOM_ATOF 1

#define _MAX_(a, b) (((a) > (b)) ? (a) : (b))

#define TOK_SYMS    "[]{}()@|!&#;:.,+*/=-><~%? \t\n\\^"
#define UNGETCHAR() (P--)
#define UNLEX(tok)  (Last_tok = (tok))
#define SKIP()      (*P = '\0', Eoln = 0, *Lex_currtok = '\0', Last_tok = 0)

static int  Last_tok = 0;
static int  Currpos = 0;
static char *P = 0;
static char Currline[BUFSIZ] = { 0 };
static char error_buf[BUFSIZ];
static char tok_syms[128];

static int  Eoln = 0;
static int  matchQuote = 0;
static int  file_buf_size;
static char *file_buf;

static int getC(void);
static int peekC(void);
static int numeric(char *);
static int number_check(char *);
static int escapeChar(void);
static int is_real(char *);
#ifdef USE_CUSTOM_ATOF
static double ascii_to_double(char *);
#endif
static void check_for_line_no(void);
static FILE *open_cpp(char *, char *, char *, int);

/* * * * Global lex stuff * * * */

char  Lex_currentFile[BUFSIZ];
char  Lex_currtok[BUFSIZ];
int Lex_line_no = 0;
T_REGISTER Lex_integerValue;
double Lex_doubleValue;
FILE  *Lex_input;

/* This is the core lexical analyzer. */

static int  
lex(void)
{
  char *p;
  char qs = 0;
  char next;
  int c;
  char *t_end = &Lex_currtok[sizeof Lex_currtok - 1];

  if (Last_tok != 0) {
    next = Last_tok;
    Last_tok = 0;
    return next;
  }
  Currpos = (int) (P - Currline);
  p = Lex_currtok;
  while (c = getC()) {
    if (p == t_end)
      yyerror("Token buffer overflow", ERR_FATAL);
    if (tok_syms[c]) {
      if (qs) {
        if (c == '\\')
          *p++ = escapeChar();
        else
          *p++ = c;
      } else if (p == Lex_currtok)
        switch (c) {
        case '[':
          return LEFT_SQUARE;
        case ']':
          return RIGHT_SQUARE;
        case '{':
          return LEFT_CURLY;
        case '}':
          return RIGHT_CURLY;
        case '(':
          return LEFT_PAREN;
        case ')':
          return RIGHT_PAREN;
        case '@':
          return AT_SIGN;
        case '|':
          next = peekC();
          switch(next) {
          case '|':
            (void) getC();
            return OR;
          case '=':
            (void) getC();
            return OR_EQ;
          }
          return PIPE;
        case '!':
          next = peekC();
          if (next == '=') {
            (void) getC();
            next = peekC();
            if (next == '~') {
              (void) getC();
              return RE_NEQ;
            }
            return NE;
          }
          return EXCLAMATION;
        case '&':
          next = peekC();
          switch(next) {
          case '&':
            (void) getC();
            return AND;
          case '=':
            (void) getC();
            return AND_EQ;
          }
          return AMPERSAND;
        case ';':
          return SEMICOLON;
        case ':':
          return COLON;
        case ',':
          return COMMA;
        case '+':
          next = peekC();
          switch(next) {
          case '+':
            (void) getC();
            return INCREMENT;
          case '=':
            (void) getC();
            return PLUS_EQ;
          default:
            break;
          }
          return PLUS;
        case '*':
          next = peekC();
          if (next == '=') {
            (void) getC();
            return TIMES_EQ;
          }
          return ASTERISK;
        case '/':
          next = peekC();
          if (next == '=') {
            (void) getC();
            return SLASH_EQ;
          }
          return SLASH;
        case '=':
          next = peekC();
          if (next == '=') {
            (void) getC();
            return EQ;
          } else if (next == '~') {
            (void) getC();
            return RE_EQ;
          }
          return ASSIGN;
        case '-':
          next = peekC();
          switch(next) {
          case '-':
            (void) getC();
            return DECREMENT;
          case '=':
            (void) getC();
            return MINUS_EQ;
          default:
            break;
          }
          return MINUS;
        case '>':
          next = peekC();
          switch(next) {
          case '=':
            (void) getC();
            return GE;
          case '>':
            (void) getC();
            next = peekC();
            if (next == '=') {
              (void) getC();
              return SHIFT_RIGHT_EQ;
            }
            return SHIFT_RIGHT;
          }
          return GT;
        case '<':
          next = peekC();
          switch(next) {
          case '=':
            (void) getC();
            return LE;
          case '<':
            (void) getC();
            next = peekC();
            if (next == '=') {
              (void) getC();
              return SHIFT_LEFT_EQ;
            }
            return SHIFT_LEFT;
          default:
            break;
          }
          return LT;
        case '~':
          return TILDE;
        case '%':
          next = peekC();
          if (next == '=') {
            (void) getC();
            return MOD_EQ;
          }
          return PERCENT;
        case '?':
          return QUESTION;
        case '.':
          next = peekC();
          if (next == '.') {
            (void) getC();
            next = peekC();
            if (next == '.') {
              (void) getC();
              return ELLIPSIS;
            } else
              return DOT_DOT;
          }
          return DOT;
        case '#':
          check_for_line_no();
          SKIP();
          break;
        case '\\':
          return BACKSLASH;
        case '^':
          next = peekC();
          if (next == '=') {
            (void) getC();
            return XOR_EQ;
          }
          return HAT;
        case ' ':
        case '\t':
        case '\n':
        case '\r':
          break;
        }
      else { /* if (p == Lex_currtok) */
        *p = '\0';

        /* real number in progress */
        if ((c == '.') && numeric(Lex_currtok)) {
          *p++ = '.';
          continue;
        }
        if ((c != ' ') && (c != '\t') && (c != EOLN))
          UNGETCHAR();

        return STRING;
      }
    } else {  /* if (strchr(TOK_SYMS, c)) */
      if ((c == '"') || (c == '\'')) {
        if ((p != Lex_currtok) && (qs == 0)) {
          *p = '\0';
          UNGETCHAR();
          return STRING;
        }
        if (qs) {
          if (c == matchQuote)
            qs = (qs == 0);
        } else {
          matchQuote = c;
          qs = (qs == 0);
        }
      } else if (c == EOLN) {
        if (p == Lex_currtok)
          return EOLN;
        Eoln++;
        *p = '\0';
        return STRING;
      }
      *p++ = c;
    }
  }

  /* end of file, but we've got a string */

  if (p != Lex_currtok) {
    *p = '\0';
    return STRING;
  }
  return 0;
}


/*  Return anything but an EOLN token */

static int  
llex(void)
{
  int tok;

  while ((tok = lex()) == EOLN)
    ;
  return tok;
}

static int  
getC(void)
{
  /* if we need more input */
  if ((P < Currline || P > &Currline[sizeof Currline - 1]) || *P == '\0') {
    /* if we need to demonstrate end-of-line */
    if (Eoln) {   /* then mark it as such and return it */
      Eoln = 0;
      return EOLN;
    }
    for (;;) {
      /* read it in */
      if (fgets(Currline, sizeof Currline, Lex_input) == 0) {
        if (Lex_input != stdin)
          pclose(Lex_input);
        return 0;
      }

      Lex_line_no++;

      P = Currline;
      Currpos = 0;

      /* we'll need an end-of-line next time */
      Eoln++;

      /* did we REALLY get something ? */
      if (strlen(Currline))
        break;
    }
  }

  /* gotcha */
  return *P++;
}

/*  Take a look-see at what the next character is */

static int  
peekC(void)
{
  int c;

  if ((*P == '\0') && (Lex_input == stdin))
    /* we have all that we can have, can't much peek into stdin */
    return 0;

  c = getC();
  if (c == EOLN)
    c = getC();
  if (c)
    UNGETCHAR();
  return c;
}

int
se_cleanup_tok_syms(char *s)
{
  int i;
  int changed = 0;

  for(i=0; s[i]; i++)
    if (tok_syms[s[i]]) {
      s[i] = '_';
      changed = 1;
    }
  return changed;
}

#ifdef USE_CUSTOM_ATOF
static double
ascii_to_double(char *ptr)
{
  char buf[DBL_DIG];
  char c;
  int i;
  int j;
  int base_sign = 1;
  int exp_sign = 1;
  double m = 1.0;
  double exponent = 0.0;
  double base = 0.0;
  double mantissa = 0.0;
  double d = 0.1;
  double r;

  for(c = *ptr; c; c = *(++ptr))
    if ((isspace(c) == 0) && (c != '0'))
      break;
  c = *ptr;
  if (c == '+')
    ptr++;
  else if (c == '-') {
    base_sign = -1;
    ptr++;
  }
  memset(buf, '\0', sizeof buf);
  for(i = 0, c = *ptr; c; c = *(++ptr)) {
    if (isdigit(c) == 0)
      break;
    buf[i++] = c;
    if (i == DBL_DIG) {
      errno = ERANGE;
      return HUGE_VAL * base_sign;
    }
  }
  for(j = i - 1; j >= 0; j--) {
    base += (buf[j] - '0') * m;
    m *= 10.0;
  }
  if (c == '\0')
    return (double) (base * base_sign);
  if (c == '.') {
    ptr++;
    for(c = *ptr; c; c = *(++ptr)) {
      if (isdigit(c) == 0)
        break;
      mantissa += (c - '0') * d;
      d /= 10.0;
    }
    if (c == '\0')
      return (base + mantissa) * (double) base_sign;
  }
  if ((c != 'e') && (c != 'E'))
    return (base + mantissa) * (double) base_sign;
  c = *(++ptr);
  if (c == '+')
    ptr++;
  else if (c == '-') {
    exp_sign = -1;
    ptr++;
  } else
    return (base + mantissa) * (double) base_sign;
  for(c = *ptr; c; c = *(++ptr))
    if (c != '0')
      break;
  memset(buf, '\0', sizeof buf);
  for(i = 0, c = *ptr; c; c = *(++ptr)) {
    if (isdigit(c) == 0)
      break;
    buf[i++] = c;
    if (i == DBL_DIG)
      break;
  }
  for(m = 1.0, j = i - 1; j >= 0; j--) {
    exponent += (buf[j] - '0') * m;
    m *= 10.0;
  }
  if (exp_sign == 1)
    d = 10;
  else
    d = 0.1;
  for(r=1.0, i=0; i<exponent; i++)
    r *= d;
  mantissa *= r;
  r *= base;
  return (r + mantissa) * (double) base_sign;
}
#endif

static int
string_break(char *buf, char *vec[])
{
  char *p;
  int i = 0;

  for(p=strtok(buf, " "); p; p=strtok(0, " "))
    vec[i++] = p;
  return i;
}

static void
kill_quotes(char *s)
{
  char *d = s;
  int i;
  int j;

  for(i=j=0; s[i]; i++)
    if (s[i] != '"')
      d[j++] = s[i];
  d[j] = '\0';
}

typedef struct _map MAP;
struct _map {
  char *string;
  int token;
};

/*  Look closely, here are all of the keywords.  */

static MAP theMap[] = {
  { "MAX_CPU",        BI_MAX_CPU           },
  { "MAX_DISK",       BI_MAX_DISK          },
  { "MAX_IF",         BI_MAX_IF            },
  { "MAX_INTS",       BI_MAX_INTS          },
  { "attach",         ATTACH               },
  { "break",          BREAK                },
  { "case",           CASE                 },
  { "char",           CHAR_TYPE            },
  { "class",          CLASS                },
  { "continue",       CONTINUE             },
  { "default",        DEFAULT              },
  { "do",             DO                   },
  { "double",         DOUBLE_TYPE          },
  { "else",           ELSE                 },
  { "extern",         EXTERN               },
  { "for",            FOR                  },
  { "if",             IF                   },
  { "int",            LONG_TYPE            },
  { "int32_t",        LONG_TYPE            },
  { "int64_t",        LONGLONG_TYPE        },
  { "kstat",          KSTAT                },
  { "kvm",            KVM                  },
  { "long",           LONG_TYPE            },
  { "longlong",       LONGLONG_TYPE        },
  { "longlong_t",     LONGLONG_TYPE        },
  { "mib",            MIB                  },
  { "ndd",            NDD                  },
  { "new",            LNEW                 },
  { "nil",            NIL                  },
  { "pointer_t",      ULONG_TYPE           },
  { "pragma",         PRAGMA               },
  { "renew",          LRENEW               },
  { "return",         LRETURN              },
  { "short",          SHORT_TYPE           },
  { "string",         STRING_TYPE          },
  { "struct",         STRUCT               },
  { "switch",         SWITCH               },
  { "uchar",          UCHAR_TYPE           },
  { "uchar_t",        UCHAR_TYPE           },
  { "uint",           ULONG_TYPE           },
  { "uint32_t",       ULONG_TYPE           },
  { "uint64_t",       ULONGLONG_TYPE       },
  { "uint_t",         ULONG_TYPE           },
  { "ulong",          ULONG_TYPE           },
  { "ulong_t",        ULONG_TYPE           },
  { "u_longlong_t",   ULONGLONG_TYPE       },
  { "ulonglong",      ULONGLONG_TYPE       },
  { "ushort",         USHORT_TYPE          },
  { "ushort_t",       USHORT_TYPE          },
  { "while",          WHILE                },
  { 0,                0                    }
};  
static avlhdr *keywords = 0;

static void
init_keyword_tree(void)
{
  MAP *mp;
  anode *anp;

  keywords = avlinit();
  if (keywords == 0)
    yyerror("out of tree memory", ERR_FATAL);
  keywords->ah_cmp = AVC_NONE;
  for(mp=theMap; mp->string; mp++)
    if (avlinsert(keywords, mp->string, (void *) (long) mp->token, &anp) == AVL_NOMEM)
      yyerror("out of keyword memory", ERR_FATAL);
}

int
se_get_keyword(char *name)
{
  anode *anp;

  if (keywords == 0)
    init_keyword_tree();
  anp = avlget(keywords, name);
  if (anp == 0)
    return 0;
  return (long) anp->an_data;
}

static void
fix_lp64_type(char *name, int is_signed)
{
  anode *anp;

  anp = avlget(keywords, name);
  if (anp == 0)
    yyerror("Cannot find builtin types", ERR_LATER);
  if (is_signed)
    anp->an_data = (void *) LONGLONG_TYPE;
  else
    anp->an_data = (void *) ULONGLONG_TYPE;
}

static int bi_max_cpu;
static int bi_max_disk;
static int bi_max_if;
static int bi_max_ints;

static int
count_type(int kstat_type)
{
  int count = 0;
  kstat_ctl_t *kc = kstat_open();
  kstat_t *kp;

  for(kp=kc->kc_chain; kp; kp=kp->ks_next)
    if (kp->ks_type == kstat_type)
      count++;

  kstat_close(kc);

  return count == 0 ? 1 : count;
}

static int
count_nets(void)
{
  int i;
  int fields;
  int count = 0;
  kstat_ctl_t *kc = kstat_open();
  kstat_t *kp;
  kstat_named_t *kn;

  for(kp=kc->kc_chain; kp; kp=kp->ks_next) {
    if (kp->ks_type == KSTAT_TYPE_NAMED) {
      kstat_read(kc, kp, 0);
      for(fields=i=0; i<kp->ks_ndata; i++) {
        kn = &((kstat_named_t *) kp->ks_data)[i];
        if ((strcmp(kn->name, "ipackets") == 0) ||
            (strcmp(kn->name, "opackets") == 0))
          fields++;
      }
      if (fields == 2)
        count++;
    }
  }

  kstat_close(kc);

  return count;
}

int
yylex(void)
{
  char **pp;
  char *s = Lex_currtok;
  int tok;
  double digVal;
  MAP *mp;
  anode *anp;
  T_SYMBOL *sp;
  static char bi_inited = 0;

  if (keywords == 0) {

    /* first time through, init */
    if (!bi_inited) {
      bi_max_cpu  = sysconf(_SC_NPROCESSORS_CONF);
      bi_max_disk = count_type(KSTAT_TYPE_IO);
      bi_max_if   = count_nets();
      bi_max_ints = count_type(KSTAT_TYPE_INTR);
      bi_inited = 1;
    }

    init_keyword_tree();

    if (sizeof(long) == 8) {
      fix_lp64_type("long", 1);
      fix_lp64_type("ulong", 0);
      fix_lp64_type("ulong_t", 0);
      fix_lp64_type("pointer_t", 0);
    }
  }

  tok = llex();
  if (tok == STRING) {
    /* quoted string */
    if (s[0] == '"')
      return QSTRING;
    else if (s[0] == '\'') {  /* character constant */
      if (s[2] != '\'')
        yyerror("invalid character constant", ERR_NONFATAL);

      Lex_integerValue = (T_REGISTER) s[1];
      return INTEGER;
    }

    /* digit without sign */
    if (isdigit(s[0])) {
      if (is_real(s)) {
#ifdef USE_CUSTOM_ATOF
        Lex_doubleValue = ascii_to_double(s);
#else
        Lex_doubleValue = atof(s);
#endif
        return REAL;
      } else {
        if (number_check(s) == 0) {
          Lex_integerValue = 1;
          return INTEGER;
        }
#ifdef _LP64
        Lex_integerValue = strtoull(s, 0, 0);
#else
        Lex_integerValue = strtoul(s, 0, 0);
#endif
        return INTEGER;
      }
    }

    /* see if it's a keyword */
    anp = avlget(keywords, Lex_currtok);
    if (anp) {
      switch((long) anp->an_data) {
      case BI_MAX_CPU:
        Lex_integerValue = bi_max_cpu;
        break;
      case BI_MAX_DISK:
        Lex_integerValue = bi_max_disk;
        break;
      case BI_MAX_IF:
        Lex_integerValue = bi_max_if;
        break;
      case BI_MAX_INTS:
        Lex_integerValue = bi_max_ints;
        break;
      default:
        return (long) anp->an_data;
      }
      return INTEGER;
    }

    /* see if it's a user type */
    anp = avlget(Se_symbol_table, Lex_currtok);
    if (anp && anp->an_data) {
      sp = (T_SYMBOL *) anp->an_data;
      if (sp && sp->sym_type == SYM_STRUCT)
        return USER_TYPE;
    }
  }
  return tok;
}

static char *
find_file_name(char *fn)
{
  static char path[BUFSIZ];
  char *p = getenv("SEPATH");
  char *dir;

  if (p == 0)
    return fn;
  if (access(fn, F_OK) == 0)
    return fn;
  dir = se_string_save(p);
  for(p=strtok(dir, ":"); p; p=strtok(0, ":")) {
    snprintf(path, sizeof path, "%s/%s", p, fn);
    if (access(path, F_OK) == 0) {
      se_free(dir);
      return path;
    }
  }
  se_free(dir);
  return fn;
}

/*+
 * se_lex_init
 *
 *  Fire up the lexical analysis routines for action
 *
 *  void
 *  se_lex_init(file_name)
 *
 *    char  *file_name;  The name of the file which we'll be reading
 *
 *  Returns:  None
 *  Note:   This function has the potential for exiting the program
-*/

void
se_lex_init(char *file_name, char *cpp_cmd)
{
  int skip = 0;
  char buf[BUFSIZ];
  char cmd[BUFSIZ];
  char first_line[BUFSIZ];
  char *p;
  int wrong = 0;
  long back_to = 0;
  struct stat stbuf;

  memset(tok_syms, '\0', sizeof tok_syms);
  for(p=TOK_SYMS; *p; p++)
    tok_syms[*p] = 1;
  if (file_name) {
    file_name = find_file_name(file_name);

    /* reading a file, stat it and get a file_buf */
    if (stat(file_name, &stbuf) == -1)
      file_buf_size = 8192;
    else
      file_buf_size = _MAX_(stbuf.st_size + BUFSIZ, 8192);
    if (file_buf)
      se_free(file_buf);
    file_buf = (char *) se_alloc(file_buf_size);
    /* we can read the file */
    Lex_input = fopen(file_name, "r");
    if (Lex_input == 0)
      wrong = 1;
    else {
      setvbuf(Lex_input, file_buf, _IOFBF, file_buf_size);
      /* read the first line and see if it has a #! on it */
      if (fgets(buf, sizeof buf, Lex_input) == 0)
        yyerror("Unexpected EOF", ERR_LATER);
      if (cpp_cmd) {
        /* we'll be popening cpp */
        if (strncmp(buf, "#!", 2) == 0)
          snprintf(cmd, sizeof cmd, "(echo '#line 2 \"%s\"' ; %s %s) | %s",
                  file_name, TAIL_CMD, file_name, cpp_cmd);
        else
          snprintf(cmd, sizeof cmd, "%s %s", cpp_cmd, file_name);
        fclose(Lex_input);
        Lex_input = popen(cmd, "r");
        if (Lex_input == 0)
          wrong = 1;
        else
          setvbuf(Lex_input, file_buf, _IOFBF, file_buf_size);
      } else {
        if (strncmp(buf, "#!", 2) == 0) {
          Lex_line_no++;
          back_to = ftell(Lex_input);
        }
      }
    }
  } else {
    file_buf_size = 8192;
    if (file_buf)
      se_free(file_buf);
    file_buf = (char *) se_alloc(file_buf_size);
    file_name = "stdin";
    if (cpp_cmd) {
      Lex_input = popen(cpp_cmd, "r");
      if (Lex_input == 0)
        wrong = 1;
    } else
      Lex_input = stdin;
    if (Lex_input)
      setvbuf(Lex_input, file_buf, _IOFBF, file_buf_size);
  }

  if (wrong) {
    snprintf(buf, sizeof buf, "Cannot open %s", file_name);
    yyerror(buf, ERR_LATER);
  }

  strcpy(Lex_currentFile, file_name);
  fseek(Lex_input, back_to, SEEK_SET);
}

void
se_lex_end(void)
{
  se_free(file_buf);
}

static int
number_check(char *s)
{
  char c;
  char *p = s;
  int base = 10;
  int error = 0;

  if (*s == '0') {
    s++;
    if ((*s == 'x') || (*s == 'X')) {
      s++;
      base = 16;
    } else
      base = 8;
  }
  switch(base) {
  case 8:
    while(c = *s++)
      if ((isdigit(c) == 0) || (c > '7'))
        error++;
    break;
  case 10:
    while(c = *s++)
      if (isdigit(c) == 0)
        error++;
    break;
  case 16:
    while(c = *s++)
      if (isxdigit(c) == 0)
        error++;
    break;
  }
  if (error) {
    snprintf(error_buf, sizeof error_buf, "Invalid numeric value: %s", p);
    yyerror(error_buf, ERR_NONFATAL);
    return 0;
  }
  return 1;
}

static int  
numeric(char *s)
{
  char c;

  while (c = *s++)
    if (isdigit(c) == 0)
      return 0;

  return 1;
}

/*+
 * valid_name
 *
 *  Determine whether a name conforms to the lexical structure of
 *  the language
 *
 *  int
 *  valid_name(name)
 *
 *    char  *name;    The name to be checked.
 *
 *  Returns:  Non-zero if it's ok. Zero if it is not.
-*/

int
valid_name(char *name)
{
  static char expbuf[BUFSIZ];
  static int compiled = 0;

  if (compiled == 0) {
    compile("^[a-z,A-Z,_][a-z,A-Z,0-9,_,$]*$", expbuf, expbuf + BUFSIZ);
    compiled++;
  }

  return step(name, expbuf);
}

static int  
escapeChar(void)
{
  char buf[32];
  int i;
  int base;
  int c = getC();

  switch (c) {
  case 'b':
    return '\b';
  case 'f':
    return '\f';
  case 'n':
    return '\n';
  case 't':
    return '\t';
  case 'r':
    return '\r';
  case '0':
  case 'x':
    base = (c == '0') ? 8 : 16;
    for(i = 0; (c = getC()) && (i < sizeof buf); i++) {
      if (((base == 8)  && ((c < '0') || (c > '7'))) ||
          ((base == 16) && (isxdigit(c) == 0))) {
        UNGETCHAR();
        break;
      }
      buf[i] = c;
    }
    buf[i] = '\0';
    return strtol(buf, 0, base);
  default:
    return c;
  }
}

char *
se_kill_double_quotes(char *p)
{
  /* skip past the " */
  if (*p == '"') {
    p++;

    /* kill the trailing " */
    p[strlen(p) - 1] = '\0';
  }
  return p;
}

static void
check_for_line_no(void)
{
  static char first_file[BUFSIZ];
  char *p;
  int n;

  if (first_file[0] == '\0')
    strcpy(first_file, Lex_currentFile);

  /* blow off the # */
  (void) strtok(Currline, " ");

  /* grab the line number */
  p = strtok((char *) 0, " ");
  if (p == 0)
    return;
  n = atoi(p);

  /* get the file name */
  p = strtok((char *) 0, " ");
  if (p == 0)
    return;

  p = se_kill_double_quotes(p);

  if (*p) {
    strcpy(Lex_currentFile, p);
  } else {
    strcpy(Lex_currentFile, first_file);
  }
  Lex_line_no = n - 1;
}

/*
 * Determine:  {int} [. {int}] [e|E [+|-] {int}]
 */

static int
is_real(char *s)
{
  char buf[128];
  char tmp[128];
  char *p;
  char *decimal;
  char *signedint;
  int tok;
 
  /* 0.0 is ok but .0 is garbage.  */
  if ((s == 0) || (*s == 0) || (*s == '.'))
    return 0;
 
  /* skip 0x digits right out of the chute */
  if (s[0] == '0' && (s[1] == 'x' || s[1] == 'X'))
    return 0;
 
  /* hunt down the decimal if any */
  strcpy(buf, s);
  decimal = strchr(buf, '.');
  if (decimal) {
 
    /* 0.0 is ok but 0. is garbage.  */
    if (decimal[1] == 0)
      return 0;

    *decimal++ = '\0';

    p = decimal;
  } else {
    p = buf;
    decimal = "False";
  }
 
  /* is this a int[.int] (e|E) [+|-] int */
  if ((signedint = strchr(p, 'e')) ||
      (signedint = strchr(p, 'E'))) {

    *signedint++ = '\0';
    decimal = "0";
 
    tok = lex();
    if ((tok == PLUS) || (tok == MINUS)) {
      (void) lex();
      if (numeric(Lex_currtok) == 0)
        return 0;
    } else {
      /* end of input stream stdin */
      if (peekC() == 0)
        return 0;
 
      /* blow the line away */
      SKIP();
      return 0;
    }
 
    strcpy(tmp, Lex_currtok);
    snprintf(Lex_currtok, sizeof Lex_currtok,
      "%s.%se%c%s", buf, decimal, (tok == PLUS) ? '+' : '-', tmp);
  }
  return numeric(buf) && numeric(decimal);
}
