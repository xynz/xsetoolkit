/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <stdarg.h>
#include <string.h>
#include <errno.h>
#include <dirent.h>
#include <fcntl.h>
#include <regexpr.h>
#include <sys/utsname.h>
#ifdef USE_LICENSE
#include <sys/uio.h>
#include <sys/stat.h>
#include <sys/systeminfo.h>
#include <sys/mman.h>
#include "nilib.h"
#include "nicmd.h"
#include "md5/code.h"
#endif
#include "avl.h"
#include "se.h"
#include "se-parser.h"

#define MAX_DISK_COUNT 256

int            Se_kvm_open_flags;
int            Se_kvm_var_count;
int            Se_mib_var_count;
int            Se_kstat_var_count;

avlhdr        *Se_symbol_table;
int            Se_errors;
int            Se_flags;
char          *Se_programName;
char          *Se_basedir;
int            Se_type_sizes[VAR_BOGUS + 1];
int            Se_os_version;

/* for kvm */
char          *Se_core_file = 0;
char          *Se_kernel = 0;
char          *Se_paging_file = 0;

/* license schtuff */
static int lssd;  /* license server socket descriptor */

static void  usage(void);
static void  show_flags(void);
static void  cpp_append(char *, int, ...);
static int   has_patch_or_newer(char *, int);
static void  release_rtu(void);

int main(int argc, char *argv[])
{
  char tmp[BUFSIZ];
  char cwd[BUFSIZ];
  char cpp_cmd[BUFSIZ];
#if it_worked
  char ehost[1024];
#endif
  char *disk_names[MAX_DISK_COUNT];
  char hostid[64];
  char *p;
  char *q;
  char *se_include;
  char *file_name = 0;
  char *tag_name = 0;
  char **x_argv;
  char *output_file;
  char *command;
  int x_argc = 1;
  int i;
  int j;
  int k;
  int first;
  int rtu;
  int key_rtu;
  int disk_count = 0;
  int minor_version;
  int acquired = 0;
  struct utsname ubuf;
  FILE *input;
#ifdef USE_LICENSE
  struct iovec result;
  unsigned char checksum[16];
  unsigned char key[16];
  char processor[128];
  char license_host[128];
  struct stat stbuf;
  int fd;
  lsd_t lsd;
#endif
  extern double Se_version;
#ifdef YYDEBUG
  extern int yydebug;

  yydebug = 1;
#endif
  setegid(getgid());
  memset(Se_type_sizes, '\0', sizeof Se_type_sizes);
  if (uname(&ubuf) < 0) {
    perror("uname");
    exit(1);
  }
  p = strchr(ubuf.release, '.');
  *p++ = '\0';
  minor_version = atoi(p) * 10;
  Se_os_version = (atoi(ubuf.release) * 100) + minor_version;

  if (Se_os_version < 560) {
    fputs("se requires Solaris 2.6 or newer\n", stderr);
    exit(1);
  }

  Se_programName = argv[0];
  x_argv = (char **) se_alloc(argc * sizeof(char *));
  strcpy(cpp_cmd, CPP_CMD);

  for(i=1; i<argc; i++) {
    if ((argv[i][0] != '-') || (strcmp(argv[i], "-") == 0) || file_name) {
      if (file_name == 0) {
        if (strcmp(argv[i], "-")) {
          file_name = argv[i];
          x_argv[0] = file_name;
        } else {
          file_name = "stdin";
          x_argv[0] = file_name;
        }
      } else {
        for(k=1, j=i; j<argc; j++, k++)
          x_argv[k] = argv[j];
        x_argc = argc - (i - 1);
        i = argc;
      }
      continue;
    }
    for(j=1; argv[i][j]; j++)
      switch(argv[i][j]) {
      case 'c':
        Se_core_file = &argv[i][j+1];
        j = strlen(argv[i]) - 1;
        break;
      case 'd':
        Se_flags |= SE_DEBUG;
        break;
      case 'f':
        if (strcmp(argv[i], "-flags") == 0) {
          show_flags();
          break;
        }
        usage();
        break;
      case 'k':
        Se_kernel = &argv[i][j+1];
        j = strlen(argv[i]) - 1;
        break;
      case 'n':
        Se_flags |= SE_NO_CPP;
        break;
      case 'p':
        Se_paging_file = &argv[i][j+1];
        j = strlen(argv[i]) - 1;
        break;
      case 's':
        Se_flags |= SE_SYNTAX;
        break;
      case 't':
        tag_name = &argv[i][j+1];
        j = strlen(argv[i]) - 1;
        break;
      case 'v':
        version();
        exit(0);
      case 'w':
        Se_flags |= SE_WARNING;
        break;
      case 'z':
        Se_flags |= SE_VANISHED;
        break;
      case 'I':
        p = &argv[i][0];
        cpp_append(cpp_cmd, sizeof cpp_cmd, " ", p, 0);
        j = strlen(argv[i]) - 1;
        break;
      case 'D':
      case 'U':
        cpp_append(cpp_cmd, sizeof cpp_cmd, " ", argv[i], 0);
        j = strlen(argv[i]) - 1;
        break;
      case 'o':
        output_file = &argv[i][j+1];
        j = strlen(argv[i]) - 1;
        Se_flags |= SE_GENERATE;
        break;
      default:
        usage();
        break;
      }
  }
  se_include = getenv("SEINCLUDE");
  if (se_include) {
    se_include = se_string_save(se_include);
    for(p=strtok(se_include, ":"); p; p=strtok(0, ":"))
      cpp_append(cpp_cmd, sizeof cpp_cmd, " ", "-I", p, 0);
    se_free(se_include);
  }

  if ((Se_flags & SE_NO_CPP) == 0) {
    snprintf(tmp, sizeof tmp,
      " -I%s -D%s -DMINOR_VERSION=%d -DSE_VERSION=%d",
      DEFAULT_SE_INCLUDE, ubuf.machine, minor_version,
      (int) (Se_version * 100));
    cpp_append(cpp_cmd, sizeof cpp_cmd, tmp, 0);
  }

  /* find the se base dir */
  Se_basedir = DEFAULT_SE_BASEDIR;
  for(first = 1;; first = 0) {
    p = se_basedir(Se_programName, first);
    if (p == 0)
      break;
    if (strcmp(p, ".") == 0) {
      if (getcwd(cwd, sizeof cwd) == 0)
        yyerror("cannot get working directory", ERR_FATAL);
      p = cwd;
    }
    /* se_basedir returns the bin path, /opt/RICHPse/bin */
    snprintf(tmp, sizeof tmp, "%s/../bin/se", p);
    if (access(tmp, F_OK) == 0) {
      if (q = strrchr(p, '/'))
        *q = '\0';
      Se_basedir = se_string_save(p);
      break;
    }
  }

#ifdef USE_LICENSE
  /* read the license file */
  snprintf(tmp, sizeof tmp, "%s/etc/license", Se_basedir);
  if (selic_read(tmp, &lsd))
    yyerror("cannot read license file", ERR_FATAL);

#if it_worked
  /* check for unlimited license */
  selic_ename(lsd.host, ehost, sizeof ehost);
  selic_encode(ehost, 249249, checksum, -1);
#else
  memset(checksum, '\0', sizeof checksum);
#endif
  if (memcmp(lsd.l_key, checksum, 16)) {

    /* get license host */
    strcpy(license_host, lsd.host);

    /* contact license server */
    lssd = NiClientInit(argv[0], license_host, LICENSE_PORT);
    if (lssd == -1)
      yyerror("cannot connect to license host", ERR_FATAL);

    /* request binary checksum */
    sysinfo(SI_ARCHITECTURE, processor, sizeof(processor));
    snprintf(tmp, sizeof tmp, GET_BINARY_CHECKSUM, processor);
    if (NiSendCmd(lssd, tmp, 0, &result, NiFUNC) == -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("license server failure", ERR_FATAL);
    }

    /* correct data? */
    if (result.iov_base == 0 || result.iov_len != 16) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("invalid license data", ERR_FATAL);
    }

    /* open binary */
    if (*argv[0] == '/')
      strcpy(tmp, argv[0]);
    else
      snprintf(tmp, sizeof tmp, "%s/bin/%s", Se_basedir, argv[0]);
    fd = open(tmp, O_RDONLY);
    if (fd == -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 1", ERR_FATAL);
    }

    /* get size */
    if (fstat(fd, &stbuf) == -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 2", ERR_FATAL);
    }

    /* mmap it */
    p = (char *) mmap(0, stbuf.st_size, PROT_READ, MAP_SHARED, fd, 0);
    if (p == (char *) -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 3", ERR_FATAL);
    }

    /* checksum it */
    md5_buffer(p, stbuf.st_size, checksum);
    munmap(p, stbuf.st_size);
    close(fd);

    /* compare */
    if (memcmp(result.iov_base, checksum, 16) != 0) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("invalid se binary", ERR_FATAL);
    }

    result.iov_base = 0;
    result.iov_len  = 0;

    /* get hostid */
    if (NiSendCmd(lssd, GET_HOSTID, 0, &result, NiFUNC) == -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 4", ERR_FATAL);
    }

    /* correct data? */
    if (result.iov_base == 0) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 5", ERR_FATAL);
    }

    strncpy(hostid, result.iov_base, result.iov_len);
    hostid[result.iov_len] = '\0';

    result.iov_base = 0;
    result.iov_len  = 0;

    /* get key */
    if (NiSendCmd(lssd, GET_KEY, 0, &result, NiFUNC) == -1) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 6", ERR_FATAL);
    }

    /* correct data? */
    if (result.iov_base == 0 || result.iov_len != 16) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 7", ERR_FATAL);
    }

    memcpy(key, result.iov_base, 16);

    result.iov_base = 0;
    result.iov_len  = 0;

    /* get rtu */
    snprintf(tmp, sizeof tmp, GET_RTU, sysconf(_SC_NPROCESSORS_CONF));
    do {
      switch(NiSendCmd(lssd, tmp, 0, &result, NiFUNC)) {
      case -1:
        NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
        close(lssd);
        yyerror("internal error: m: 8", ERR_FATAL);
        break;
      case SELIC_NOT_ENOUGH:
        yyerror("waiting for sufficient licenses to become free", ERR_WARNING);
        sleep(5);
        break;
      case SELIC_NEVER_ENOUGH:
        yyerror("insufficient licenses", ERR_FATAL);
        break;
      case SELIC_OK:
        acquired = 1;
        break;
      }
    } while(acquired == 0);

    /* correct data? */
    if (result.iov_base == 0) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("internal error: m: 9", ERR_FATAL);
    }

    memcpy(tmp, result.iov_base, result.iov_len);
    tmp[result.iov_len] = '\0';
    rtu = atoi(tmp);

    selic_encode(license_host, (unsigned int) strtoul(hostid, 0, 16),
                 checksum, rtu);
    key_rtu = selic_decode(key);

    if ((key_rtu != rtu) || memcmp(checksum, key, 16)) {
      NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
      close(lssd);
      yyerror("invalid license key", ERR_FATAL);
    }

    atexit(release_rtu);
  } else {
    /* which passes to se_init_internals which sets the statics to zip */
    memset(checksum, '\0', 16);
    memset(key, '\0', 16);
  }
#endif

  /* process the se_defines file */
  snprintf(tmp, sizeof tmp, "%s/etc/se_defines", Se_basedir);
  input = fopen(tmp, "r");
  if (input) {
    while(fgets(tmp, sizeof tmp, input)) {
      if (tmp[0] == '#')
        continue;
      if (p = strchr(tmp, '\n'))
        *p = '\0';
      if (tmp[0] == '\0')
        continue;
      command = strtok(tmp, " \t");
      if (command == 0)
        continue;
      if (strcmp(command, "patch") == 0) {
        char *patch;
        char *rev;
        char *define;

        patch = strtok(0, " \t");
        if (patch == 0)
          continue;
        rev = strtok(0, " \t");
        if (rev == 0)
          continue;
        define = strtok(0, " \t");
        if (define == 0)
          continue;
        if (has_patch_or_newer(patch, atoi(rev)))
          cpp_append(cpp_cmd, sizeof cpp_cmd, " ", define, 0);
      } else if (strcmp(command, "driver") == 0) {
        char regline[BUFSIZ];
        char expbuf[BUFSIZ];
        char dline[BUFSIZ];
        char *driver;
        char *regexp;
        char *define;
        FILE *modinfo;

        driver = strtok(0, " \t");
        if (driver == 0)
          continue;
        regexp = strtok(0, " \t");
        if (regexp == 0)
          continue;
        define = strtok(0, " \t");
        if (define == 0)
          continue;
        snprintf(regline, sizeof regline, "%s.*%s", driver, regexp);
        compile(regline, expbuf, expbuf + BUFSIZ);
        modinfo = popen("/usr/sbin/modinfo", "r");
        if (modinfo == 0)
          continue;
        while(fgets(dline, sizeof dline, modinfo)) {
          if (p = strchr(dline, '\n'))
            *p = '\0';
          if (step(dline, expbuf)) {
            cpp_append(cpp_cmd, sizeof cpp_cmd, " ", define, 0);
            break;
          }
        }
        pclose(modinfo);
      } else if (strcmp(command, "disk") == 0) {
        char *name;

        if (disk_count == MAX_DISK_COUNT)
          yyerror("Too many disk names in se_defines", ERR_FATAL);
        name = strtok(0, " \t");
        if (name == 0)
          continue;
        disk_names[disk_count++] = se_string_save(name);
      }
    }
    fclose(input);
  }

  /* free the patch list */
  has_patch_or_newer(0, 0);

#ifdef _LP64
  cpp_append(cpp_cmd, sizeof cpp_cmd, " ", "-D_LP64", 0);
#endif

  /* the program must have some clue what it's name is */
  if ((file_name == 0) || (strcmp(file_name, "stdin") == 0)) {
    file_name = 0;
    if (tag_name)
      x_argv[0] = tag_name;
    else
      x_argv[0] = "stdin";
  }

  /* fire up the scanner and parser */
  if (Se_flags & SE_NO_CPP)
    se_lex_init(file_name, 0);
  else
    se_lex_init(file_name, cpp_cmd);
  se_parse_init();

  /* go get 'em */
  yyparse();
  if (Se_errors)
    yyerror("Errors detected.  Exiting.", ERR_LATER);

  /* syntax check only */
  if (Se_flags & SE_SYNTAX)
    exit(0);
  se_lex_end();

  if (Se_flags & SE_GENERATE) {
    se_generate(output_file);
    exit(0);
  }

  /* init special variables */
#ifdef USE_LICENSE
  se_init_internals(checksum, key);
#endif
  se_init_kvm();
  se_init_kstat();
  se_init_mib();
  se_init_ndd();

  if (disk_count) {
    for(i=0; i<disk_count; i++) {
      se_add_disk_name(disk_names[i]);
      se_free(disk_names[i]);
    }
  }

  /* go get 'em again */
  if (Se_flags & SE_DEBUG)
    setbuf(stdout, 0);
  errno = 0;
  i = se_run(x_argc, x_argv);

  /* close things up */
  se_end_kvm();
  se_end_kstat();
  se_end_mib();
  se_end_ndd();

  exit(i);
}

#if USE_LICENSE
static void
release_rtu(void)
{
  NiSendCmd(lssd, TTFN, 0, 0, NiPROC);
  close(lssd);
}
#endif

static void
usage(void)
{
  fprintf(stderr, "Usage: %s [ options ].  Use '%s -flags' for details.\n",
                  Se_programName, Se_programName);
  exit(1);
}

static void
show_flags(void)
{
  putc('\n', stderr);
  version();
  putc('\n', stderr);
  fprintf(stderr, "Usage:\t%s\n", Se_programName);
  fputs("\t[-dnsvwz]\n",              stderr);
  fputs("\t[-ccore-file] [-kkernel-file] [-ppaging-file]\n", stderr);
  fputs("\t[-Iinclude-directory] [-Ddefine] [-Uundefine]\n",    stderr);
  fputs("\t[-o- | -ooutput-file]\n", stderr);
  fputs("\t[script-name | -] [script-args]\n", stderr);
  putc('\n', stderr);
  fputs("\t-d  Run in debug mode\n",               stderr);
  fputs("\t-n  Run without the pre-processor\n",   stderr);
  fputs("\t-s  Syntax check only\n",               stderr);
  fputs("\t-v  Display the version\n",             stderr);
  fputs("\t-w  Suppress warning messages\n",       stderr);
  fputs("\t-z  Complain about vanished members\n", stderr);
  putc('\n', stderr);
  fputs("\t-ccore-file          Specify core file for kvm variables\n",
    stderr);
  fputs("\t-kkernel-file        Specify kernel file for kvm variables\n",
    stderr);
  fputs("\t-ppaging-file        Specify paging file for kvm variables\n",
    stderr);
  putc('\n', stderr);
  fputs("\t-Iinclude-directory  Add an include directory to the search path\n",
    stderr);
  fputs("\t-Ddefine             Define a symbol for the pre-processor\n",
    stderr);
  fputs("\t-Uundefine           Undefine a symbol for the pre-processor\n",
    stderr);
  putc('\n', stderr);
  fputs("\t-o-                  Regenerate a minimal script to stdout\n",
    stderr);
  fputs("\t-ooutput-file        Regenerate a minimal script to output-file\n",
    stderr);
  putc('\n', stderr);
  fputs("\t-       Input is stdin followed (optionally) by script flags\n",
        stderr);
  fputs("\t-t tag  Names the program when stdin is used\n", stderr);
  putc('\n', stderr);
  exit(0);
}

static void
cpp_append(char *cpp_cmd, int cpp_size, ...)
{
  va_list args;
  char *p;
  int len;

  va_start(args, cpp_size);
  len = strlen(cpp_cmd);
  for(p=va_arg(args, char *); p; p=va_arg(args, char *)) {
    len += strlen(p);
    if (len >= cpp_size)
      yyerror("too many command line arguments", ERR_FATAL);
    strcat(cpp_cmd, p);
  }
  va_end(args);
}

static int
has_patch_or_newer(char *patch, int rev)
{
  typedef struct _patch patch_t;
  struct _patch {
    char    *patch;
    int      rev;
    patch_t *next;
  };
  static patch_t *patch_list;
  patch_t *pp;
  char *p;
  int has_patch = 0;
  int n;
  DIR *dirp;
  struct dirent *dp;

  /* request to free the list */
  if (patch == 0) {
    for(pp=patch_list; pp; pp=patch_list) {
      patch_list = pp->next;
      se_free(pp->patch);
      se_free(pp);
    }
    return 0;
  }

  /* build the list */
  if (patch_list == 0) {
    dirp = opendir("/var/sadm/patch");
    if (dirp == 0)
      return 0;
    while(dp = readdir(dirp)) {
      if (dp->d_name[0] == '.')
        continue;
      p = strchr(dp->d_name, '-');
      if (p == 0)
        continue;
      *p++ = '\0';
      pp = NEW(patch_t);
      pp->next = patch_list;
      patch_list = pp;
      pp->patch = se_string_save(dp->d_name);
      pp->rev = atoi(p);
    }
    closedir(dirp);
  }

  /* search the list */
  for(pp=patch_list; pp; pp=pp->next) {
    if (strcmp(patch, pp->patch) == 0) {
      has_patch = (pp->rev >= rev);
      break;
    }
  }

  return has_patch;
}
