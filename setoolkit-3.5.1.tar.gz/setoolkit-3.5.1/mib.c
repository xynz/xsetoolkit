/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <stropts.h>
#include <fcntl.h>
#include <errno.h>
#include <sys/stream.h>
#include <sys/stropts.h>
#include <sys/socket.h>
#include <sys/tihdr.h>
#include <sys/tiuser.h>
#include <inet/led.h>
#include <inet/mib2.h>
#include <netinet/igmp_var.h>
#include "avl.h"
#include "se.h"

#define DEV_ARP     "/dev/arp"
#define ARP_MODULE  "arp"
#define TCP_MODULE  "tcp"
#define UDP_MODULE  "udp"
#define ICMP_MODULE "icmp"

typedef struct _map T_MAP;
struct _map {
  char   *m_type_name;      /* type name from include file         */
  void   *m_area;           /* pointer to mib2 struct              */
};

static mib2_ip_t   ip_struct;
static mib2_icmp_t icmp_struct;
static mib2_tcp_t  tcp_struct;
static mib2_udp_t  udp_struct;
static int mib_sd = -1;

/* ordered by the likelihood of their access */
static T_MAP mib_types[] = {
  { "mib2_tcp_t",   (void *) &tcp_struct  },
  { "mib2_ip_t",    (void *) &ip_struct   },
  { "mib2_udp_t",   (void *) &udp_struct  },
  { "mib2_icmp_t",  (void *) &icmp_struct },
  { 0,              (void *) 0            }
};

void
se_init_mib(void)
{
  static int told_em = 0;

  if ((Se_mib_var_count == 0) || (mib_sd != -1))
    return;
  setegid(SYS_GID);
  mib_sd = open(DEV_ARP, O_RDWR);
  if (mib_sd == -1) {
    if (told_em == 0) {
      se_warning("cannot open %s", DEV_ARP);
      told_em = 1;
    }
    return;
  }
  if (ioctl(mib_sd, I_PUSH, TCP_MODULE) == -1)
    se_fatal("cannot push %s module", TCP_MODULE);
  if (ioctl(mib_sd, I_PUSH, UDP_MODULE) == -1)
    se_fatal("cannot push %s module", UDP_MODULE);
  if (Se_os_version >= 580)
    if (ioctl(mib_sd, I_PUSH, ICMP_MODULE) == -1)
      se_fatal("cannot push %s module", ICMP_MODULE);
  setegid(getgid());
}

static void
refresh_mib(void)
{
  static char *trash;
  static int trash_size;
  char buf[BUFSIZ];
  int flags;
  int n;
  void *p;
  struct strbuf control;
  struct strbuf data;
  struct T_optmgmt_req *req_opt = (struct T_optmgmt_req *) buf;
  struct T_optmgmt_ack *ack_opt = (struct T_optmgmt_ack *) buf;
  struct T_error_ack   *err_opt = (struct T_error_ack *)   buf;
  struct opthdr *req_hdr;
  static int told_em = 0;

  if (mib_sd == -1) {
    if (told_em == 0) {
      se_warning("Mib not initialized: Variables will have invalid values");
      told_em = 1;
    }
    return;
  }

  setegid(SYS_GID);
  req_opt->PRIM_type = T_OPTMGMT_REQ;
  req_opt->OPT_offset = sizeof(struct T_optmgmt_req);
  req_opt->OPT_length = sizeof(struct opthdr);
  req_opt->MGMT_flags = T_CURRENT;

  req_hdr = (struct opthdr *) &req_opt[1];
  req_hdr->level = MIB2_IP;
  req_hdr->name  = 0;
  req_hdr->len   = 0;

  control.buf = buf;
  control.len = req_opt->OPT_length + req_opt->OPT_offset;
  if (putmsg(mib_sd, &control, 0, 0) == -1)
    se_fatal("cannot send control message");

  req_hdr = (struct opthdr *) &ack_opt[1];
  control.maxlen = sizeof buf;

  for (;;) {
    flags = 0;
    n = getmsg(mib_sd, &control, 0, &flags);
    if (n == -1)
      se_fatal("cannot read control message");

    /* end of data? */
    if ((n == 0) && (control.len >= sizeof(struct T_optmgmt_ack)) &&
        (ack_opt->PRIM_type == T_OPTMGMT_ACK) &&
        (ack_opt->MGMT_flags == T_SUCCESS) &&
        (req_hdr->len == 0))
      break;

    if ((control.len >= sizeof(struct T_error_ack)) &&
         err_opt->PRIM_type == T_ERROR_ACK)
      se_fatal("error reading control message");

    if ((n != MOREDATA) || (control.len < sizeof(struct T_optmgmt_ack)) ||
         (ack_opt->PRIM_type != T_OPTMGMT_ACK) ||
         (ack_opt->MGMT_flags != T_SUCCESS))
      se_fatal("invalid control message received");

    /* cause the default case to happen */
    if (req_hdr->name != 0)
      req_hdr->level = -1;

    switch(req_hdr->level) {
    case MIB2_IP:
      p = &ip_struct;
      break;
    case MIB2_ICMP: 
      p = &icmp_struct;
      break;
    case MIB2_TCP: 
      p = &tcp_struct;
      break;
    case MIB2_UDP: 
      p = &udp_struct;
      break;
    default:
      if ((trash == 0) || (req_hdr->len > trash_size)) {
        if (trash)
          se_free(trash);
        trash = (char *) se_alloc(req_hdr->len);
        trash_size = req_hdr->len;
      }
      p = trash;
      break;
    }

    data.maxlen = req_hdr->len;
    data.buf    = (char *) p;
    data.len    = 0;
    flags = 0;

    n = getmsg(mib_sd, 0, &data, &flags);
    if (n != 0)
      se_fatal("error reading data");
  }
  setegid(getgid());
}

void
se_refresh_mib_variable(T_VARIABLE *vp)
{
  char *name;
  T_MAP *mp;
  T_VARIABLE *vvp;

  /* obviously, called by an initialization in the parser. */
  if (mib_sd == -1)
    se_init_mib();

  /* sanity check before reading the stream */
  if (vp->var_type != VAR_USER)
    vp = vp->var_parent;
  if ((vp == 0) || (vp->var_type != VAR_USER))
    return;
  name = vp->var_struct->st_name;
  for(mp=mib_types; mp->m_type_name; mp++)
    if (strcmp(mp->m_type_name, name) == 0)
      break;
  if (mp->m_type_name == 0)
    return;

  /* read the stream */
  refresh_mib();

  /* dump */
  se_area_into_struct(mp->m_area, vp);
}

void
se_end_mib(void)
{
  if (mib_sd != -1)
    close(mib_sd);
}
