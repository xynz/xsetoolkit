/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _RAPS_perf_tools_ndd_h_
#define _RAPS_perf_tools_ndd_h_

typedef enum ndd_data_t { ND_LONG, ND_STRING };

class ndd_t {
private:
  char *ndd_buf;
  int   ndd_buf_size;
  int   dev_sd;

  void *ndd_get_set(char *name, void *data, ndd_data_t type, int cmd);

public:
  ndd_t(char *dev_name);
 ~ndd_t();

  long ndd_get_long(char *name);
  char *ndd_get_string(char *name);

  int ndd_set(char *name, long value);
  int ndd_set(char *name, char *value);

  void ndd_set_buf_size(int size);
};

#endif
