/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <regex.h>
#include <sys/types.h>
#include <time.h>
#include <signal.h>
#include <syslog.h>
#include <math.h>
#include <dirent.h>
#include <sys/param.h>
#include <sys/utsname.h>
#include <sys/processor.h>
#include <sys/stat.h>
#include <sys/time.h>
#include "avl.h"
#include "se.h"

#define MAX_DOTS    256		/* oh well */
#define MAX_ARGS    256		/* well oh */

#define MIN(A, B)  (((A) < (B)) ? (A) : (B))

#define SIGNAL_DEFAULT    "@default"
#define SIGNAL_IGNORE     "@ignore"

#if defined(_LP64)
# if defined(_BIG_ENDIAN)
#  define _PARAM_(x) \
    (((Se_type_sizes[x.var_type] < 8) && \
      (Se_type_sizes[x.var_type] > 0)) && (x.var_dimension == 0) ? \
        (x.var_un.var_uldigit >> 32) : (x.var_un.var_uldigit))
# else
#  define _PARAM_(x) (x.var_un.var_uldigit)
# endif
#else
# define _PARAM_(x) (x.var_un.var_udigit)
#endif

typedef enum {
  PRINTF_TYPE,
  FPRINTF_TYPE,
  SPRINTF_TYPE,
  SYSLOG_TYPE
} T_INTF;

/* for breaking or continuing for or while loops */
#define DO_BREAK    1
#define DO_CONTINUE 2

static void run_block              (T_BLOCK *volatile);
static void run_class              (T_VARIABLE *);
static void run_statement_list     (T_STATEMENT *);
static void run_if                 (T_STATEMENT *);
static void run_printf             (T_STATEMENT *);
static void run_call               (T_STATEMENT *);
static void run_while              (T_STATEMENT *);
static void run_assign             (T_STATEMENT *);
static void run_increment          (T_STATEMENT *);
static void run_decrement          (T_STATEMENT *);
static void run_attachment         (T_STATEMENT *);
static void run_for                (T_STATEMENT *);
static void run_do                 (T_STATEMENT *);
static void run_switch             (T_STATEMENT *);
static void run_return             (T_STATEMENT *);
static void run_break              (T_STATEMENT *);
static void run_continue           (T_STATEMENT *);
static void run_itoa               (T_STATEMENT *);
extern void run_first_proc         (T_STATEMENT *);
extern void run_next_proc          (T_STATEMENT *);
extern void run_get_proc           (T_STATEMENT *);
static void run_fprintf            (T_STATEMENT *);
static void run_sprintf            (T_STATEMENT *);
static void run_signal             (T_STATEMENT *);
static void run_debug_on           (T_STATEMENT *);
static void run_debug_off          (T_STATEMENT *);
static void run_fileno             (T_STATEMENT *);
static void run_syslog             (T_STATEMENT *);
static void run_sizeof             (T_STATEMENT *);
static void run_kvm_cvt            (T_STATEMENT *);
static void run_kvm_address        (T_STATEMENT *);
static void run_struct_fill        (T_STATEMENT *);
static void run_struct_empty       (T_STATEMENT *);
static void run_lazy_value         (T_STATEMENT *);
static void run_lazy_lvalue        (T_STATEMENT *);
static void run_indirection        (T_STATEMENT *);
static void run_address_of         (T_STATEMENT *);
static void run_kvm_declare        (T_STATEMENT *);
static void run_type_cast          (T_STATEMENT *);
static void run_qsort              (T_STATEMENT *);
static void run_atexit             (T_STATEMENT *);
static void run_bsearch            (T_STATEMENT *);
static void run_refresh            (T_STATEMENT *);
static void run_new                (T_STATEMENT *);
static void run_null               (T_STATEMENT *);
static void run_renew              (T_STATEMENT *);

/* math */
static void run_acos               (T_STATEMENT *);
static void run_acosh              (T_STATEMENT *);
static void run_asin               (T_STATEMENT *);
static void run_asinh              (T_STATEMENT *);
static void run_atan               (T_STATEMENT *);
static void run_atan2              (T_STATEMENT *);
static void run_atanh              (T_STATEMENT *);
static void run_cbrt               (T_STATEMENT *);
static void run_ceil               (T_STATEMENT *);
static void run_copysign           (T_STATEMENT *);
static void run_cos                (T_STATEMENT *);
static void run_cosh               (T_STATEMENT *);
static void run_erf                (T_STATEMENT *);
static void run_erfc               (T_STATEMENT *);
static void run_exp                (T_STATEMENT *);
static void run_expm1              (T_STATEMENT *);
static void run_fabs               (T_STATEMENT *);
static void run_floor              (T_STATEMENT *);
static void run_fmod               (T_STATEMENT *);
static void run_frexp              (T_STATEMENT *);
static void run_gamma              (T_STATEMENT *);
static void run_gamma_r            (T_STATEMENT *);
static void run_hypot              (T_STATEMENT *);
static void run_ilogb              (T_STATEMENT *);
static void run_isnan              (T_STATEMENT *);
static void run_j0                 (T_STATEMENT *);
static void run_j1                 (T_STATEMENT *);
static void run_jn                 (T_STATEMENT *);
static void run_ldexp              (T_STATEMENT *);
static void run_lgamma             (T_STATEMENT *);
static void run_lgamma_r           (T_STATEMENT *);
static void run_log                (T_STATEMENT *);
static void run_log10              (T_STATEMENT *);
static void run_log1p              (T_STATEMENT *);
static void run_logb               (T_STATEMENT *);
static void run_matherr            (T_STATEMENT *);
static void run_modf               (T_STATEMENT *);
static void run_nextafter          (T_STATEMENT *);
static void run_pow                (T_STATEMENT *);
static void run_remainder          (T_STATEMENT *);
static void run_rint               (T_STATEMENT *);
static void run_scalb              (T_STATEMENT *);
static void run_scalbn             (T_STATEMENT *);
static void run_significand        (T_STATEMENT *);
static void run_sin                (T_STATEMENT *);
static void run_sinh               (T_STATEMENT *);
static void run_sqrt               (T_STATEMENT *);
static void run_tan                (T_STATEMENT *);
static void run_tanh               (T_STATEMENT *);
static void run_y0                 (T_STATEMENT *);
static void run_y1                 (T_STATEMENT *);
static void run_yn                 (T_STATEMENT *);
static void run_readdir            (T_STATEMENT *);

static int   resolve_l_expression   (T_LEXPR *);
static int   compute_subscript      (T_VARIABLE *, int);
static void  resolve_expression     (T_VARIABLE *, T_EXPR *, int);
static void  do_structure_assignment(T_VARIABLE *, T_VARIABLE *, int);
static void  fix_type               (T_VARIABLE *, T_VARTYPE);
static void  initialize_variable    (T_VARIABLE *, T_EXPR *);
static void  init_globals           (anode *, int);
static void  struct_fill            (T_VARIABLE *, uchar_t *, int);
static void  struct_empty           (T_VARIABLE *, uchar_t *, int);
static char *expr_name              (T_EXPR *);
static T_VARIABLE *get_lazy_member  (T_VARIABLE *, T_VARIABLE *[]);

static char      **sig_functions;
static int         line_no;
static T_VARIABLE  zero_variable;
static T_ASSIGN    zero_assign;
static T_STATEMENT zero_statement;
static T_EXPR      zero_expr;
static T_FCALL     zero_fcall;
static T_BLOCK     zero_block;
static T_STACK     qsort_cmp_stack;
static T_STACK     atexit_stack;
static T_STACK     bsearch_cmp_stack;

#ifdef USE_LICENSE
/* force inequality */
static unsigned char ics[16] = { 0 };
static unsigned char ik[16] = { 1 };
#endif

#ifdef _USE_INTF
static ssize_t anprintf(char *, size_t, char *, T_VARTYPE *,
			unsigned long[], int);
#endif

void (*Se_functions[])(T_STATEMENT *) = {
  /* control structures */
  0,                   /* UNUSED=0             */
  run_if,              /* S_IF=1               */
  run_while,           /* S_WHILE=2            */
  run_for,             /* S_FOR=3              */
  run_do,              /* S_DO=4               */
  run_switch,          /* S_SWITCH=5           */
  run_return,          /* S_RETURN=6           */
  run_break,           /* S_BREAK=7            */
  run_continue,        /* S_CONTINUE=8         */
  0,                   /* UNUSED=9             */
  0,                   /* UNUSED=10            */

  /* statement types */
  run_call,            /* S_CALL=11            */
  run_assign,          /* S_ASSIGN=12          */
  run_increment,       /* S_INCREMENT=13       */
  run_decrement,       /* S_DECREMENT=14       */
  run_attachment,      /* S_ATTACHMENT=15      */
  run_address_of,      /* S_ADDR_OF=16         */
  run_lazy_value,      /* S_LAZY_VALUE=17      */
  run_lazy_lvalue,     /* S_LAZY_LVALUE=18     */
  run_indirection,     /* S_INDIRECT=19        */
  run_new,             /* S_NEW=20             */
  run_null,            /* S_NULL=21            */
  run_renew,           /* S_RENEW=22           */
  0,                   /* UNUSED=23            */
  0,                   /* UNUSED=24            */
  0,                   /* UNUSED=25            */
  0,                   /* UNUSED=26            */
  0,                   /* UNUSED=27            */
  0,                   /* UNUSED=28            */
  0,                   /* UNUSED=29            */
  0,                   /* UNUSED=30            */

  /* builtins */
  run_printf,          /* S_PRINTF=31          */
  run_itoa,            /* S_ITOA=32            */
  run_first_proc,      /* S_FIRST_PROC=33      */
  run_next_proc,       /* S_NEXT_PROC=34       */
  run_get_proc,        /* S_GET_PROC=35        */
  run_fprintf,         /* S_FPRINTF=36         */
  run_sprintf,         /* S_SPRINTF=37         */
  run_signal,          /* S_SIGFUNC=38         */
  run_debug_on,        /* S_DEBUG_ON=39        */
  run_debug_off,       /* S_DEBUG_OFF=40       */
  run_fileno,          /* S_FILENO=41          */
  run_syslog,          /* S_SYSLOG=42          */
  run_sizeof,          /* S_SIZEOF=43          */
  run_kvm_cvt,         /* S_KVM_CVT=44         */
  run_kvm_address,     /* S_KVM_ADDR=45        */
  run_struct_fill,     /* S_STRUCT_FILL=46     */
  run_struct_empty,    /* S_STRUCT_EMPTY=47    */
  run_kvm_declare,     /* S_KVM_DECLARE=48     */
  run_type_cast,       /* S_TYPE_CAST=49       */
  run_qsort,           /* S_QSORT=50           */
  run_atexit,          /* S_ATEXIT=51          */
  run_bsearch,         /* S_BSEARCH=52         */
  run_refresh,         /* S_REFRESH=53         */

  0,                   /* UNUSED=54            */
  0,                   /* UNUSED=55            */
  0,                   /* UNUSED=56            */
  0,                   /* UNUSED=57            */
  0,                   /* UNUSED=58            */
  0,                   /* UNUSED=59            */

  /* math */
  run_acos,            /* S_ACOS=60            */
  run_acosh,           /* S_ACOSH=61           */
  run_asin,            /* S_ASIN=62            */
  run_asinh,           /* S_ASINH=63           */
  run_atan,            /* S_ATAN=64            */
  run_atan2,           /* S_ATAN2=65           */
  run_atanh,           /* S_ATANH=66           */
  run_cbrt,            /* S_CBRT=67            */
  run_ceil,            /* S_CEIL=68            */
  run_copysign,        /* S_COPYSIGN=69        */
  run_cos,             /* S_COS=70             */
  run_cosh,            /* S_COSH=71            */
  run_erf,             /* S_ERF=72             */
  run_erfc,            /* S_ERFC=73            */
  run_exp,             /* S_EXP=74             */
  run_expm1,           /* S_EXPM1=75           */
  run_fabs,            /* S_FABS=76            */
  run_floor,           /* S_FLOOR=77           */
  run_fmod,            /* S_FMOD=78            */
  run_frexp,           /* S_FREXP=79           */
  run_gamma,           /* S_GAMMA=80           */
  run_gamma_r,         /* S_GAMMA_R=81         */
  run_hypot,           /* S_HYPOT=82           */
  run_ilogb,           /* S_ILOGB=83           */
  run_isnan,           /* S_ISNAN=84           */
  run_j0,              /* S_J0=85              */
  run_j1,              /* S_J1=86              */
  run_jn,              /* S_JN=87              */
  run_ldexp,           /* S_LDEXP=88           */
  run_lgamma,          /* S_LGAMMA=89          */
  run_lgamma_r,        /* S_LGAMMA_R=90        */
  run_log,             /* S_LOG=91             */
  run_log10,           /* S_LOG10=92           */
  run_log1p,           /* S_LOG1P=93           */
  run_logb,            /* S_LOGB=94            */
  run_matherr,         /* S_MATHERR=95         */
  run_modf,            /* S_MODF=96            */
  run_nextafter,       /* S_NEXTAFTER=97       */
  run_pow,             /* S_POW=98             */
  run_remainder,       /* S_REMAINDER=99       */
  run_rint,            /* S_RINT=100           */
  run_scalb,           /* S_SCALB=101          */
  run_scalbn,          /* S_SCALBN=102         */
  run_significand,     /* S_SIGNIFICAND=103    */
  run_sin,             /* S_SIN=104            */
  run_sinh,            /* S_SINH=105           */
  run_sqrt,            /* S_SQRT=106           */
  run_tan,             /* S_TAN=107            */
  run_tanh,            /* S_TANH=108           */
  run_y0,              /* S_Y0=109             */
  run_y1 ,             /* S_Y1=110             */
  run_yn,              /* S_YN=111             */
  run_readdir,         /* S_READDIR=112        */
  0
};

#ifdef USE_LICENSE
void
se_init_internals(unsigned char *checksum, unsigned char *key)
{
  memcpy(ics, checksum, 16);
  memcpy(ik, key, 16);
}
#endif

int
se_run(int argc, char **argv)
{
  int i;
  anode *anp;
  T_BLOCK *main;
  T_VARIABLE *vp;
  T_VARIABLE *vvp;
  extern jmp_buf ljb;
  extern jmp_buf lbj;
  jmp_buf zero;

#ifdef USE_LICENSE
  if (memcmp(ics, ik, 16))
    yyerror("invalid se binary", ERR_FATAL);
#endif

#ifdef _MEM_DEBUG
  se_mem_debug(-1);
#endif

  main = se_get_block("main");
  if (main == 0)
    se_fatal("main vanished!");

  sig_functions = (char **) se_alloc(_sys_nsig * sizeof(char *));
  for(i=0; i<_sys_nsig; i++)
    sig_functions[i] = SIGNAL_DEFAULT;

  /* initialize global variables */
  for(anp=avlfirst(Se_symbol_table); anp; anp=avlnext(Se_symbol_table, anp, 0))
    init_globals(anp, 1);
  /* initialize global classes */
  for(anp=avlfirst(Se_symbol_table); anp; anp=avlnext(Se_symbol_table, anp, 0))
    init_globals(anp, 0);

  /* this has been verified in the parser */
  if (main->b_parameters) {
    vp = main->b_parameters;
    vp->var_un.var_digit = argc;
    vp = vp->var_next;
    if (vp) {
      if (vp->var_un.var_array)
        se_free(vp->var_un.var_array);
      vp->var_dimension = argc;
      vp->var_un.var_array = (char **) se_alloc(argc * sizeof(char *));
      for(i=0; i<argc; i++)
        ((char **) vp->var_un.var_array)[i] = se_string_save(argv[i]);
      vp->var_flags &= ~VF_EMPTY;
      for(vvp=vp->var_instances; vvp; vvp=vvp->var_next) {
        vvp->var_dimension = argc;
        vvp->var_un.var_array = vp->var_un.var_array;
        vvp->var_flags &= ~VF_EMPTY;
      }
    }
  }

  run_block(main);
  if (main->b_return)
    return main->b_return->var_un.var_digit;
  return 0;
}

static void
run_block(T_BLOCK *volatile bp)
{
  T_VARIABLE *vp;

  /* no more of this */
  if (bp == 0)
    se_fatal("nil block");

  /* no recursion */
  if (bp->b_flags & B_ACTIVE)
    return;
  bp->b_flags |= B_ACTIVE;
  if (setjmp(bp->b_jmpbuf)) {
    bp->b_flags &= ~B_ACTIVE;
    return;
  }
  if ((bp->b_flags & B_INITIALIZED) == 0) {
    bp->b_flags |= B_INITIALIZED;
    for(vp=bp->b_variables; vp; vp=vp->var_next) {
      if (vp->var_initial) {
        initialize_variable(vp, vp->var_initial);
        continue;
      }
      if ((vp->var_flags & VF_SPECIAL) == VF_CLASS) {
        vp->var_struct->st_class->b_flags |= B_INITIAL_CALL;
        run_class(vp);
      }
    }
  }
  run_statement_list(bp->b_statements);
  bp->b_flags &= ~B_ACTIVE;
}

static void
run_class(T_VARIABLE *vp)
{
  T_STRUCT *declaration_locals = 0;
  T_STRUCT *declaration_members;
  T_BLOCK *class_block;
  T_VARIABLE declaration;
  T_VARIABLE *vvp;
  T_VARIABLE *top = vp;
  T_VARIABLE *fp;
  T_VARIABLE *tp;

  /* find the top */
  for(vvp=vp->var_parent; vvp; vvp=vvp->var_parent)
    top = vvp;

  /* class block code */
  class_block = top->var_struct->st_class;

  /* if it hasn't been initialized yet then do so now */
  if ((class_block->b_flags & B_INITIAL_CALL) == 0) {
    class_block->b_flags |= B_INITIAL_CALL;
    run_class(vp);
  }

  /* easy initializations */
  declaration = zero_variable;
  declaration.var_type = VAR_USER;

  /* use these variables to help make this code a little clearer */
  declaration_members = top->var_struct;
  if (top->var_struct->st_local_vars)
    declaration_locals = top->var_struct->st_local_vars->var_struct;

  /* before we start, we must update the class declaration with the values   *
   * from the variable that we're dealing with.  When the class code updates *
   * the member variables (which actually exist inside of the declaration)   *
   * they will have the correct initial values.                              *
   *                                                                         *
   * Note that the var_user is assigned the value of var_struct.  var_user   *
   * is the instance and var_struct is the declaration which is what the     *
   * class code will be updating.                                            */

  /* make var_user point at the declaration */
  declaration.var_un.var_user = declaration_members;

  /* update the declaration from the instance, forcing empty arrays */
  do_structure_assignment(/* to = */ &declaration, /* from = */ top, 1);

  /* update local vars too */
  if (declaration_locals) {

    /* ...except make var_user point at the declaration */
    declaration.var_un.var_user = declaration_locals;

    /* update the local variables from instance to declaration */
    do_structure_assignment(/* to  = */ &declaration,
                            /* from= */ top->var_un.var_user->st_local_vars, 1);
  }

  /* With class variables, "being initialized" isn't a function of the       *
   * block, it's a function of the variable.  If this *variable* is not      *
   * initialized, then I digress on the *block's* "initializationess" and    *
   * call run_block where the initialization of this *variable* will happen. */

  if ((top->var_flags & VF_INITIALIZED) == 0) {

    class_block->b_flags &= ~B_INITIALIZED;
    run_block(class_block);
    top->var_flags |= VF_INITIALIZED;
  } else
    run_block(class_block);

  /* At this point the class code has run and the variables declared inside *
   * of the class declaration have been updated instead of the instances of *
   * the variables inside of the variable declaration itself.  We must now  *
   * copy the values out of the declaration into the variable.              *
   * This is expensive, but without it, we would only be able to declare    *
   * one active class variable per class type.                              */

  /* ...except make var_user point at the declaration */
  declaration.var_un.var_user = declaration_members;

  /* update the instance from the declaration */
  do_structure_assignment(/* to = */ top, /* from = */ &declaration, 2);

  /* update local vars if necessary */
  if (declaration_locals) {

    /* make var_user point at the declaration */
    declaration.var_un.var_user = declaration_locals;

    /* update the instance from the declaration */
    do_structure_assignment(/* to   = */ top->var_un.var_user->st_local_vars,
                            /* from = */ &declaration, 2);
  }
}

static void
run_statement_list(T_STATEMENT *lp)
{
  T_STATEMENT *sp;

  for(sp=lp; sp; sp=sp->s_next) {
    line_no = sp->s_line_no;
    if (Se_flags & SE_DEBUG)
      se_debug_statement(sp);
    (*sp->s_function)(sp);
  }
}

static void
run_if(T_STATEMENT *sp)
{
  T_IF *ip;

  ip = sp->s_un.s_if;
  if (resolve_l_expression(ip->i_if))
    run_statement_list(ip->i_then);
  else if (ip->i_else)
    run_statement_list(ip->i_else);
}

static void
run_intf(T_INTF type, T_STATEMENT *sp, void *arg, int argsz)
{
  unsigned long arg_list[MAX_ARGS * sizeof(void *) * 2];
  char *format;
  int i;
  int j;
  T_EXPR *ep;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE var;
  T_VARTYPE vtypes[MAX_ARGS];

  if (cp->c_arg_count > MAX_ARGS)
    se_fatal("arg count overflow to intf function");

  switch(type) {
  case PRINTF_TYPE:
  case SPRINTF_TYPE:
    ep = cp->c_args;
    break;
  case FPRINTF_TYPE:
  case SYSLOG_TYPE:
    ep = cp->c_args->e_next;
    break;
  }
  memset(vtypes, VAR_BOGUS, sizeof vtypes);
  resolve_expression(&var, ep, 1);
  format = var.var_un.var_string;
  if (format == 0)
    se_fatal("reference through nil pointer: intf function");
  for(i=0, ep=ep->e_next; ep; ep=ep->e_next, i++) {
    var = zero_variable;
    resolve_expression(&var, ep, 1);
    vtypes[i] = var.var_type;
    switch(var.var_type) {
    case VAR_STRING:
      if (var.var_un.var_string == 0)
        arg_list[i] = (unsigned long) se_string_save("(nil)");
      else
        arg_list[i] = (unsigned long) se_string_save(var.var_un.var_string);
      break;
    case VAR_CHAR:
      if (var.var_dimension) {
        arg_list[i] = (unsigned long) se_string_save(var.var_un.var_string);
        vtypes[i] = VAR_STRING;
      } else {
        arg_list[i] = (unsigned long) ((char) var.var_un.var_digit);
      }
      break;
    case VAR_SHORT:
      arg_list[i] = (unsigned long) ((short) var.var_un.var_digit);
      break;
    case VAR_LONG:
      arg_list[i] = (unsigned long) var.var_un.var_digit;
      break;
    case VAR_UCHAR:
      arg_list[i] = (unsigned long) ((unsigned char) var.var_un.var_udigit);
      break;
    case VAR_USHORT:
      arg_list[i] = (unsigned long) ((unsigned short) var.var_un.var_udigit);
      break;
    case VAR_ULONG:
      arg_list[i] = ((unsigned long) var.var_un.var_udigit);
      break;
    case VAR_LONGLONG:
#if defined(_LP64)
      arg_list[i] = (unsigned long) var.var_un.var_ldigit;
#else
      arg_list[i++] = ((unsigned long *) &var.var_un.var_ldigit)[0];
      arg_list[i]   = ((unsigned long *) &var.var_un.var_ldigit)[1];
#endif
      break;
    case VAR_ULONGLONG:
#if defined(_LP64)
      arg_list[i] = var.var_un.var_uldigit;
#else
      arg_list[i++] = ((unsigned long *) &var.var_un.var_uldigit)[0];
      arg_list[i]   = ((unsigned long *) &var.var_un.var_uldigit)[1];
#endif
      break;
    case VAR_DOUBLE:
#if defined(_LP64)
      arg_list[i] = ((unsigned long *) &var.var_un.var_rdigit)[0];
#else
      arg_list[i++] =
        (unsigned long) ((unsigned int *) &var.var_un.var_rdigit)[0];
      arg_list[i]   =
        (unsigned long) ((unsigned int *) &var.var_un.var_rdigit)[1];
#endif
      break;
    }
  }
  switch(type) {
  case SPRINTF_TYPE:
  case SYSLOG_TYPE:
#ifdef _USE_INTF
    anprintf(arg, argsz, format, vtypes, arg_list, i);
#else
    vsnprintf((char *) arg, argsz, format, (void *) arg_list);
#endif
    break;
  case PRINTF_TYPE:
  case FPRINTF_TYPE:
#ifdef _USE_INTF
    /* arg_list is not a va_list, do it the hard way.
       Format into a buffer, then print the buffer to the file */
    {
      int buf_size = 8192;
      char * buf = NULL;
      int rc;

      /* Will loop at most once if 8k isn't enough */
      for (;;) {
        buf = (char *)realloc(buf, buf_size);
        rc = anprintf(buf, buf_size, format, vtypes, arg_list, i);
	if (rc < buf_size)
	  break;
	buf_size = rc + 1; /* +1 for the terminating 0 */
      }

      cp->c_block->b_return->var_un.var_digit =
        fprintf((FILE *) arg, "%s", buf);
      free(buf);
    }
#else
    cp->c_block->b_return->var_un.var_digit =
      vfprintf((FILE *) arg, format, (void *) arg_list);
#endif
    break;
  }
  switch(type) {
  case PRINTF_TYPE:
  case SPRINTF_TYPE:
    ep = cp->c_args;
    break;
  case FPRINTF_TYPE:
  case SYSLOG_TYPE:
    ep = cp->c_args->e_next;
    break;
  }
  for(j=0; j<i; j++)
    if (vtypes[j] == VAR_STRING)
      se_free((void *) arg_list[j]);
}

#ifdef _USE_INTF

/* this code is kept here because it parses an intf string   *
 * and I may want that some day.                             */

/* The anprintf() function returns  the  number  of  characters
     formatted, that is, the number of characters that would have
     been written to the buffer if it were large enough.  If  the
     value  of  n  is  0  on a call to anprintf(), an unspecified
     value less than 1 is returned.
*/
static ssize_t
anprintf(char *buf, size_t buf_size, char *format, T_VARTYPE *vtypes,
	 unsigned long arg_list[], int n)
{
  char fmt_buf[32];
  char *fmt;
  char *p;
  int i;
  int vindex = -1;
  int stars;
  int first_star;
  int second_star;
  unsigned long long ull;
  double d;
  size_t result = 0;
  int rc;

  if (buf_size == 0)
      return -1;

  p = format;
  for(i=0; i<n; i++) {
    for(; *p; p++) {
      if (*p == '%') {
        if (*(p + 1) == '%') {
	  if (buf_size > 1) {
            *buf++ = '%';
	    buf_size--;
	  }
	  result++;
          p++;
        } else {
          ++vindex;
          break;
        }
      } else {
	  if (buf_size > 1) {
            *buf++ = *p;
	    buf_size--;
	  }
	  result++;
      }
    }

    if (*p) {
      stars = 0;
      fmt = fmt_buf;
      *fmt++ = *p++;
      while(strchr(" \t%", *p) == 0) {
        if (*p == '*') {
          stars++;
          i++;
        }
        *fmt++ = *p++;
      }
      *fmt = '\0';
    } else
      break;

    rc = 0;
    switch(stars) {
    case 0:
      switch(vtypes[i]) {
      case VAR_STRING:
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
        rc = snprintf(buf, buf_size, fmt_buf, arg_list[vindex]);
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
#if defined(_LP64)
        ull = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &ull)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &ull)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, ull);
        break;
      case VAR_DOUBLE:
#if defined(_LP64)
	((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &d)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, d);
        break;
      default:
        se_fatal("Bogus type: %u\n", vtypes[i]);
      }
      break;
    case 1:
      switch(vtypes[i]) {
      case VAR_STRING:
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
        rc = snprintf(buf, buf_size, fmt_buf, arg_list[vindex], arg_list[vindex+1]);
        vindex++;
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        first_star = (long) arg_list[vindex++];
#if defined(_LP64)
        ull = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &ull)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &ull)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, first_star, ull);
        break;
      case VAR_DOUBLE:
        first_star = (long) arg_list[vindex++];
#if defined(_LP64)
	((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &d)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, first_star, d);
        break;
      default:
        se_fatal("Bogus type: %u\n", vtypes[i]);
      }
      break;
    case 2:
      switch(vtypes[i]) {
      case VAR_STRING:
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
        rc = snprintf(buf, buf_size, fmt_buf,
                arg_list[vindex], arg_list[vindex+1], arg_list[vindex+2]);
        vindex += 2;
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        first_star = (long) arg_list[vindex++];
        second_star = (long) arg_list[vindex++];
#if defined(_LP64)
        ull = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &ull)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &ull)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, first_star, second_star, ull);
        break;
      case VAR_DOUBLE:
        first_star = (long) arg_list[vindex++];
        second_star = (long) arg_list[vindex++];
#if defined(_LP64)
	((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex];
#else
        ((unsigned long *) &d)[0] = (unsigned long) arg_list[vindex++];
        ((unsigned long *) &d)[1] = (unsigned long) arg_list[vindex];
#endif
        rc = snprintf(buf, buf_size, fmt_buf, first_star, second_star, d);
        break;
      default:
        se_fatal("Bogus type: %u\n", vtypes[i]);
      }
      break;
    default:
      se_fatal("Too many stars in format string");
      break;
    }
    if (rc < buf_size) {
      buf += rc;
      buf_size -= rc;
    } else {
      buf = &buf[buf_size - 1];
      buf_size = 1;
    }
    result += rc;
  }
  for(; *p; p++) {
    if (*p == '%') {
      if (*(p + 1) == '%') {
        if (buf_size > 1) {
          *buf++ = '%';
          buf_size--;
        }
        result++;
        p++;
      } else
        break;
    } else {
      if (buf_size > 1) {
        *buf++ = *p;
        buf_size--;
      }
      result++;
    }
  }
  *buf = '\0';

  return result;
}
#endif

static void
run_printf(T_STATEMENT *sp)
{
  run_intf(PRINTF_TYPE, sp, (void *) stdout, 0);
}

static void
run_fprintf(T_STATEMENT *sp)
{
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, sp->s_un.s_call->c_args, 1);
  run_intf(FPRINTF_TYPE, sp, (void *) var.var_un.var_register, 0);
}

static void
run_sprintf(T_STATEMENT *sp)
{
  char buf[8192];
  T_VARIABLE *vp = sp->s_un.s_call->c_block->b_return;

  run_intf(SPRINTF_TYPE, sp, (void *) buf, sizeof buf);
  se_new_string(&vp->var_un.var_string, buf);
}

static void
run_itoa(T_STATEMENT *sp)
{
  T_VARIABLE var;
  T_FCALL *cp = sp->s_un.s_call;
  char *p;

  var = zero_variable;
  resolve_expression(&var, cp->c_args, 1);
  if (cp->c_block->b_return->var_un.var_string == 0)
    cp->c_block->b_return->var_un.var_string = (char *) se_alloc(32);
  p = cp->c_block->b_return->var_un.var_string;
  switch(var.var_type) {
  case VAR_CHAR:
  case VAR_SHORT:
  case VAR_LONG:
    snprintf(p, 32, "%d", var.var_un.var_digit);
    break;
  case VAR_UCHAR:
  case VAR_USHORT:
  case VAR_ULONG:
    snprintf(p, 32, "%u", var.var_un.var_udigit);
    break;
  case VAR_LONGLONG:
    snprintf(p, 32, "%lld", var.var_un.var_ldigit);
    break;
  case VAR_ULONGLONG:
    snprintf(p, 32, "%llu", var.var_un.var_uldigit);
    break;
  }
}

static void
signal_catcher(int signo)
{
  char *func = sig_functions[signo];

  sig_functions[signo] = SIGNAL_DEFAULT;
  se_function_call(func, signo);
}

static void
run_signal(T_STATEMENT *sp)
{
  int signo;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, cp->c_args, 1);
  resolve_expression(&arg2, cp->c_args->e_next, 1);
  if (arg2.var_un.var_string == 0)
    se_fatal("reference through nil pointer: signal");
  signo = _DIGIT_(arg1);
  cp->c_block->b_return->var_un.var_string = sig_functions[signo];
  sig_functions[signo] = arg2.var_un.var_string;
  if (strcmp(sig_functions[signo], SIGNAL_DEFAULT) == 0)
    signal(signo, SIG_DFL);
  else if (strcmp(sig_functions[signo], SIGNAL_IGNORE) == 0)
    signal(signo, SIG_IGN);
  else
    signal(signo, signal_catcher);
}

static void
run_debug_off(T_STATEMENT *sp)
{
  Se_flags &= ~SE_DEBUG;
}

static void
run_debug_on(T_STATEMENT *sp)
{
  Se_flags |= SE_DEBUG;
}

static void
run_fileno(T_STATEMENT *sp)
{
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, sp->s_un.s_call->c_args, 1);
  sp->s_un.s_call->c_block->b_return->var_un.var_digit =
    fileno((FILE *) var.var_un.var_register);
}

static void
run_syslog(T_STATEMENT *sp)
{
  char buf[BUFSIZ];
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, sp->s_un.s_call->c_args, 1);
  run_intf(SYSLOG_TYPE, sp, (void *) buf, sizeof buf);
  syslog(var.var_un.var_digit, buf);
}

static void
run_sizeof(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE var;
  int size;

  var = zero_variable;
  resolve_expression(&var, cp->c_args, 1);
  size = Se_type_sizes[var.var_type];
  if (size == -1)
    size = var.var_struct->st_size;
  if (var.var_dimension && (var.var_subscript == 0))
    size *= var.var_dimension;
  cp->c_block->b_return->var_un.var_udigit = (size < 0) ? 0 : size;
}

static void
run_kvm_cvt (T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *arg1 = cp->c_args->e_variable;
  T_VARIABLE arg2;

  arg2 = zero_variable;
  resolve_expression(&arg2, cp->c_args->e_next, 1);
  arg1->var_address = (caddr_t) arg2.var_un.var_register;
  if (arg1->var_type == VAR_USER)
    se_address_inherit(arg1, arg1->var_address);
}

static void
run_kvm_address (T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *arg1 = cp->c_args->e_variable;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_register = (T_REGISTER) arg1->var_address;
}

static int ncalls;

static void
member_fill(T_VARIABLE *vp, uchar_t *area, int bias)
{
  int i;
  int size;
  void *t_array;
  void *f_array;

  if (vp->var_type == VAR_USER) {
    struct_fill(vp, area, bias);
    return;
  }
  /* I will never encounter a subscripted value */
  if (vp->var_dimension) {
    f_array = area + vp->var_offset + bias;
    t_array = vp->var_un.var_array;
    size = Se_type_sizes[vp->var_type];
    size *= vp->var_dimension;
    if (vp->var_type == VAR_STRING) {
      for(i=0; i<vp->var_dimension; i++)
        ((char **) t_array)[i] = ((char **) f_array)[i];
    } else {
      if ((t_array == 0) || (f_array == 0))
        se_fatal("reference through nil pointer accessing: %s", vp->var_name);
      memcpy(t_array, f_array, size);
    }
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      vp->var_un.var_udigit = (unsigned int) area[vp->var_offset + bias];
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      vp->var_un.var_udigit =
        (unsigned int) *((unsigned short *) (area + vp->var_offset + bias));
      break;
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit =
        *((unsigned int *) (area + vp->var_offset + bias));
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = *((T_ULLONG *) (area + vp->var_offset + bias));
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = *((double *) (area + vp->var_offset + bias));
      break;
    case VAR_STRING:
      se_new_string(&vp->var_un.var_string,
                    *((char **)(area + vp->var_offset + bias)));
      break;
    }
  }
}

static void
struct_fill(T_VARIABLE *vp, uchar_t *area, int bias)
{
  int i;
  T_VARIABLE *vvp;
  T_STRUCT **spp;

  if (vp->var_type != VAR_USER)
    return;
  if (vp->var_dimension) {
    spp = (T_STRUCT **) vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++)
      for(vvp=spp[i]->st_members; vvp; vvp=vvp->var_next)
        member_fill(vvp, area, bias);
  } else {
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next)
      member_fill(vvp, area, bias);
  }
}

/* run_struct_fill(to_struct_var, flat_area);  */

static void
run_struct_fill(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE arg1;
  T_VARIABLE arg2;
  int bias = 0;

  arg1 = zero_variable;
  arg2 = zero_variable;

  resolve_expression(&arg1, cp->c_args, 1);
  if (arg1.var_dimension)
    bias = -((T_STRUCT **) arg1.var_un.var_array)[0]->st_members->var_offset;
  else
    bias = -arg1.var_un.var_user->st_members->var_offset;

  resolve_expression(&arg2, cp->c_args->e_next, 1);
  if (arg2.var_un.var_register == 0)
    se_fatal("reference through nil pointer assigning to: %s", arg1.var_name);

  struct_fill(&arg1, (uchar_t *) arg2.var_un.var_register, bias);
}

static void
member_empty(T_VARIABLE *vp, uchar_t *area, int bias)
{
  int i;
  int size;
  void *t_array;
  void *f_array;

  if (vp->var_type == VAR_USER) {
    struct_empty(vp, area, bias);
    return;
  }
  /* I will never encounter a subscripted value */
  if (vp->var_dimension) {
    f_array = vp->var_un.var_array;
    t_array = area + vp->var_offset + bias;
    size = Se_type_sizes[vp->var_type];
    size *= vp->var_dimension;
    /* I'm punting on the VAR_STRING case. */
    if ((t_array == 0) || (f_array == 0))
      se_fatal("reference through nil pointer accessing: %s", vp->var_name);
    memcpy(t_array, f_array, size);
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      area[vp->var_offset + bias] = (unsigned char) vp->var_un.var_udigit;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      *((unsigned short *) (area + vp->var_offset + bias)) =
        (unsigned short) vp->var_un.var_udigit;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      *((unsigned int *) (area + vp->var_offset + bias)) =
         vp->var_un.var_udigit;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      *((T_ULLONG *) (area + vp->var_offset + bias)) = vp->var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      *((double *) (area + vp->var_offset + bias)) = vp->var_un.var_rdigit;
      break;
    case VAR_STRING:
      *((char **) (area + vp->var_offset + bias)) = vp->var_un.var_string;
      break;
    }
  }
}

static void
struct_empty(T_VARIABLE *vp, unsigned char *area, int bias)
{
  int i;
  T_VARIABLE *vvp;
  T_STRUCT **spp;

  if (vp->var_type != VAR_USER)
    return;
  if (vp->var_dimension) {
    spp = (T_STRUCT **) vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++)
      for(vvp=spp[i]->st_members; vvp; vvp=vvp->var_next)
        member_empty(vvp, area, bias);
  } else
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next)
      member_empty(vvp, area, bias);
}

/*  run_struct_empty(from_struct_var, flat_area);  */

static void
run_struct_empty(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE arg1;
  T_VARIABLE arg2;
  int bias = 0;

  arg1 = zero_variable;
  arg2 = zero_variable;

  resolve_expression(&arg1, cp->c_args, 1);

  if (arg1.var_dimension)
    bias = -((T_STRUCT **) arg1.var_un.var_array)[0]->st_members->var_offset;
  else
    bias = -arg1.var_un.var_user->st_members->var_offset;

  resolve_expression(&arg2, cp->c_args->e_next, 1);
  if (arg2.var_un.var_register == 0)
    se_fatal("reference through nil pointer assigning to: %s", arg1.var_name);

  struct_empty(&arg1, (unsigned char *) arg2.var_un.var_register, bias);
}

static void
run_address_of(T_STATEMENT *sp)
{
  int i;
  int sub = 0;
  int entire = 1;
  int size;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *arg = cp->c_args->e_variable;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE *member_list[MAX_DOTS];
  T_VARIABLE *vp;
  T_VARIABLE var;
  T_STATEMENT st;

  if ((arg->var_flags & VF_SPECIAL) == VF_EXTERN) {
    /* (not an array) or (address of whole array) */
    if ((arg->var_dimension == 0) || (arg->var_subscript == 0)) {
      ret->var_un.var_register = (T_REGISTER) arg->var_address;
      return;
    }

    /* subscripted array */
    sub = compute_subscript(arg, 1);
    size = Se_type_sizes[arg->var_type];
    ret->var_un.var_register = (T_REGISTER)
      (((unsigned char *) arg->var_address) + (sub * size));
    return;
  }

  if (arg->var_dimension) {
    if (arg->var_subscript)
      sub = compute_subscript(arg, 1);

    size = Se_type_sizes[arg->var_type];
    if (size == -1)
      se_fatal("structure slipped through run_address_of");
    ret->var_un.var_register = (T_REGISTER)
      (((unsigned char *) arg->var_un.var_array) + (sub * size));
  } else {
    switch(arg->var_type) {
    case VAR_CHAR:
#if defined(sparc)
        ret->var_un.var_register =
          (T_REGISTER) (((char *) &arg->var_un.var_digit) + 3);
#elif defined(i386)
        ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_digit;
#else
        time_to_define_a_new_architecture
#endif
      break;
    case VAR_SHORT:
#if defined(sparc)
        ret->var_un.var_register =
          (T_REGISTER) (((unsigned short *) &arg->var_un.var_digit) + 1);
#elif defined(i386)
        ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_digit;
#else
        time_to_define_a_new_architecture
#endif
      break;
    case VAR_LONG:
      ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_digit;
      break;
    case VAR_UCHAR:
#if defined(sparc)
        ret->var_un.var_register =
          (T_REGISTER) (((char *) &arg->var_un.var_udigit) + 3);
#elif defined(i386)
        ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_udigit;
#else
        time_to_define_a_new_architecture
#endif
      break;
    case VAR_USHORT:
#if defined(sparc)
        ret->var_un.var_register =
          (T_REGISTER) (((unsigned short *) &arg->var_un.var_udigit) + 1);
#elif defined(i386)
        ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_udigit;
#else
        time_to_define_a_new_architecture
#endif
      break;
    case VAR_ULONG:
      ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_udigit;
      break;
    case VAR_LONGLONG:
      ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_ldigit;
      break;
    case VAR_ULONGLONG:
      ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      ret->var_un.var_register = (T_REGISTER) &arg->var_un.var_rdigit;
      break;
    case VAR_STRING:
      /* I'm going to assume they just want a type cast */
      ret->var_un.var_register = (T_REGISTER) arg->var_un.var_string;
      break;
    }
  }
}

static void
run_indirection(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, cp->c_args, 1);
  if (var.var_un.var_string == 0)
    se_fatal("reference through nil pointer: indirection");
  switch(ret->var_type) {
  case VAR_CHAR:
  case VAR_UCHAR:
    ret->var_un.var_udigit = *((unsigned char *) var.var_un.var_register);
    break;
  case VAR_SHORT:
  case VAR_USHORT:
    ret->var_un.var_udigit = *((unsigned short *) var.var_un.var_register);
    break;
  case VAR_LONG:
  case VAR_ULONG:
    ret->var_un.var_udigit = *((unsigned int *) var.var_un.var_register);
    break;
  case VAR_LONGLONG:
  case VAR_ULONGLONG:
  case VAR_DOUBLE:
    ret->var_un.var_uldigit = *((T_ULLONG *) var.var_un.var_register);
    break;
  case VAR_STRING:
    ret->var_un.var_string = *((char **) var.var_un.var_register);
    break;
  case VAR_USER:
    struct_fill(ret, (unsigned char *) var.var_un.var_register, 0);
    break;
  }
}

static void
run_new(T_STATEMENT *sp)
{
  int i;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE *vp = cp->c_args->e_variable;
  T_VARIABLE size;

  size = zero_variable;
  resolve_expression(&size, vp->var_initial, 1);
  if (ret->var_un.var_array) {
    if (ret->var_type == VAR_USER) {
      for(i=0; i<ret->var_dimension; i++)
        se_free_user_type(((T_STRUCT **) ret->var_un.var_array)[i]);
      se_free(ret->var_un.var_array);
    } else
      se_free(ret->var_un.var_array);
  }
  if (Se_type_sizes[size.var_type] < 8)
    ret->var_dimension = size.var_un.var_digit;
  else
    ret->var_dimension = size.var_un.var_ldigit;
  ret->var_un.var_array = se_new_array_type(ret);
}

static void
run_null(T_STATEMENT *sp)
{
}

static void
run_renew(T_STATEMENT *sp)
{
  int i;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *args = cp->c_args;
  T_VARIABLE *vp = args->e_variable;
  T_VARIABLE size;
  T_STATEMENT statement;
  T_ASSIGN assign;
  T_EXPR expr;

  /* resolve the new size */
  size = zero_variable;
  resolve_expression(&size, args->e_next, 1);

  /* free the old ret values */
  if (ret->var_un.var_array) {
    if (ret->var_type == VAR_USER) {
      for(i=0; i<ret->var_dimension; i++)
        se_free_user_type(((T_STRUCT **) ret->var_un.var_array)[i]);
      se_free(ret->var_un.var_array);
    } else
      se_free(ret->var_un.var_array);
  }

  /* allocate a new array with the new size */
  if (Se_type_sizes[size.var_type] < 8)
    ret->var_dimension = size.var_un.var_digit;
  else
    ret->var_dimension = size.var_un.var_ldigit;
  if (ret->var_dimension < vp->var_dimension)
    /* truncate: char buf[8] = renew buf[4]; */
    vp->var_dimension = ret->var_dimension;
  ret->var_un.var_array = se_new_array_type(ret);

  /* assign vp to ret */
  expr = zero_expr;
  assign = zero_assign;
  statement = zero_statement;
  statement.s_un.s_assign = &assign;
  assign.a_op = A_ASSIGN;
  assign.a_variable = ret;
  assign.a_expression = &expr;
  expr.e_type = E_VALUE;
  expr.e_variable = vp;
  run_assign(&statement);

  /* free the old vp values */
  if (vp->var_un.var_array) {
    if (vp->var_type == VAR_USER) {
      for(i=0; i<vp->var_dimension; i++)
        se_free_user_type(((T_STRUCT **) vp->var_un.var_array)[i]);
      se_free(vp->var_un.var_array);
    } else
      se_free(vp->var_un.var_array);
  }

  /* build new vp values with the new size */
  vp->var_dimension = ret->var_dimension;
  vp->var_un.var_array = se_new_array_type(vp);

  /* assign the values back into vp from ret */
  assign.a_variable = vp;
  expr.e_variable = ret;
  run_assign(&statement);
}

static void
run_kvm_declare(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, cp->c_args, 1);
  if (var.var_un.var_string == 0)
    se_fatal("reference through nil pointer: kvm_declare");
  ret->var_un.var_register = se_kvm_address(var.var_un.var_string);
}

static void
run_type_cast(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, cp->c_args, 1);
  fix_type(&var, ret->var_type);
  ret->var_un.var_uldigit = var.var_un.var_uldigit;
}

static void
push(void *item, T_STACK *sp)
{
  if (sp->st_top == MAX_STACK)
    se_fatal("callback function stack overflow");
  sp->st_array[sp->st_top++] = item;
}

static void *
pop(T_STACK *sp)
{
  if (sp->st_top == 0)
    return 0;
  return sp->st_array[--sp->st_top];
}

static void *
peek(T_STACK *sp)
{
  if (sp->st_top == 0)
    return 0;
  return sp->st_array[sp->st_top-1];
}

static int
qsort_cmp(const void *a, const void *b)
{
  char *fn = (char *) peek(&qsort_cmp_stack);
  T_VARIABLE *vp;

  if (fn == 0)
    se_fatal("qsort compare function stack underflow");
  vp = se_function_call(fn, a, b);
  if (vp == 0)
    se_fatal("qsort compare function: %s does not exist", fn);
  return vp->var_un.var_digit;
}

static void
run_qsort(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE base;
  T_VARIABLE nel;
  T_VARIABLE width;
  T_VARIABLE compar;

  base = nel = width = compar = zero_variable;
  resolve_expression(&base,   cp->c_args, 1);
  resolve_expression(&nel,    cp->c_args->e_next, 1);
  resolve_expression(&width,  cp->c_args->e_next->e_next, 1);
  resolve_expression(&compar, cp->c_args->e_next->e_next->e_next, 1);
  if (compar.var_un.var_string == 0)
    se_fatal("reference through nil pointer: qsort");
  push(compar.var_un.var_string, &qsort_cmp_stack);
  qsort((void *) base.var_un.var_register,
                 nel.var_un.var_digit,
                 width.var_un.var_digit,
                 qsort_cmp);
  (void) pop(&qsort_cmp_stack);
}

void
atexit_fn(void)
{
  char *p;

  while(p = (char *) pop(&atexit_stack))
    se_function_call(p);
}

static void
run_atexit(T_STATEMENT *sp)
{
  static int atexit_called = 0;
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE fn;

  resolve_expression(&fn, cp->c_args, 1);
  if (fn.var_un.var_string == 0)
    se_fatal("reference through nil pointer: atexit");
  push(fn.var_un.var_string, &atexit_stack);
  if (atexit_called == 0) {
    atexit_called = 1;
    ret->var_un.var_digit = atexit(atexit_fn);
  } else
    ret->var_un.var_digit = 0;
}

static int
bsearch_cmp(const void *a, const void *b)
{
  char *fn = (char *) peek(&bsearch_cmp_stack);
  T_VARIABLE *vp;

  if (fn == 0)
    se_fatal("bsearch compare function stack underflow");
  vp = se_function_call(fn, a, b);
  if (vp == 0)
    se_fatal("bsearch compare function: %s does not exist", fn);
  return vp->var_un.var_digit;
}

static void
run_bsearch(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_VARIABLE key;
  T_VARIABLE base;
  T_VARIABLE nel;
  T_VARIABLE size;
  T_VARIABLE compar;

  key = base = nel = size = compar = zero_variable;
  resolve_expression(&key,    cp->c_args, 1);
  resolve_expression(&base,   cp->c_args->e_next, 1);
  resolve_expression(&nel,    cp->c_args->e_next->e_next, 1);
  resolve_expression(&size,   cp->c_args->e_next->e_next->e_next, 1);
  resolve_expression(&compar, cp->c_args->e_next->e_next->e_next->e_next, 1);
  if (compar.var_un.var_string == 0)
    se_fatal("reference through nil pointer: bsearch");
  push(compar.var_un.var_string, &bsearch_cmp_stack);
  ret->var_un.var_register =
    (T_REGISTER) bsearch((void *) key.var_un.var_register,
                         (void *) base.var_un.var_register,
                                  nel.var_un.var_digit,
                                  size.var_un.var_digit,
                                  bsearch_cmp);
  (void) pop(&bsearch_cmp_stack);
}

static void
run_refresh(T_STATEMENT *sp)
{
  T_VARIABLE *vp = sp->s_un.s_call->c_args->e_variable;

  switch(vp->var_special) {
  case SS_KSTAT:
    se_refresh_kstat_variable(vp);
    break;
  case SS_NDD:
    se_refresh_ndd_variable(vp);
    break;
  case SS_MIB:
    se_refresh_mib_variable(vp);
    break;
  case SS_KVM:
    se_refresh_kvm_variable(vp);
    break;
  default:
    run_class(vp);
    break;
  }
}

static void
run_call(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_STATEMENT statement;
  T_ASSIGN assign;
  T_VARIABLE *vp;
  T_EXPR *ep;
  anode *anp;

  if (cp->c_builtin) {
    (*cp->c_builtin)(sp);
  } else {
    if (cp->c_block->b_parameters) {
      /* run a bunch of assignments */
      vp = cp->c_block->b_parameters;
      ep = cp->c_args;
      assign = zero_assign;
      statement = zero_statement;
      statement.s_un.s_assign = &assign;
      assign.a_op = A_ASSIGN;
      for(; vp; vp=vp->var_next, ep=ep->e_next) {
        assign.a_variable = vp;
        assign.a_expression = ep;
        run_assign(&statement);
      }
    }

    run_block(cp->c_block);
  }
}

static void
run_while(T_STATEMENT *sp)
{
  T_WHILE *volatile wp = sp->s_un.s_while;

  if (setjmp(wp->w_jmpbuf) == DO_BREAK)
    return;
  while(resolve_l_expression(wp->w_expr))
    run_statement_list(wp->w_statements);
}

static void
run_assign(T_STATEMENT *sp)
{
  char *p;
  int i;
  int n;
  int subscript;
  void *array;
  void *t_array;
  void *f_array;
  int size;
  T_ASSIGN *ap;
  T_VARIABLE var;
  T_VARIABLE t_var;
  T_VARIABLE f_var;
  T_VARIABLE *vp;
  T_EXPR *ep;
  T_EXPR evar;
  T_EXPR expr;

  /* Run "lvalue = expression" code.  First, get the players */
  ap = sp->s_un.s_assign;
  vp = ap->a_variable;
  ep = ap->a_expression;

  /* The *=, /=, etc. operators are also assignments.  Deal with it. */
  var = zero_variable;
  if (ap->a_op != A_ASSIGN) {
    evar = zero_expr;
    expr = zero_expr;
  }

  /* The expression will now be resolved into the "var" variable */
  switch(ap->a_op) {
  case A_ASSIGN:
    resolve_expression(&var, ep, 1);
    break;
  case A_ADD:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_ADD;
    resolve_expression(&var, &expr, 1);
    break;
  case A_SUBTRACT:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_SUBTRACT;
    resolve_expression(&var, &expr, 1);
    break;
  case A_MULTIPLY:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_MULTIPLY;
    resolve_expression(&var, &expr, 1);
    break;
  case A_DIVIDE:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_DIVIDE;
    resolve_expression(&var, &expr, 1);
    break;
  case A_MODULUS:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_MODULUS;
    resolve_expression(&var, &expr, 1);
    break;
  case A_BIT_AND:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_BIT_AND;
    resolve_expression(&var, &expr, 1);
    break;
  case A_BIT_OR:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_BIT_OR;
    resolve_expression(&var, &expr, 1);
    break;
  case A_BIT_XOR:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_BIT_XOR;
    resolve_expression(&var, &expr, 1);
    break;
  case A_SHIFT_LEFT:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_SHIFT_LEFT;
    resolve_expression(&var, &expr, 1);
    break;
  case A_SHIFT_RIGHT:
    /* fake it */
    evar.e_type = E_VALUE;
    evar.e_variable = vp;
    expr.e_type = E_EXPRESSION;
    expr.e_left = &evar;
    expr.e_right = ep;
    expr.e_op = EO_SHIFT_RIGHT;
    resolve_expression(&var, &expr, 1);
    break;
  }

  /* make sure we can assign longs to longlongs */
  if (var.var_type != vp->var_type)
    /* exceptional case for string actual to char[] formal assigns */
    if ((var.var_type | vp->var_type) == (VAR_CHAR | VAR_STRING)) {
      /* actual parameter type matches formal parameter type */
      var.var_type = vp->var_type;
      /* formal parameter is empty declaration? */
      if (vp->var_flags & VF_EMPTY)
        /* if the actual parameter is not "nil" */
        if (var.var_un.var_string)
          /* the size of the formal parameter is the length of the actual */
          vp->var_dimension = strlen(var.var_un.var_string) + 1;
        else
          vp->var_dimension = -1;
      /* the actual looks just like the formal now */
      var.var_dimension = vp->var_dimension;
    } else
      fix_type(&var, vp->var_type);

  /* Now look at the lvalue and figure out where to put it. */
  if (vp->var_subscript) {
    /* It's a subscripted array.  */
    subscript = compute_subscript(vp, 1);
    array = vp->var_un.var_array;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      ((unsigned char *) array)[subscript] =
                           (unsigned char) var.var_un.var_udigit;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      ((unsigned short *) array)[subscript] =
                           (unsigned short) var.var_un.var_udigit;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      ((unsigned int *) array)[subscript] = var.var_un.var_udigit;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ((T_ULLONG *) array)[subscript] = var.var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      ((double *) array)[subscript] = var.var_un.var_rdigit;
      break;
    case VAR_STRING:
      se_new_string(((char **) array) + subscript, var.var_un.var_string);
      break;
    case VAR_USER:
      t_var = var;
      t_var.var_un.var_user = ((T_STRUCT **) array)[subscript];
      do_structure_assignment(&t_var, &var, 0);
      break;
    }
  } else if (vp->var_dimension || (vp->var_flags & VF_EMPTY)) {
    /* It's an array assignment. */
    f_array = var.var_un.var_array;
    t_array = vp->var_un.var_array;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      size = sizeof(char);
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      size = sizeof(short);
      break;
    case VAR_LONG:
    case VAR_ULONG:
      size = sizeof(int);
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      size = sizeof(T_LLONG);
      break;
    case VAR_DOUBLE:
      size = sizeof(double);
      break;
    case VAR_STRING:
      if (vp->var_flags & VF_EMPTY) {
        se_clone_array(vp, &var);
        t_array = vp->var_un.var_array;
      }
      n = MIN(vp->var_dimension, var.var_dimension);
      for(i=0; i<n; i++)
         se_new_string(((char **) t_array) + i, ((char **) f_array)[i]);
      size = -1;  /* inhibit the memcpy below */
      break;
    case VAR_USER:
      if (vp->var_flags & VF_EMPTY) {
        se_clone_array(vp, &var);
        t_array = vp->var_un.var_array;
      }
      t_var = var;
      t_var.var_dimension = 0;
      f_var = t_var;
      n = MIN(vp->var_dimension, var.var_dimension);
      for(i=0; i<n; i++) {
        t_var.var_un.var_user = ((T_STRUCT **) t_array)[i];
        f_var.var_un.var_user = ((T_STRUCT **) f_array)[i];
        do_structure_assignment(&t_var, &f_var, 0);
      }
      size = -1;
      break;
    }
    if (size != -1) {
      if (vp->var_flags & VF_EMPTY) {
        se_clone_array(vp, &var);
        t_array = vp->var_un.var_array;
      }
      if (var.var_dimension == -1) {
        /* char f[4]; */
        /* char z[];  */
        /* f = z;     */
        se_clone_array(vp, &var);
        vp->var_flags |= VF_EMPTY;
        vp->var_dimension = -1;
      } else {
        size *= var.var_dimension;
        if ((t_array == 0) || (f_array == 0)) {
          if ((var.var_flags & VF_SPECIAL) != VF_KVM)
            se_fatal("reference through nil pointer assigning to %s",
                      vp->var_name);
        } else
          memcpy(t_array, f_array, size);
      }
    }
  } else {
    /* It's just a plain ol' variable. */
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      vp->var_un.var_digit = (unsigned char) var.var_un.var_udigit;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      vp->var_un.var_digit = (unsigned short) var.var_un.var_udigit;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit = var.var_un.var_udigit;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = var.var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = var.var_un.var_rdigit;
      break;
    case VAR_STRING:
      se_new_string(&vp->var_un.var_string, var.var_un.var_string);
      break;
    case VAR_USER:
      do_structure_assignment(vp, &var, 0);
      break;
    }
  }
  if (vp->var_flags & VF_SPECIAL) {
    switch(vp->var_flags & VF_SPECIAL) {
    case VF_KVM:
      se_update_kvm_variable(vp);
      break;
    case VF_KSTAT:
      se_update_kstat_variable(vp);
      break;
    case VF_CLASS:
    case VF_MIB:
      /* updating these values has no special effect */
      break;
    case VF_NDD:
      se_update_ndd_variable(vp);
      break;
    case VF_EXTERN:
      se_update_extern_variable(vp);
      break;
    }
  }
}

static void
run_unary(T_STATEMENT *sp, char bias)
{
  int subscript;
  T_VARIABLE *vp = sp->s_un.s_variable;

  if (vp->var_subscript) {
    subscript = compute_subscript(vp, 1);
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
      ((unsigned char *) vp->var_un.var_array)[subscript] += bias;
      break;
    case VAR_SHORT:
    case VAR_USHORT:
      ((unsigned short *) vp->var_un.var_array)[subscript] += bias;
      break;
    case VAR_LONG:
    case VAR_ULONG:
      ((unsigned int *) vp->var_un.var_array)[subscript] += bias;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      ((T_ULLONG *) vp->var_un.var_array)[subscript] += bias;
      break;
    }
  } else {
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
    case VAR_SHORT:
    case VAR_USHORT:
    case VAR_LONG:
    case VAR_ULONG:
      vp->var_un.var_udigit += bias;
      break;
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit += bias;
      break;
    }
  }
}

static void
run_increment(T_STATEMENT *sp)
{
  run_unary(sp, 1);
}

static void
run_decrement(T_STATEMENT *sp)
{
  run_unary(sp, -1);
}

/* param vp should already have been resolved with resolve_expression */
uchar_t *
se_struct_into_area(T_VARIABLE *vp, uchar_t *supplied)
{
  int n = 1;
  uchar_t *area = supplied;
  int bias = 0;

  if (vp->var_dimension) {
    n = vp->var_dimension;
    bias = -1 * ((T_STRUCT **) vp->var_un.var_array)[0]->st_members->var_offset;
  } else
    bias = -1 * vp->var_un.var_user->st_members->var_offset;

  n *= vp->var_struct->st_size;
  if (area == 0)
    area = (uchar_t *) se_alloc(n);

  struct_empty(vp, (unsigned char *) area, bias);

  return area;
}

/* param vp should already have been resolved with resolve_expression */
void
se_area_into_struct(uchar_t *area, T_VARIABLE *vp)
{
  int bias = 0;
  int i;
  T_VARIABLE var;

  if (vp->var_dimension)
    bias = -1 * ((T_STRUCT **) vp->var_un.var_array)[0]->st_members->var_offset;
  else
    bias = -1 * vp->var_un.var_user->st_members->var_offset;

  if (vp->var_subscript) {
    i = compute_subscript(vp, 0);
    var = *vp;
    var.var_dimension = 0;
    var.var_subscript = 0;
    var.var_un.var_user = ((T_STRUCT **) vp->var_un.var_array)[i];
    struct_fill(&var, (unsigned char *) area, bias);
  } else
    struct_fill(vp, (unsigned char *) area, bias);
}

static void
run_attachment(T_STATEMENT *sp)
{
  int i;
  int n;
  int size;
  unsigned int result;
  T_ULLONG lresult;
  uchar_t *area;
  union {
    unsigned int (*uip)(T_REGISTER, ...);
    T_ULLONG (*ullp)(T_REGISTER, ...);
    double (*dp)(T_REGISTER, ...);
  } pf;
  void *saved_struct_arrays[MAX_ATT_ARGS];
  T_VARIABLE  args[MAX_ATT_ARGS];
  T_FCALL *cp = sp->s_un.s_call;
  T_BLOCK *bp = cp->c_block;
  T_VARIABLE *vp;
  T_VARIABLE var;
  T_EXPR *ep;

  for(i=0; i<MAX_ATT_ARGS; i++)
    args[i] = zero_variable;
  var = zero_variable;

  for(i=0, ep=cp->c_args, vp=bp->b_parameters; ep;
           i++, ep=ep->e_next) {
    resolve_expression(&args[i], ep, 1);
    if (vp && ((vp->var_type & VAR_ELLIPSIS) == 0))
      if (args[i].var_type != vp->var_type)
        /* exceptional case for string actual to char[] formal assigns */
        if (!((args[i].var_type | vp->var_type) == (VAR_CHAR | VAR_STRING)))
          fix_type(&args[i], vp->var_type);
    if (args[i].var_type == VAR_USER) {
      saved_struct_arrays[i] = args[i].var_un.var_array;
      args[i].var_un.var_array = se_struct_into_area(&args[i], 0);
    }
    if (vp)
      vp = vp->var_next;
  }

  pf.dp = (double (*)(T_REGISTER, ...)) bp->b_attachment;
  vp = bp->b_return;
  if (vp == 0) {
    var.var_type = VAR_LONG;
    vp = &var;
  }

  switch(vp->var_type) {
  case VAR_CHAR:
  case VAR_UCHAR:
  case VAR_SHORT:
  case VAR_USHORT:
  case VAR_LONG:
  case VAR_ULONG:
#ifndef _LP64
  case VAR_STRING:
  case VAR_USER:
#endif
    switch(i) {
    case 0:
      result = (*pf.uip)(0);
      break;
    case 1:
      result = (*pf.uip)(
            _PARAM_(args[0]));
      break;
    case 2:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]));
      break;
    case 3:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]));
      break;
    case 4:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]));
      break;
    case 5:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]));
      break;
    case 6:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]));
      break;
    case 7:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]));
      break;
    case 8:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]));
      break;
    case 9:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]));
      break;
    case 10:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]));
      break;
    case 11:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]));
      break;
    case 12:
      result = (*pf.uip)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]),
            _PARAM_(args[11]));
      break;
    }
#ifndef _LP64
    if (vp->var_type == VAR_USER) {
      if (result == 0)
        se_fatal("reference through nil pointer: assign from %s", bp->b_name);
      se_area_into_struct((uchar_t *) result, vp);
    } else
#endif
      vp->var_un.var_udigit = result;
    break;
  case VAR_LONGLONG:
  case VAR_ULONGLONG:
#ifdef _LP64
  case VAR_STRING:
  case VAR_USER:
#endif
    switch(i) {
    case 0:
      lresult = (*pf.ullp)(0);
      break;
    case 1:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]));
      break;
    case 2:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]));
      break;
    case 3:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]));
      break;
    case 4:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]));
      break;
    case 5:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]));
      break;
    case 6:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]));
      break;
    case 7:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]));
      break;
    case 8:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]));
      break;
    case 9:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]));
      break;
    case 10:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]));
      break;
    case 11:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]));
      break;
    case 12:
      lresult = (*pf.ullp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]),
            _PARAM_(args[11]));
      break;
    }
#ifdef _LP64
    if (vp->var_type == VAR_USER) {
      if (lresult == 0)
        se_fatal("reference through nil pointer: assign from %s", bp->b_name);
      se_area_into_struct((uchar_t *) lresult, vp);
    } else
#endif
      vp->var_un.var_uldigit = lresult;
    break;
  case VAR_DOUBLE:
    switch(i) {
    case 0:
      vp->var_un.var_rdigit = (*pf.dp)(0);
      break;
    case 1:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]));
      break;
    case 2:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]));
      break;
    case 3:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]));
      break;
    case 4:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]));
      break;
    case 5:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]));
      break;
    case 6:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]));
      break;
    case 7:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]));
      break;
    case 8:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]));
      break;
    case 9:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]));
      break;
    case 10:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]));
      break;
    case 11:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]));
      break;
    case 12:
      vp->var_un.var_rdigit = (*pf.dp)(
            _PARAM_(args[0]),
            _PARAM_(args[1]),
            _PARAM_(args[2]),
            _PARAM_(args[3]),
            _PARAM_(args[4]),
            _PARAM_(args[5]),
            _PARAM_(args[6]),
            _PARAM_(args[7]),
            _PARAM_(args[8]),
            _PARAM_(args[9]),
            _PARAM_(args[10]),
            _PARAM_(args[11]));
      break;
    }
    break;
  }
  for(i=0, ep=cp->c_args; ep; i++, ep=ep->e_next) {
    if (args[i].var_type == VAR_USER) {
      if (args[i].var_dimension && (args[i].var_subscript == 0)) {
        var = args[i];
        var.var_un.var_array = saved_struct_arrays[i];
        se_area_into_struct((uchar_t *) args[i].var_un.var_array, &var);
      }
      se_free(args[i].var_un.var_array);
    }
  }
}

static void
run_for(T_STATEMENT *sp)
{
  T_FOR *volatile fp = sp->s_un.s_for;

  if (fp->f_before)
    run_statement_list(fp->f_before);
  switch(setjmp(fp->f_jmpbuf)) {
  case DO_BREAK:
    return;
  case DO_CONTINUE:
    if (fp->f_after)
      run_statement_list(fp->f_after);
    break;
  default:
    break;
  }
  for(;;) {
    if (fp->f_while && (resolve_l_expression(fp->f_while) == 0))
      break;
    run_statement_list(fp->f_statements);
    if (fp->f_after)
      run_statement_list(fp->f_after);
  }
}

static void
run_do(T_STATEMENT *sp)
{
  T_DO *volatile dp = sp->s_un.s_do;

  if (setjmp(dp->do_jmpbuf) == DO_BREAK)
    return;
  do
    run_statement_list(dp->do_statements);
  while (resolve_l_expression(dp->do_while));
}

static void
run_switch(T_STATEMENT *stp)
{
  T_SWITCH *volatile sp = stp->s_un.s_switch;
  T_EXPR *volatile ep = sp->sw_expr;
  T_CASE *volatile default_case = sp->sw_default;
  T_VARIABLE var;
  anode *anp;
  T_REGISTER p;

  if (setjmp(sp->sw_jmpbuf))
    return;
  var = zero_variable;
  resolve_expression(&var, ep, 1);
  fix_type(&var, VAR_REGISTER);
  p = var.var_un.var_register;
  if (anp = avlget(sp->sw_cases, (void *) p)) {
    run_statement_list((T_STATEMENT *) anp->an_data);
    return;
  }
  if (default_case && default_case->ca_statements)
    run_statement_list(default_case->ca_statements);
}

static void
run_return(T_STATEMENT *sp)
{
  T_RETURN *rp = sp->s_un.s_return;
  T_STATEMENT statement;
  T_ASSIGN assign;

  /* returning an expression */
  if (rp->ret_expr) {
    assign.a_variable = rp->ret_block->b_return;
    assign.a_op = A_ASSIGN;
    assign.a_expression = rp->ret_expr;
    statement.s_un.s_assign = &assign;
    run_assign(&statement);
  }
  longjmp(sp->s_un.s_return->ret_block->b_jmpbuf, 1);
}

static void
run_break(T_STATEMENT *sp)
{
  T_BREAK *bp = sp->s_un.s_break;

  switch(bp->brk_type) {
  case BRK_SWITCH:
    longjmp(bp->brk_un.brk_switch->sw_jmpbuf, DO_BREAK);
    break;
  case BRK_FOR:
    longjmp(bp->brk_un.brk_for->f_jmpbuf, DO_BREAK);
    break;
  case BRK_DO:
    longjmp(bp->brk_un.brk_do->do_jmpbuf, DO_BREAK);
    break;
  case BRK_WHILE:
    longjmp(bp->brk_un.brk_while->w_jmpbuf, DO_BREAK);
    break;
  }
}

static void
run_continue(T_STATEMENT *sp)
{
  T_CONTINUE *cp = sp->s_un.s_continue;

  switch(cp->con_type) {
  case CON_FOR:
    longjmp(cp->con_un.con_for->f_jmpbuf, DO_CONTINUE);
    break;
  case CON_WHILE:
    longjmp(cp->con_un.con_while->w_jmpbuf, DO_CONTINUE);
    break;
  case CON_DO:
    longjmp(cp->con_un.con_do->do_jmpbuf, DO_CONTINUE);
    break;
  }
}

static int
resolve_l_expression(T_LEXPR *ep)
{
  char expbuf[BUFSIZ];
  int n;
  T_VARIABLE left;
  T_VARIABLE right;
  regex_t re;
  int reg_status;

  left = zero_variable;
  right = zero_variable;

  switch(ep->le_op) {
  case LE_EQ:
  case LE_RE_EQ:
  case LE_RE_NEQ:
  case LE_NE:
  case LE_LT:
  case LE_GT:
  case LE_GE:
  case LE_LE:
    resolve_expression(&left, ep->le_left, 1);
    resolve_expression(&right, ep->le_right, 1);
    if (left.var_dimension && (left.var_type == VAR_CHAR))
      left.var_type = VAR_STRING;
    if (right.var_dimension && (right.var_type == VAR_CHAR))
      right.var_type = VAR_STRING;
    if (left.var_type & VAR_NUMERIC)
      if (left.var_type != right.var_type)
        if (left.var_type < right.var_type)
          fix_type(&left, right.var_type);
        else
          fix_type(&right, left.var_type);
    break;
  default:
    break;
  }

  switch(ep->le_op) {
  case LE_RE_EQ:
    if (right.var_un.var_string == 0 || left.var_un.var_string == 0)
      se_fatal("reference through nil pointer: op \"=~\"");
    reg_status = regcomp(&re, right.var_un.var_string, REG_EXTENDED|REG_NOSUB);
    if (reg_status != 0)
      se_fatal("compile failed: op \"=~\", reason = %d", reg_status);
    reg_status = regexec(&re, left.var_un.var_string, 0, NULL, 0);
    regfree(&re);
    return reg_status == 0;
  case LE_RE_NEQ:
    if (right.var_un.var_string == 0 || left.var_un.var_string == 0)
      se_fatal("reference through nil pointer: op \"!=~\"");
    reg_status = regcomp(&re, right.var_un.var_string, REG_EXTENDED|REG_NOSUB);
    if (reg_status != 0)
      se_fatal("compile failed: op \"!~\", reason = %d", reg_status);
    reg_status = regexec(&re, left.var_un.var_string, 0, NULL, 0);
    regfree(&re);
    return reg_status != 0;
  case LE_EQ:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   == right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  == right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  == right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit == right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  == right.var_un.var_rdigit);
    case VAR_STRING:
      if (left.var_un.var_string == 0)
        return (right.var_un.var_string == 0);
      else if (right.var_un.var_string == 0)
        return 0;
      if (left.var_un.var_string[0] != right.var_un.var_string[0])
        return 0;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) == 0);
    }
    break;
  case LE_NE:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   != right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  != right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  != right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit != right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  != right.var_un.var_rdigit);
    case VAR_STRING:
      if (left.var_un.var_string == 0)
        return (right.var_un.var_string != 0);
      else if (right.var_un.var_string == 0)
        return 1;
      if (left.var_un.var_string[0] != right.var_un.var_string[0])
        return 1;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) != 0);
    }
    break;
  case LE_LT:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   < right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  < right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  < right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit < right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  < right.var_un.var_rdigit);
    case VAR_STRING:
       if ((left.var_un.var_string == 0) || (right.var_un.var_string == 0))
        se_fatal("reference through nil pointer: op \"<\"");
      if (left.var_un.var_string[0] < right.var_un.var_string[0])
        return 1;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) < 0);
    }
    break;
  case LE_GT:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   > right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  > right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  > right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit > right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  > right.var_un.var_rdigit);
    case VAR_STRING:
      if ((left.var_un.var_string == 0) || (right.var_un.var_string == 0))
        se_fatal("reference through nil pointer: op \">\"");
      if (left.var_un.var_string[0] > right.var_un.var_string[0])
        return 1;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) > 0);
    }
    break;
  case LE_GE:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   >= right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  >= right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  >= right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit >= right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  >= right.var_un.var_rdigit);
    case VAR_STRING:
      if ((left.var_un.var_string == 0) || (right.var_un.var_string == 0))
        se_fatal("reference through nil pointer: op \">=\"");
      if (left.var_un.var_string[0] >= right.var_un.var_string[0])
        return 1;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) >= 0);
    }
    break;
  case LE_LE:
    switch(left.var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      return (left.var_un.var_digit   <= right.var_un.var_digit);
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      return (left.var_un.var_udigit  <= right.var_un.var_udigit);
    case VAR_LONGLONG:
      return (left.var_un.var_ldigit  <= right.var_un.var_ldigit);
    case VAR_ULONGLONG:
      return (left.var_un.var_uldigit <= right.var_un.var_uldigit);
    case VAR_DOUBLE:
      return (left.var_un.var_rdigit  <= right.var_un.var_rdigit);
    case VAR_STRING:
      if ((left.var_un.var_string == 0) || (right.var_un.var_string == 0))
        se_fatal("reference through nil pointer: op \"<=\"");
      if (left.var_un.var_string[0] <= right.var_un.var_string[0])
        return 1;
      return (strcmp(left.var_un.var_string, right.var_un.var_string) <= 0);
    }
    break;
  case LE_AND:
    return (resolve_l_expression((T_LEXPR *) ep->le_left) &&
            resolve_l_expression((T_LEXPR *) ep->le_right));
  case LE_OR:
    return (resolve_l_expression((T_LEXPR *) ep->le_left) ||
            resolve_l_expression((T_LEXPR *) ep->le_right));
  case LE_PREC:
    return resolve_l_expression((T_LEXPR *) ep->le_left);
  case LE_NOT:
    return (resolve_l_expression((T_LEXPR *) ep->le_left) == 0);
  }
}

static char *
expr_name(T_EXPR *ep)
{
  switch(ep->e_type) {
  case E_VALUE:
    if (ep->e_variable->var_name)
      return ep->e_variable->var_name;
    return "CONSTANT";
  case E_EXPRESSION:
    return "EXPRESSION";
  case E_QCOP:
    return "QC OPERATOR";
  case E_CALL:
    if (ep->e_call->c_name)
      return ep->e_call->c_name;
    return "<block>";
  case E_ASSIGN:
    return "ASSIGNMENT";
  default:
    return "<impossible>";
  }
}
  
/* this function must always do assignments into anonymous variables */
static void
resolve_expression(T_VARIABLE *vp, T_EXPR *ep, int runit)
{
  char *left_name;
  char *right_name;
  int subscript = 0;
  double left;
  double right;
  double result;
  void *array;
  T_VARIABLE *vvp;
  T_VARIABLE left_var;
  T_VARIABLE right_var;
  T_VARIABLE *member_list[MAX_DOTS];
  T_VARIABLE *tmpv;
  T_STATEMENT statement;

  switch(ep->e_type) {
  case E_VALUE:
  case E_CALL:
    if (ep->e_type == E_VALUE) {
      vvp = ep->e_variable;
    } else {
      statement.s_un.s_call = ep->e_call;
      run_call(&statement);
      vvp = ep->e_call->c_block->b_return;
    }
    if (vvp->var_name && (vvp->var_flags & VF_SPECIAL)) {
      switch(vvp->var_flags & VF_SPECIAL) {
      case VF_KVM:
        se_refresh_kvm_variable(vvp);
        break;
      case VF_KSTAT:
        se_refresh_kstat_variable(vvp);
        break;
      case VF_CLASS:
        run_class(vvp);
        break;
      case VF_MIB:
        se_refresh_mib_variable(vvp);
        break;
      case VF_NDD:
        se_refresh_ndd_variable(vvp);
        break;
      case VF_EXTERN:
        se_refresh_extern_variable(vvp);
        break;
      }
    }
    if (vvp->var_subscript) {
      subscript = compute_subscript(vvp, runit);
      array = vvp->var_un.var_array;
      switch(vvp->var_type) {
      case VAR_CHAR:
      case VAR_UCHAR:
        vp->var_type = vvp->var_type;
        vp->var_un.var_udigit = ((unsigned char *) array)[subscript];
        break;
      case VAR_SHORT:
      case VAR_USHORT:
        vp->var_type = vvp->var_type;
        vp->var_un.var_udigit = ((unsigned short *) array)[subscript];
        break;
      case VAR_LONG:
      case VAR_ULONG:
        vp->var_type = vvp->var_type;
        vp->var_un.var_udigit = ((unsigned int *) array)[subscript];
        break;
      case VAR_LONGLONG:
      case VAR_ULONGLONG:
        vp->var_type = vvp->var_type;
        vp->var_un.var_uldigit = ((T_ULLONG *) array)[subscript];
        break;
      case VAR_DOUBLE:
        vp->var_type = VAR_DOUBLE;
        vp->var_un.var_rdigit = ((double *) array)[subscript];
        break;
      case VAR_STRING:
        vp->var_type = VAR_STRING;
        vp->var_un.var_string = ((char **) array)[subscript];
        break;
      case VAR_USER:
        vp->var_type = VAR_USER;
        vp->var_struct = vvp->var_struct;
        vp->var_un.var_user = ((T_STRUCT **) array)[subscript];
        break;
      }
    /* Switching on the type to copy no more than 8 bytes is overhead. *
     * Just get to the business and copy it over.  Nevermind the work. */
    } else
      *vp = *vvp;
    break;
  case E_EXPRESSION:
    if (ep->e_op == EO_PRECEDENCE) {
      resolve_expression(vp, ep->e_left, runit);
      break;
    }
    if (ep->e_op == EO_BIT_NOT) {
      resolve_expression(vp, ep->e_left, runit);
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
        vp->var_un.var_digit = ~vp->var_un.var_digit;
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
        vp->var_un.var_udigit = ~vp->var_un.var_udigit;
        break;
      case VAR_LONGLONG:
        vp->var_un.var_ldigit = ~vp->var_un.var_ldigit;
        break;
      case VAR_ULONGLONG:
        vp->var_un.var_uldigit = ~vp->var_un.var_uldigit;
        break;
      }
      break;
    }

    left_var = zero_variable;
    right_var = zero_variable;

    resolve_expression(&left_var, ep->e_left, runit);
    resolve_expression(&right_var, ep->e_right, runit);

    /* as it turns out, the enum values for the types are ordered according *
     * to the maximum value that a variable of that type could hold         */

    vp->var_type = (left_var.var_type > right_var.var_type) ?
                    left_var.var_type : right_var.var_type;

    if (left_var.var_type != vp->var_type)
      fix_type(&left_var, vp->var_type);
    if (right_var.var_type != vp->var_type)
      fix_type(&right_var, vp->var_type);

    switch(left_var.var_type) {
    case VAR_CHAR:
      left = (double) ((char) left_var.var_un.var_digit);
      break;
    case VAR_SHORT:
      left = (double) ((short) left_var.var_un.var_digit);
      break;
    case VAR_LONG:
      left = (double) left_var.var_un.var_digit;
      break;
    case VAR_UCHAR:
      left = (double) ((unsigned char) left_var.var_un.var_udigit);
      break;
    case VAR_USHORT:
      left = (double) ((unsigned short) left_var.var_un.var_udigit);
      break;
    case VAR_ULONG:
      left = (double) left_var.var_un.var_udigit;
      break;
    case VAR_LONGLONG:
      left = (double) left_var.var_un.var_ldigit;
      break;
    case VAR_ULONGLONG:
      left = (double) left_var.var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      left = left_var.var_un.var_rdigit;
      break;
    }

    switch(right_var.var_type) {
    case VAR_CHAR:
      right = (double) ((char) right_var.var_un.var_digit);
      break;
    case VAR_SHORT:
      right = (double) ((unsigned short) right_var.var_un.var_udigit);
      break;
    case VAR_LONG:
      right = (double) right_var.var_un.var_digit;
      break;
    case VAR_UCHAR:
      right = (double) ((unsigned char) right_var.var_un.var_udigit);
      break;
    case VAR_USHORT:
      right = (double) ((unsigned short) right_var.var_un.var_udigit);
      break;
    case VAR_ULONG:
      right = (double) right_var.var_un.var_udigit;
      break;
    case VAR_LONGLONG:
      right = (double) right_var.var_un.var_ldigit;
      break;
    case VAR_ULONGLONG:
      right = (double) right_var.var_un.var_uldigit;
      break;
    case VAR_DOUBLE:
      right = right_var.var_un.var_rdigit;
      break;
    }

    switch(ep->e_op) {
    case EO_ADD:
      result = left + right;
      break;
    case EO_SUBTRACT:
      result = left - right;
      break;
    case EO_MULTIPLY:
      result = left * right;
      break;
    case EO_DIVIDE:
      if (right == 0) {
        left_name = expr_name(ep->e_left);
        right_name = expr_name(ep->e_right);
        se_fatal("division by zero: (%s / %s)", left_name, right_name);
      }
      result = left / right;
      break;
    case EO_MODULUS:
      result = (double) (((T_LLONG) left) % ((T_LLONG) right));
      break;
    case EO_BIT_AND:
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_LONGLONG:
        result = (double) (((T_LLONG) left) & ((T_LLONG) right));
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
      case VAR_ULONGLONG:
        result = (double) (((T_ULLONG) left) & ((T_ULLONG) right));
        break;
      }
      break;
    case EO_BIT_OR:
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_LONGLONG:
        result = (double) (((T_LLONG) left) | ((T_LLONG) right));
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
      case VAR_ULONGLONG:
        result = (double) (((T_ULLONG) left) | ((T_ULLONG) right));
        break;
      }
      break;
    case EO_BIT_XOR:
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_LONGLONG:
        result = (double) (((T_LLONG) left) ^ ((T_LLONG) right));
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
      case VAR_ULONGLONG:
        result = (double) (((T_ULLONG) left) ^ ((T_ULLONG) right));
        break;
      }
      break;
    case EO_SHIFT_LEFT:
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_LONGLONG:
        result = (double) (((T_LLONG) left) << ((T_LLONG) right));
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
      case VAR_ULONGLONG:
        result = (double) (((T_ULLONG) left) << ((T_ULLONG) right));
        break;
      }
      break;
    case EO_SHIFT_RIGHT:
      switch(vp->var_type) {
      case VAR_CHAR:
      case VAR_SHORT:
      case VAR_LONG:
      case VAR_LONGLONG:
        result = (double) (((T_LLONG) left) >> ((T_LLONG) right));
        break;
      case VAR_UCHAR:
      case VAR_USHORT:
      case VAR_ULONG:
      case VAR_ULONGLONG:
        result = (double) (((T_ULLONG) left) >> ((T_ULLONG) right));
        break;
      }
      break;
    }
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_SHORT:
    case VAR_LONG:
      vp->var_un.var_digit = (int) result;
      break;
    case VAR_UCHAR:
    case VAR_USHORT:
    case VAR_ULONG:
      vp->var_un.var_udigit = (unsigned int) result;
      break;
    case VAR_LONGLONG:
      vp->var_un.var_ldigit = (T_LLONG) result;
      break;
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = (T_ULLONG) result;
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = result;
      break;
    }
    break;
  case E_QCOP:
    /* use of such for it's own resolution */
    resolve_expression(vp,
      resolve_l_expression(ep->e_lexpr) ? ep->e_left : ep->e_right, runit);
    break;
  case E_INCRA:
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_INCRA;
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, 1);
    }
    break;
  case E_INCRB:
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, 1);
    }
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_INCRB;
    break;
  case E_DECRA:
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_DECRA;
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, -1);
    }
    break;
  case E_DECRB:
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, -1);
    }
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_DECRB;
    break;
  case E_LAZY_INCRA:
    tmpv = ep->e_variable;
    ep->e_variable = get_lazy_member(tmpv, member_list);
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, 1);
    }
    ep->e_type = E_LAZY_INCRA;
    ep->e_variable = tmpv;
    break;
  case E_LAZY_INCRB:
    tmpv = ep->e_variable;
    ep->e_variable = get_lazy_member(tmpv, member_list);
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, 1);
    }
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_LAZY_INCRB;
    ep->e_variable = tmpv;
    break;
  case E_LAZY_DECRA:
    tmpv = ep->e_variable;
    ep->e_variable = get_lazy_member(tmpv, member_list);
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, -1);
    }
    ep->e_type = E_LAZY_DECRA;
    ep->e_variable = tmpv;
    break;
  case E_LAZY_DECRB:
    tmpv = ep->e_variable;
    ep->e_variable = get_lazy_member(tmpv, member_list);
    if (runit) {
      statement.s_un.s_variable = ep->e_variable;
      run_unary(&statement, -1);
    }
    ep->e_type = E_VALUE;
    resolve_expression(vp, ep, runit);
    ep->e_type = E_LAZY_DECRB;
    ep->e_variable = tmpv;
    break;
  case E_ASSIGN:
    statement = zero_statement;
    statement.s_type = S_ASSIGN;
    statement.s_un.s_assign = ep->e_assign;
    run_assign(&statement);
    *vp = *ep->e_assign->a_variable;
    break;
  }
}

static void
do_structure_assignment(T_VARIABLE *to, T_VARIABLE *from, int force)
{
  int i;
  int n;
  void *t_array;
  void *f_array;
  T_VARIABLE *tp;
  T_VARIABLE *fp;
  T_VARIABLE t_var;
  T_VARIABLE f_var;

  for(tp=to->var_un.var_user->st_members,
      fp=from->var_un.var_user->st_members; tp; tp=tp->var_next,
                                                fp=fp->var_next) {
    if (fp->var_dimension) {
      /* force the target array to look like the source array */
      if (force && (tp->var_dimension != fp->var_dimension))
        se_clone_array(tp, fp);
      f_array = fp->var_un.var_array;
      t_array = tp->var_un.var_array;
      /* this code is consistent with run_assign */
      if ((tp->var_dimension == -1) && (fp->var_dimension != -1)) {
        se_clone_array(tp, fp);
        t_array = tp->var_un.var_array;
      }
      switch(tp->var_type) {
      case VAR_STRING:
        for(i=0; i<tp->var_dimension; i++)
          se_new_string(((char **) t_array) + i, ((char **) f_array)[i]);
        break;
      case VAR_USER:
        t_var = *tp;
        t_var.var_dimension = 0;
        f_var = t_var;
        for(i=0; i<tp->var_dimension; i++) {
          t_var.var_un.var_user = ((T_STRUCT **) t_array)[i];
          f_var.var_un.var_user = ((T_STRUCT **) f_array)[i];
          do_structure_assignment(&t_var, &f_var, force);
        }
        break;
      default:
        n = (tp->var_dimension == -1) ? 1 : tp->var_dimension;
        n *= Se_type_sizes[tp->var_type];
        if ((t_array == 0) || (f_array == 0)) {
          if ((fp->var_flags & VF_SPECIAL) != VF_KVM)
            se_fatal("reference through nil pointer assigning to %s",
                      tp->var_name);
        } else
          memcpy(t_array, f_array, n);
        break;
      }
    } else {
      switch(tp->var_type) {
      case VAR_STRING:
        se_new_string(&tp->var_un.var_string, fp->var_un.var_string);
        break;
      case VAR_USER:
        do_structure_assignment(tp, fp, force);
        break;
      default:
        tp->var_un.var_uldigit = fp->var_un.var_uldigit;
        break;
      }
    }
  }
}

/*
 * the bullshit you see in this function is due to sign extension/deletion
 * of the compiler.  I can't make an (int) -1 change to a (long) -1 on LP64.
 */

static void
fix_type(T_VARIABLE *vp, T_VARTYPE type)
{
  typedef enum { _I64, _U64, _DP } source_t;
  source_t source;
  void *tmp;
  int i;
  long long i64;
  unsigned long long u64;
  double dbl_prec;

  /* don't mess with my mind man */
  if (type == vp->var_type)
    return;

  /* grok the special case "string p = ((string) ul);" */
  if ((vp->var_type & VAR_INTEGRAL) && (type == VAR_STRING)) {
    vp->var_type = VAR_STRING;
    return;
  }
  /* grok the special case "ulong_t u = ((ulong_t) "string");" */
  if ( ((vp->var_type == VAR_STRING) ||
       ((vp->var_type == VAR_CHAR) && vp->var_dimension) &&
        (vp->var_subscript == 0))
    && (type & VAR_INTEGRAL)) {
    vp->var_type = VAR_REGISTER;
    return;
  }

  /* extract the orignal value that will be type-changed */
  if (vp->var_dimension && (vp->var_subscript == 0)) {
    tmp = vp->var_un.var_array;
    vp->var_un.var_array = se_alloc(vp->var_dimension * Se_type_sizes[type]);
    for(i=0; i<vp->var_dimension; i++) {
      switch(vp->var_type) {
      case VAR_CHAR:
        i64 = ((char *) tmp)[i];
        source = _I64;
        break;
      case VAR_SHORT:
        i64 = ((short *) tmp)[i];
        source = _I64;
        break;
      case VAR_LONG:
        i64 = ((int *) tmp)[i];
        source = _I64;
        break;
      case VAR_LONGLONG:
        i64 = ((long long *) tmp)[i];
        source = _I64;
        break;
      case VAR_UCHAR:
        u64 = ((unsigned char *) tmp)[i];
        source = _U64;
        break;
      case VAR_USHORT:
        u64 = ((unsigned short *) tmp)[i];
        source = _U64;
        break;
      case VAR_ULONG:
        u64 = ((unsigned int *) tmp)[i];
        source = _U64;
        break;
      case VAR_ULONGLONG:
        u64 = ((unsigned long long *) tmp)[i];
        source = _U64;
        break;
      case VAR_DOUBLE:
        dbl_prec = ((double *) tmp)[i];
        source = _DP;
        break;
      }

      switch(source) {
      case _I64:
        switch(type) {
        case VAR_CHAR:
          ((char *) vp->var_un.var_array)[i] = (char) i64;
          break;
        case VAR_SHORT:
          ((short *) vp->var_un.var_array)[i] = (short) i64;
          break;
        case VAR_LONG:
          ((int *) vp->var_un.var_array)[i] = (int) i64;
          break;
        case VAR_LONGLONG:
          ((long long *) vp->var_un.var_array)[i] = (long long) i64;
          break;
        case VAR_UCHAR:
          ((unsigned char *) vp->var_un.var_array)[i] = (char) i64;
          break;
        case VAR_USHORT:
          ((unsigned short *) vp->var_un.var_array)[i] = (short) i64;
          break;
        case VAR_ULONG:
          ((unsigned int *) vp->var_un.var_array)[i] = (int) i64;
          break;
        case VAR_ULONGLONG:
          ((unsigned long long *) vp->var_un.var_array)[i] = (long long) i64;
          break;
        case VAR_DOUBLE:
          ((double *) vp->var_un.var_array)[i] = (double) i64;
          break;
        }
        break;
      case _U64:
        switch(type) {
        case VAR_CHAR:
          ((char *) vp->var_un.var_array)[i] = (char) u64;
          break;
        case VAR_SHORT:
          ((short *) vp->var_un.var_array)[i] = (short) u64;
          break;
        case VAR_LONG:
          ((int *) vp->var_un.var_array)[i] = (int) u64;
          break;
        case VAR_LONGLONG:
          ((long long *) vp->var_un.var_array)[i] = (long long) u64;
          break;
        case VAR_UCHAR:
          ((unsigned char *) vp->var_un.var_array)[i] = (char) u64;
          break;
        case VAR_USHORT:
          ((unsigned short *) vp->var_un.var_array)[i] = (short) u64;
          break;
        case VAR_ULONG:
          ((unsigned int *) vp->var_un.var_array)[i] = (int) u64;
          break;
        case VAR_ULONGLONG:
          ((unsigned long long *) vp->var_un.var_array)[i] = (long long) u64;
          break;
        case VAR_DOUBLE:
          ((double *) vp->var_un.var_array)[i] = (double) u64;
          break;
        }
        break;
      case _DP:
        switch(type) {
        case VAR_CHAR:
          ((char *) vp->var_un.var_array)[i] = (char) dbl_prec;
          break;
        case VAR_SHORT:
          ((short *) vp->var_un.var_array)[i] = (short) dbl_prec;
          break;
        case VAR_LONG:
          ((int *) vp->var_un.var_array)[i] = (int) dbl_prec;
          break;
        case VAR_LONGLONG:
          ((long long *) vp->var_un.var_array)[i] = (long long) dbl_prec;
          break;
        case VAR_UCHAR:
          ((unsigned char *) vp->var_un.var_array)[i] = (char) dbl_prec;
          break;
        case VAR_USHORT:
          ((unsigned short *) vp->var_un.var_array)[i] = (short) dbl_prec;
          break;
        case VAR_ULONG:
          ((unsigned int *) vp->var_un.var_array)[i] = (int) dbl_prec;
          break;
        case VAR_ULONGLONG:
          ((unsigned long long *) vp->var_un.var_array)[i] =
            (long long) dbl_prec;
          break;
        case VAR_DOUBLE:
          ((double *) vp->var_un.var_array)[i] = (double) dbl_prec;
          break;
        }
        break;
      }
    }
    vp->var_type = type;
    se_free(tmp);
    return;
  }

  switch(vp->var_type) {
  case VAR_CHAR:
    i64 = vp->var_un.var_digit;
    source = _I64;
    break;
  case VAR_SHORT:
    i64 = vp->var_un.var_digit;
    source = _I64;
    break;
  case VAR_LONG:
    i64 = vp->var_un.var_digit;
    source = _I64;
    break;
  case VAR_LONGLONG:
    i64 = vp->var_un.var_ldigit;
    source = _I64;
    break;
  case VAR_UCHAR:
    u64 = vp->var_un.var_udigit;
    source = _U64;
    break;
  case VAR_USHORT:
    u64 = vp->var_un.var_udigit;
    source = _U64;
    break;
  case VAR_ULONG:
    u64 = vp->var_un.var_udigit;
    source = _U64;
    break;
  case VAR_ULONGLONG:
    u64 = vp->var_un.var_uldigit;
    source = _U64;
    break;
  case VAR_DOUBLE:
    dbl_prec = vp->var_un.var_rdigit;
    source = _DP;
    break;
  }

  vp->var_type = type;

  switch(source) {
  case _I64:
    switch(type) {
    case VAR_CHAR:
      vp->var_un.var_digit = (int) i64;
      break;
    case VAR_SHORT:
      vp->var_un.var_digit = (int) i64;
      break;
    case VAR_LONG:
      vp->var_un.var_digit = (int) i64;
      break;
    case VAR_LONGLONG:
      vp->var_un.var_ldigit = i64;
      break;
    case VAR_UCHAR:
      vp->var_un.var_udigit = (unsigned int) i64;
      break;
    case VAR_USHORT:
      vp->var_un.var_udigit = (unsigned int) i64;
      break;
    case VAR_ULONG:
      vp->var_un.var_udigit = (unsigned int) i64;
      break;
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = (T_ULLONG) i64;
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = (double) i64;
      break;
    }
    break;
  case _U64:
    switch(type) {
    case VAR_CHAR:
      vp->var_un.var_digit = (int) u64;
      break;
    case VAR_SHORT:
      vp->var_un.var_digit = (int) u64;
      break;
    case VAR_LONG:
      vp->var_un.var_digit = (int) u64;
      break;
    case VAR_LONGLONG:
      vp->var_un.var_ldigit = (T_LLONG) u64;
      break;
    case VAR_UCHAR:
      vp->var_un.var_udigit = (unsigned int) u64;
      break;
    case VAR_USHORT:
      vp->var_un.var_udigit = (unsigned int) u64;
      break;
    case VAR_ULONG:
      vp->var_un.var_udigit = (unsigned int) u64;
      break;
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = u64;
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = (double) u64;
      break;
    }
    break;
  case _DP:
    switch(type) {
    case VAR_CHAR:
      vp->var_un.var_digit = (int) dbl_prec;
      break;
    case VAR_SHORT:
      vp->var_un.var_digit = (int) dbl_prec;
      break;
    case VAR_LONG:
      vp->var_un.var_digit = (int) dbl_prec;
      break;
    case VAR_LONGLONG:
      vp->var_un.var_ldigit = (T_LLONG) dbl_prec;
      break;
    case VAR_UCHAR:
      vp->var_un.var_udigit = (unsigned int) dbl_prec;
      break;
    case VAR_USHORT:
      vp->var_un.var_udigit = (unsigned int) dbl_prec;
      break;
    case VAR_ULONG:
      vp->var_un.var_udigit = (unsigned int) dbl_prec;
      break;
    case VAR_ULONGLONG:
      vp->var_un.var_uldigit = (T_ULLONG) dbl_prec;
      break;
    case VAR_DOUBLE:
      vp->var_un.var_rdigit = dbl_prec;
      break;
    }
    break;
  }
}

void
se_fix_type(T_VARIABLE *vp, T_VARTYPE type)
{
  fix_type(vp, type);
}

void
se_fatal(char *format, ...)
{
  va_list args;

  va_start(args, format);
  fputs("Fatal: ", stderr);
  vfprintf(stderr, format, args);
  if (line_no)
    fprintf(stderr, ": Near line %d\n", line_no);
  else
    putc('\n', stderr);
  va_end(args);
  exit(1);
}

void
se_warning(char *format, ...)
{
  va_list args;

  if (Se_flags & SE_WARNING)
    return;
  va_start(args, format);
  fputs("Warning: ", stderr);
  vfprintf(stderr, format, args);
  if (line_no)
    fprintf(stderr, ": Near line %d\n", line_no);
  else
    putc('\n', stderr);
  va_end(args);
}

static void
initialize_variable(T_VARIABLE *vp, T_EXPR *ep)
{
  T_STATEMENT svar;
  T_ASSIGN avar;

  /* fake it */
  svar = zero_statement;
  avar.a_variable = vp;
  avar.a_op = A_ASSIGN;
  avar.a_expression = ep;
  svar.s_type = S_ASSIGN;
  svar.s_line_no = Lex_line_no;
  svar.s_un.s_assign = &avar;
  run_assign(&svar);
}

static void
init_globals(anode *anp, int do_vars)
{
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_VARIABLE *vp;
  T_BLOCK *bp;

  if ((sp == 0) || (sp->sym_type != SYM_VARIABLE))
    return;

  vp = sp->sym_un.sym_variable;
  if (do_vars) {
    if (vp->var_initial)
      initialize_variable(vp, vp->var_initial);
  } else {
    if ((vp->var_flags & VF_SPECIAL) == VF_CLASS) {
      bp = vp->var_struct->st_class;
      if ((bp->b_flags & B_INITIAL_CALL) == 0) {
        bp->b_flags |= B_INITIAL_CALL;
        run_class(vp);
      }
    }
  }
}

static int
compute_subscript(T_VARIABLE *vp, int runit)
{
  int subscript;
  T_VARIABLE var;

  var = zero_variable;
  resolve_expression(&var, vp->var_subscript, runit);
  if (Se_type_sizes[var.var_type] != Se_type_sizes[VAR_LONG])
    fix_type(&var, VAR_LONG);
  subscript = var.var_un.var_digit;
  if ((subscript < 0) || (subscript >= vp->var_dimension))
    se_fatal("subscript: %d out of range for: %s[%d]",
              subscript, vp->var_name, vp->var_dimension);
  return subscript;
}

static T_VARIABLE *
get_lazy_member(T_VARIABLE *vp, T_VARIABLE *member_list[])
{
  int i;
  int subscript;
  int member_count = 0;
  anode *anp;
  T_EXPR *sub;
  T_STRUCT *stp;
  T_VARIABLE *vvp;
  T_VARIABLE *mvp;
  T_VARIABLE *xvp;
  T_VARIABLE *parent;

  for(parent=vp->var_parent; parent; parent=parent->var_parent) {
    if (member_count == MAX_DOTS)
      se_fatal("dot notation overflow");
    member_list[member_count++] = parent;
  }
  for(i=member_count-1, mvp=parent=member_list[i]; i>=0; i--, parent=vvp) {
    if (mvp->var_subscript) {
      subscript = compute_subscript(mvp, 1);
      stp = ((T_STRUCT **) parent->var_un.var_array)[subscript];
    } else
      stp = parent->var_un.var_user;
    if (i == 0)
      mvp = vp;
    else
      mvp = member_list[i - 1];
    for(vvp=stp->st_members; vvp; vvp=vvp->var_next)
      if (strcmp(mvp->var_name, vvp->var_name) == 0)
        break;
    if (vvp == 0)
      se_fatal("cannot evaluate member: %s", mvp->var_name);
  }
  return vvp;
}

static void
run_lazy_value(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *vp = cp->c_args->e_variable;
  T_VARIABLE *member_list[MAX_DOTS];
  T_VARIABLE *vvp = get_lazy_member(vp, member_list);

  *cp->c_block->b_return = *vvp;
  cp->c_block->b_return->var_subscript = vp->var_subscript;
  cp->c_block->b_return->var_parent = member_list[0];
}

static void
run_lazy_lvalue(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *vp = cp->c_args->e_variable;
  T_STATEMENT *ssp = (T_STATEMENT *) vp->var_un.var_register;
  T_STATEMENT statement;
  T_ASSIGN *ap;
  T_ASSIGN assign;
  T_VARIABLE *vvp;
  T_VARIABLE *member_list[MAX_DOTS];

  switch(ssp->s_type) {
  case S_ASSIGN:
    ap = ssp->s_un.s_assign;
    vp = ap->a_variable;
    vvp = get_lazy_member(vp, member_list);
    vvp->var_subscript = vp->var_subscript;
    vvp->var_parent = member_list[0];
    assign = *ap;
    assign.a_variable = vvp;
    statement = *ssp;
    statement.s_un.s_assign = &assign;
    run_assign(&statement);
    vvp->var_subscript = 0;
    break;
  case S_INCREMENT:
  case S_DECREMENT:
    vp = ssp->s_un.s_variable;
    vvp = get_lazy_member(vp, member_list);
    vvp->var_subscript = vp->var_subscript;
    vvp->var_parent = member_list[0];
    statement = *ssp;
    statement.s_un.s_variable = vvp;
    if (ssp->s_type == S_INCREMENT)
      run_increment(&statement);
    else
      run_decrement(&statement);
    break;
  }
}

T_VARIABLE *
se_function_call(char *fn, ...)
{
  va_list args;
  T_BLOCK *bp;
  T_VARIABLE *vp;
  T_VARIABLE var;
  T_EXPR expr;

  if (fn == 0)
    return 0;
  bp = se_get_block(fn);
  if (bp == 0)
    return 0;
  va_start(args, fn);
  var = zero_variable;
  expr = zero_expr;
  expr.e_type = E_VALUE;
  for(vp=bp->b_parameters; vp; vp=vp->var_next) {
    var.var_type = vp->var_type;
    switch(vp->var_type) {
    case VAR_CHAR:
    case VAR_UCHAR:
    case VAR_SHORT:
    case VAR_USHORT:
      var.var_un.var_udigit = va_arg(args, unsigned int);
      break;
    case VAR_LONG:
    case VAR_ULONG:
    case VAR_STRING:
    case VAR_USER:
      var.var_un.var_register = va_arg(args, T_REGISTER);
      break;
    /* these "won't" happen on ILP32 */
    case VAR_LONGLONG:
    case VAR_ULONGLONG:
      var.var_un.var_uldigit = va_arg(args, T_ULLONG);
      break;
    case VAR_DOUBLE:
      var.var_un.var_rdigit = va_arg(args, double);
      break;
    }
    if (vp->var_dimension || (vp->var_type == VAR_USER))
      expr.e_variable = (T_VARIABLE *) var.var_un.var_register;
    else
      expr.e_variable = &var;
    se_run_assign(vp, &expr);
  }
  va_end(args);
  run_block(bp);
  return bp->b_return;
}

void
se_resolve_expression(T_VARIABLE *vp, T_EXPR *ep, int runit)
{
  resolve_expression(vp, ep, runit);
}

void
se_run_assign(T_VARIABLE *vp, T_EXPR *ep)
{
  T_STATEMENT s;
  T_ASSIGN a;

  a = zero_assign;
  a.a_variable = vp;
  a.a_op = A_ASSIGN;
  a.a_expression = ep;

  s = zero_statement;
  s.s_type = S_ASSIGN;
  s.s_line_no = Lex_line_no;
  s.s_un.s_assign = &a;

  run_assign(&s);
}

void
se_run_block(T_BLOCK *bp)
{
  run_block(bp);
}

int
se_compute_subscript(T_VARIABLE *vp, int runit)
{
  return compute_subscript(vp, runit);
}

void
se_structure_assignment(T_VARIABLE *to, T_VARIABLE *from)
{
  do_structure_assignment(to, from, 0);
}

/* math functions */

static double
run_dbl(T_EXPR *ep, double (*math_func)(double))
{
  T_VARIABLE arg;

  arg = zero_variable;
  resolve_expression(&arg, ep, 1);
  fix_type(&arg, VAR_DOUBLE);
  return (*math_func)(arg.var_un.var_rdigit);
}

static double
run_2dbl(T_EXPR *ep, double (*math_func)(double, double))
{
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  fix_type(&arg2, VAR_DOUBLE);
  return (*math_func)(arg1.var_un.var_rdigit, arg2.var_un.var_rdigit);
}

static void run_acos(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, acos);
}

static void run_acosh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, acosh);
}

static void run_asin(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, asin);
}

static void run_asinh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, asinh);
}

static void run_atan(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, atan);
}

static void run_atan2(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, atan2);
}

static void run_atanh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, atanh);
}

static void run_cbrt(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, cbrt);
}

static void run_ceil(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, ceil);
}

static void run_copysign(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, copysign);
}

static void run_cos(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, cos);
}

static void run_cosh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, cosh);
}

static void run_erf(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, erf);
}

static void run_erfc(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, erfc);
}

static void run_exp(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, exp);
}

static void run_expm1(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, expm1);
}

static void run_fabs(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, fabs);
}

static void run_floor(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, floor);
}

static void run_fmod(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, fmod);
}

static void run_frexp(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    frexp(arg1.var_un.var_rdigit, (int *) arg2.var_un.var_array);
}

static void run_gamma(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, gamma);
}

static void run_gamma_r(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;
  extern double gamma_r(double, int *);

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    gamma_r(arg1.var_un.var_rdigit, (int *) arg2.var_un.var_array);
}

static void run_hypot(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, hypot);
}

static void run_ilogb(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg;

  arg = zero_variable;
  resolve_expression(&arg, ep, 1);
  fix_type(&arg, VAR_DOUBLE);
  ret->var_un.var_digit = ilogb(arg.var_un.var_rdigit);
}

static void run_isnan(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg;

  arg = zero_variable;
  resolve_expression(&arg, ep, 1);
  fix_type(&arg, VAR_DOUBLE);
  ret->var_un.var_digit = isnan(arg.var_un.var_rdigit);
}

static void run_j0(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, j0);
}

static void run_j1(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, j1);
}

static void run_jn(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg2, VAR_DOUBLE);
  ret->var_un.var_rdigit = jn(arg1.var_un.var_digit, arg2.var_un.var_rdigit);
}

static void run_ldexp(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    ldexp(arg1.var_un.var_rdigit, arg2.var_un.var_digit);
}

static void run_lgamma(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, lgamma);
}

static void run_lgamma_r(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;
  extern double lgamma_r(double, int *);

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    lgamma_r(arg1.var_un.var_rdigit, (int *) arg2.var_un.var_array);
}

static void run_log(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, log);
}

static void run_log10(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, log10);
}

static void run_log1p(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, log1p);
}

static void run_logb(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, logb);
}

static void run_matherr(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg;

  arg = zero_variable;
  resolve_expression(&arg, ep, 1);
  ret->var_un.var_digit = matherr((struct exception *) arg.var_un.var_array);
}

static void run_modf(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    modf(arg1.var_un.var_rdigit, (double *) arg2.var_un.var_array);
}

static void run_nextafter(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, nextafter);
}

static void run_pow(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, pow);
}

static void run_remainder(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, remainder);
}

static void run_rint(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, rint);
}

static void run_scalb(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_2dbl(cp->c_args, scalb);
}

static void run_scalbn(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg1, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    scalbn(arg1.var_un.var_rdigit, arg2.var_un.var_digit);
}

static void run_significand(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, significand);
}

static void run_sin(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, sin);
}

static void run_sinh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, sinh);
}

static void run_sqrt(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, sqrt);
}

static void run_tan(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, tan);
}

static void run_tanh(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, tanh);
}

static void run_y0(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, y0);
}

static void run_y1(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;

  ret->var_un.var_rdigit = run_dbl(cp->c_args, y1);
}

static void run_yn(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg1;
  T_VARIABLE arg2;

  arg1 = zero_variable;
  arg2 = zero_variable;
  resolve_expression(&arg1, ep, 1);
  resolve_expression(&arg2, ep->e_next, 1);
  fix_type(&arg2, VAR_DOUBLE);
  ret->var_un.var_rdigit =
    yn(arg1.var_un.var_digit, arg2.var_un.var_rdigit);
}

typedef struct {
  ulong_t  d_ino;
  long     d_off;
  ushort_t d_reclen;
  char     d_name[MAXNAMELEN];
} internal_dirent_t;

static void run_readdir(T_STATEMENT *sp)
{
  T_FCALL *cp = sp->s_un.s_call;
  T_VARIABLE *ret = cp->c_block->b_return;
  T_EXPR *ep = cp->c_args;
  T_VARIABLE arg;
  DIR *dirp;
  dirent_t *dp;
  static internal_dirent_t dirent;

  arg = zero_variable;
  resolve_expression(&arg, ep, 1);
  if (arg.var_un.var_user == 0) {
    ret->var_un.var_user = 0;
    return;
  }
  dirp = (DIR *) arg.var_un.var_user;
  dp = readdir(dirp);
  if (dp == 0) {
    ret->var_un.var_user = 0;
    return;
  }
  dirent.d_ino = dp->d_ino;
  dirent.d_off = dp->d_off;
  dirent.d_reclen = dp->d_reclen;
  strlcpy(dirent.d_name, dp->d_name, sizeof dirent.d_name);
  ret->var_un.var_array = (void *) &dirent;
}
