
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.4.1"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Push parsers.  */
#define YYPUSH 0

/* Pull parsers.  */
#define YYPULL 1

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Copy the first part of user declarations.  */


#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <dlfcn.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <setjmp.h>
#include <alloca.h>
#include <sys/systeminfo.h>
#include "avl.h"
#include "se.h"

/*
 * Notes on bizarre issues with parsing:
 *
 * When structs are declared, the members of the struct are parsed and the
 * struct definition is complete before any code can be parsed.  Then,
 * variables of this struct type are parsed and new instances of the struct
 * are created.  Then when the code is parsed and references to the struct
 * members are made, the links to the variables referenced point to the
 * instances of the struct variable, not the "variables" in the struct
 * declaration itself.
 * 
 * However, in the case of classes, the class definition has not been
 * completely parsed before the class code is encountered.  As the parser
 * builds the parse tree for the class code, references made to members
 * of the class itself are referenced back to the actual *declaration* of the
 * class member instead of an instance.  This is why there was a limitation
 * on the class type that only one active user defined class variable could
 * be allowed per program.  Because the parse tree for the class code pointed
 * at the "variables" inside of the declaration of the class instead of an
 * instance of the class.
 */

typedef struct _name T_NAME;

struct _name {
  char   *n_name;
  T_NAME *n_next;
};

extern int yylex(void);

/* for se_put_* */
#define NO_DUPS     0
#define ALLOW_DUPS  1

#define MAX_CHAR  ((unsigned char)  -1)
#define MAX_SHORT ((unsigned short) -1)

#define GET_BLOCK(n)    ((T_BLOCK *)  get_symbol(SYM_BLOCK, (n)))
#define GET_VARIABLE(n) ((T_STRUCT *) get_symbol(SYM_VARIABLE, (n)))
#define GET_STRUCT(n)   ((T_STRUCT *) get_symbol(SYM_STRUCT, (n)))

#define PUT_BLOCK(n, b, a)    put_symbol(SYM_BLOCK,    n, b, a)
#define PUT_VARIABLE(n, v, a) put_symbol(SYM_VARIABLE, n, v, a)
#define PUT_STRUCT(n, s, a)   put_symbol(SYM_STRUCT,   n, s, a)

/* for integral_constant_expression second parameter */
#define INT_TYPES    VAR_INTEGRAL
#define AGG_TYPES   (VAR_NUMERIC|VAR_STRING)

typedef struct _bmap T_BMAP;

struct _bmap {
  char      *bm_name;
  T_STYPE    bm_stype;
  int        bm_param_count;
  T_VARTYPE  bm_return_type;
  char      *bm_user_type;
  void     (*bm_check)(char *, T_EXPR *);
};

/*
 * local function forward declarations
 */


static T_STATEMENT *reverse_statement_list(T_STATEMENT *);
static T_EXPR      *reverse_arg_list      (T_EXPR *);
static T_VARIABLE  *reverse_member_list   (T_VARIABLE *);
static T_CASE      *reverse_case_list     (T_CASE *);

static void        *get_symbol      (T_SYMTYPE, char *);
static void         put_symbol      (T_SYMTYPE, char *, void *, int);
static void         add_special_name(char *);
static void         free_user_type  (T_STRUCT *);
static T_NAME      *get_special_name(char *);
static T_BMAP      *get_builtin     (char *);
static T_VARIABLE  *get_variable    (char *);

static int          check_symbol      (anode *);
static void         symbol_check      (void);
static T_VARTYPE    type_value        (T_EXPR *);
static int          integral_constant_expression(T_EXPR *, int);
static void         expr_clash_check  (T_EXPR *, T_EXPR *, char *);
static void         l_expr_clash_check(T_EXPR *, T_EXPR *, char *);
static T_VARIABLE  *do_dot_check      (char *, char *m, T_VARIABLE *, int *);
static T_VARIABLE  *do_array_check    (char *, T_EXPR *, T_VARIABLE *);
static void         do_digit_checks   (T_VARIABLE *, T_EXPR *);
static void         do_assign_check   (T_VARIABLE *, T_EXPR *, char *, int);
static void         do_switch_check   (T_SWITCH *);
static void         do_for_check      (T_FOR *);
static void         do_while_check    (T_WHILE *);
static void         do_special_check  (char *, T_VARIABLE *);
static void         do_structure_check(T_STRUCT *);
static void         do_param_check    (T_FCALL *);
static void         do_main_check     (T_BLOCK *);
static void         do_return_check   (T_VARIABLE *, T_RETURN *);
static void         do_builtin_check  (T_BMAP *, T_VARIABLE *,
                                       T_FCALL *, T_EXPR *, int);
static void         do_compound_check (T_VARIABLE *, T_EXPR *, char *);
static void         do_lazy_value     (T_EXPR *, T_VARIABLE *);
static T_STATEMENT *do_lazy_lvalue    (T_STATEMENT *);
static void         do_attach_check   (char *, T_BLOCK *);
static void         do_aggregate_check(T_VARIABLE *, T_VARIABLE *);
static void         do_member_check   (T_VARIABLE *, T_VARIABLE *);
static void         do_do_check       (T_DO *);

/* builtins */
static void         do_string_check  (char *, T_EXPR *);
static void         do_long_check    (char *, T_EXPR *);
static void         do_dbl_check     (char *, T_EXPR *);
static void         do_2dbl_check    (char *, T_EXPR *);
static void         do_dbl_long_check(char *, T_EXPR *);
static void         do_long_dbl_check(char *, T_EXPR *);
static void         do_refresh_check (char *, T_EXPR *);
static void         do_printf_check  (char *, T_EXPR *);
static void         do_qsort_check   (char *, T_EXPR *);
static void         do_bsearch_check (char *, T_EXPR *);
static void         do_signal_check  (char *, T_EXPR *);
static void         do_spawn_check   (char *, T_EXPR *);
static void         do_fprintf_check (char *, T_EXPR *);
static void         do_syslog_check  (char *, T_EXPR *);
static void         do_sizeof_check  (char *, T_EXPR *);
static void         do_kvm_cvt_check (char *, T_EXPR *);
static void         do_kvm_addr_check(char *, T_EXPR *);
static void         do_str_fill_check(char *, T_EXPR *);

/* news */
static T_VARIABLE  *new_variable    (T_VARIABLE *);
static T_STRUCT    *new_user_type   (T_VARIABLE *);
static void        *new_array_type  (T_VARIABLE *);

/* misc. */
static void         member_inherit  (T_VARIABLE *, T_VFTYPE);
static void         case_error      (T_CASE *, char *);
static void         push            (void *, T_STACK *);
static void        *pop             (T_STACK *);
static int          is_lazy         (T_VARIABLE *);
static void         fix_offsets     (T_STRUCT *, int, int);
static void         free_aggregate  (T_VARIABLE *);


/*
 * local variable declarations
 */

static char        error_buf[BUFSIZ];
static char        type_name[128];
static char        block_type[128];
static char       *current_scope_name;
static char       *current_class_name;
static char        in_local_scope;
static char        in_class_scope;
static char        block_already_called;
static T_VARIABLE *current_scope;
static T_VARIABLE *class_scope;
static T_VARIABLE *last_variable;
static T_VARIABLE *last_parameter;
static T_VARIABLE *last_dot_component;
static T_STACK     component_stack;
static T_FCALL     *call_list;
static T_RETURN   *return_list;
static T_BREAK    *break_list;
static T_STACK     break_stack;
static T_NAME     *name_list;
static T_CONTINUE *continue_list;
static T_STACK     continue_stack;
static T_VARIABLE  zero_variable;
static T_EXPR      zero_expr;

static T_BMAP builtins[] = {
 { "acos",        S_ACOS,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "acosh",       S_ACOSH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "asin",        S_ASIN,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "asinh",       S_ASINH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atan",        S_ATAN,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atan2",       S_ATAN2,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "atanh",       S_ATANH,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "atexit",      S_ATEXIT,      1, VAR_LONG,    0,        do_string_check   },
 { "bsearch",     S_BSEARCH,     5, VAR_REGISTER,0,        do_bsearch_check  },
 { "cbrt",        S_CBRT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "ceil",        S_CEIL,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "copysign",    S_COPYSIGN,    2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "cos",         S_COS,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "cosh",        S_COSH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "debug_off",   S_DEBUG_OFF,   0, 0,           0,        0                 },
 { "debug_on",    S_DEBUG_ON,    0, 0,           0,        0                 },
 { "erf",         S_ERF,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "erfc",        S_ERFC,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "exp",         S_EXP,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "expm1",       S_EXPM1,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fabs",        S_FABS,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fileno",      S_FILENO,      1, VAR_LONG,    0,        do_long_check     },
 { "first_proc",  S_FIRST_PROC,  0, VAR_USER,   "psinfo_t",0                 },
 { "floor",       S_FLOOR,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "fmod",        S_FMOD,        2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "fprintf",     S_FPRINTF,    -1, VAR_LONG,    0,        do_fprintf_check  },
 { "frexp",       S_FREXP,       2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "gamma",       S_GAMMA,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "gamma_r",     S_GAMMA_R,     2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "get_proc",    S_GET_PROC,    1, VAR_USER,   "psinfo_t",do_long_check     },
 { "hypot",       S_HYPOT,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "ilogb",       S_ILOGB,       1, VAR_LONG,    0,        do_dbl_check      },
 { "isnan",       S_ISNAN,       1, VAR_LONG,    0,        do_dbl_check      },
 { "itoa",        S_ITOA,        1, VAR_STRING,  0,        do_long_check     },
 { "j0",          S_J0,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "j1",          S_J1,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "jn",          S_JN,          2, VAR_DOUBLE,  0,        do_long_dbl_check },
 { "kvm_address", S_KVM_ADDR,    1, VAR_REGISTER,0,        do_kvm_addr_check },
 { "kvm_cvt",     S_KVM_CVT,     2, 0,           0,        do_kvm_cvt_check  },
 { "kvm_declare", S_KVM_DECLARE, 1, VAR_REGISTER,0,        do_string_check   },
 { "ldexp",       S_LDEXP,       2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "lgamma",      S_LGAMMA,      1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "lgamma_r",    S_LGAMMA_R,    2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "log",         S_LOG,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "log10",       S_LOG10,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "log1p",       S_LOG1P,       1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "logb",        S_LOGB,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "matherr",     S_MATHERR,     1, VAR_LONG,    0,        do_long_check     },
 { "modf",        S_MODF,        2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "next_proc",   S_NEXT_PROC,   0, VAR_USER,   "psinfo_t",0                 },
 { "nextafter",   S_NEXTAFTER,   2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "pow",         S_POW,         2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "printf",      S_PRINTF,     -1, VAR_LONG,    0,        do_printf_check   },
 { "qsort",       S_QSORT,       4, 0,           0,        do_qsort_check    },
 { "readdir",     S_READDIR,     1, VAR_REGISTER,0,        do_long_check     },
 { "refresh$",    S_REFRESH,     1, 0,           0,        do_refresh_check  },
 { "remainder",   S_REMAINDER,   2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "rint",        S_RINT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "scalb",       S_SCALB,       2, VAR_DOUBLE,  0,        do_2dbl_check     },
 { "scalbn",      S_SCALBN,      2, VAR_DOUBLE,  0,        do_dbl_long_check },
 { "signal",      S_SIGFUNC,     2, VAR_STRING,  0,        do_signal_check   },
 { "significand", S_SIGNIFICAND, 1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sin",         S_SIN,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sinh",        S_SINH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "sizeof",      S_SIZEOF,      1, VAR_LONG,    0,        do_sizeof_check   },
 { "sprintf",     S_SPRINTF,    -1, VAR_STRING,  0,        do_printf_check   },
 { "sqrt",        S_SQRT,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "struct_empty",S_STRUCT_EMPTY,2, 0,           0,        do_str_fill_check },
 { "struct_fill", S_STRUCT_FILL, 2, 0,           0,        do_str_fill_check },
 { "syslog",      S_SYSLOG,     -1, 0,           0,        do_syslog_check   },
 { "tan",         S_TAN,         1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "tanh",        S_TANH,        1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "y0",          S_Y0,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "y1",          S_Y1,          1, VAR_DOUBLE,  0,        do_dbl_check      },
 { "yn",          S_YN,          2, VAR_DOUBLE,  0,        do_long_dbl_check },
};



/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     AMPERSAND = 258,
     AND = 259,
     AND_EQ = 260,
     ASSIGN = 261,
     ASTERISK = 262,
     ATTACH = 263,
     BREAK = 264,
     CASE = 265,
     CHAR_TYPE = 266,
     CLASS = 267,
     COLON = 268,
     COMMA = 269,
     CONTINUE = 270,
     DECREMENT = 271,
     DEFAULT = 272,
     DO = 273,
     DOT = 274,
     DOUBLE_TYPE = 275,
     ELLIPSIS = 276,
     ELSE = 277,
     EQ = 278,
     EXCLAMATION = 279,
     EXTERN = 280,
     FOR = 281,
     GE = 282,
     GT = 283,
     HAT = 284,
     IF = 285,
     INCREMENT = 286,
     INTEGER = 287,
     KSTAT = 288,
     KVM = 289,
     LE = 290,
     LEFT_CURLY = 291,
     LEFT_PAREN = 292,
     LEFT_SQUARE = 293,
     LNEW = 294,
     LONGLONG_TYPE = 295,
     LONG_TYPE = 296,
     LRENEW = 297,
     LT = 298,
     MIB = 299,
     MINUS = 300,
     MINUS_EQ = 301,
     MOD_EQ = 302,
     NDD = 303,
     NE = 304,
     NIL = 305,
     OR = 306,
     OR_EQ = 307,
     PERCENT = 308,
     PIPE = 309,
     PLUS = 310,
     PLUS_EQ = 311,
     PRAGMA = 312,
     QSTRING = 313,
     RE_EQ = 314,
     RE_NEQ = 315,
     REAL = 316,
     LRETURN = 317,
     QUESTION = 318,
     RIGHT_CURLY = 319,
     RIGHT_PAREN = 320,
     RIGHT_SQUARE = 321,
     SEMICOLON = 322,
     SHIFT_LEFT = 323,
     SHIFT_RIGHT = 324,
     SHIFT_LEFT_EQ = 325,
     SHIFT_RIGHT_EQ = 326,
     SHORT_TYPE = 327,
     SLASH = 328,
     SLASH_EQ = 329,
     STRING = 330,
     STRING_TYPE = 331,
     STRUCT = 332,
     SWITCH = 333,
     TILDE = 334,
     TIMES_EQ = 335,
     UCHAR_TYPE = 336,
     ULONGLONG_TYPE = 337,
     ULONG_TYPE = 338,
     USER_TYPE = 339,
     USHORT_TYPE = 340,
     WHILE = 341,
     XOR_EQ = 342,
     AT_SIGN = 343,
     BACKSLASH = 344,
     DOT_DOT = 345,
     EOLN = 346,
     BI_MAX_CPU = 347,
     BI_MAX_DISK = 348,
     BI_MAX_IF = 349,
     BI_MAX_INTS = 350
   };
#endif
/* Tokens.  */
#define AMPERSAND 258
#define AND 259
#define AND_EQ 260
#define ASSIGN 261
#define ASTERISK 262
#define ATTACH 263
#define BREAK 264
#define CASE 265
#define CHAR_TYPE 266
#define CLASS 267
#define COLON 268
#define COMMA 269
#define CONTINUE 270
#define DECREMENT 271
#define DEFAULT 272
#define DO 273
#define DOT 274
#define DOUBLE_TYPE 275
#define ELLIPSIS 276
#define ELSE 277
#define EQ 278
#define EXCLAMATION 279
#define EXTERN 280
#define FOR 281
#define GE 282
#define GT 283
#define HAT 284
#define IF 285
#define INCREMENT 286
#define INTEGER 287
#define KSTAT 288
#define KVM 289
#define LE 290
#define LEFT_CURLY 291
#define LEFT_PAREN 292
#define LEFT_SQUARE 293
#define LNEW 294
#define LONGLONG_TYPE 295
#define LONG_TYPE 296
#define LRENEW 297
#define LT 298
#define MIB 299
#define MINUS 300
#define MINUS_EQ 301
#define MOD_EQ 302
#define NDD 303
#define NE 304
#define NIL 305
#define OR 306
#define OR_EQ 307
#define PERCENT 308
#define PIPE 309
#define PLUS 310
#define PLUS_EQ 311
#define PRAGMA 312
#define QSTRING 313
#define RE_EQ 314
#define RE_NEQ 315
#define REAL 316
#define LRETURN 317
#define QUESTION 318
#define RIGHT_CURLY 319
#define RIGHT_PAREN 320
#define RIGHT_SQUARE 321
#define SEMICOLON 322
#define SHIFT_LEFT 323
#define SHIFT_RIGHT 324
#define SHIFT_LEFT_EQ 325
#define SHIFT_RIGHT_EQ 326
#define SHORT_TYPE 327
#define SLASH 328
#define SLASH_EQ 329
#define STRING 330
#define STRING_TYPE 331
#define STRUCT 332
#define SWITCH 333
#define TILDE 334
#define TIMES_EQ 335
#define UCHAR_TYPE 336
#define ULONGLONG_TYPE 337
#define ULONG_TYPE 338
#define USER_TYPE 339
#define USHORT_TYPE 340
#define WHILE 341
#define XOR_EQ 342
#define AT_SIGN 343
#define BACKSLASH 344
#define DOT_DOT 345
#define EOLN 346
#define BI_MAX_CPU 347
#define BI_MAX_DISK 348
#define BI_MAX_IF 349
#define BI_MAX_INTS 350




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{


  int          integer;
  double       real;
  char        *string;
  T_BLOCK     *block;
  T_STATEMENT *statement;
  T_IF        *if_statement;
  T_FCALL     *call_statement;
  T_WHILE     *while_statement;
  T_ASSIGN    *assign_statement;
  T_EXPR      *expression;
  T_LEXPR     *l_expression;
  T_VARIABLE  *variable;
  T_STRUCT    *structure;
  T_VARTYPE    var_type;
  T_FOR       *for_statement;
  T_DO        *do_statement;
  T_SWITCH    *switch_statement;
  T_CASE      *case_statement;
  T_RETURN    *return_statement;
  T_BREAK     *break_statement;
  T_CONTINUE  *continue_statement;
  T_SFTYPE     struct_flags;



} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif


/* Copy the second part of user declarations.  */



#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int yyi)
#else
static int
YYID (yyi)
    int yyi;
#endif
{
  return yyi;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss_alloc;
  YYSTYPE yyvs_alloc;
};

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack_alloc, Stack)				\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack_alloc, Stack, yysize);			\
	Stack = &yyptr->Stack_alloc;					\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  53
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   1053

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  96
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  89
/* YYNRULES -- Number of rules.  */
#define YYNRULES  211
/* YYNRULES -- Number of states.  */
#define YYNSTATES  402

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   350

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54,
      55,    56,    57,    58,    59,    60,    61,    62,    63,    64,
      65,    66,    67,    68,    69,    70,    71,    72,    73,    74,
      75,    76,    77,    78,    79,    80,    81,    82,    83,    84,
      85,    86,    87,    88,    89,    90,    91,    92,    93,    94,
      95
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint16 yyprhs[] =
{
       0,     0,     3,     5,     8,    10,    12,    14,    16,    18,
      20,    22,    24,    26,    28,    30,    39,    42,    51,    54,
      57,    59,    63,    65,    67,    74,    76,    83,    87,    90,
      92,    99,   103,   105,   106,   109,   111,   116,   120,   123,
     125,   129,   136,   138,   141,   145,   148,   154,   156,   157,
     160,   163,   164,   168,   172,   174,   176,   178,   180,   182,
     184,   186,   188,   190,   192,   194,   196,   198,   200,   205,
     208,   217,   219,   221,   222,   225,   227,   229,   230,   234,
     236,   238,   240,   242,   244,   246,   249,   251,   253,   256,
     258,   260,   262,   264,   266,   268,   270,   272,   274,   276,
     278,   280,   282,   285,   288,   291,   294,   306,   316,   318,
     320,   324,   326,   328,   329,   331,   332,   340,   342,   344,
     347,   349,   354,   358,   360,   361,   363,   365,   368,   371,
     374,   378,   387,   392,   393,   395,   399,   404,   408,   412,
     416,   420,   424,   428,   432,   436,   440,   444,   449,   457,
     459,   461,   465,   470,   472,   474,   476,   478,   480,   484,
     488,   492,   496,   500,   504,   508,   512,   516,   520,   524,
     528,   530,   531,   535,   537,   539,   541,   544,   547,   550,
     553,   555,   557,   559,   561,   563,   565,   569,   577,   581,
     585,   587,   589,   592,   595,   598,   601,   604,   608,   612,
     616,   620,   624,   628,   632,   636,   640,   644,   648,   652,
     659,   668
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int16 yyrhs[] =
{
      97,     0,    -1,    98,    -1,    98,    99,    -1,    99,    -1,
     106,    -1,   100,    -1,   101,    -1,   102,    -1,   108,    -1,
     112,    -1,   118,    -1,   127,    -1,   128,    -1,   129,    -1,
      33,    77,   137,   107,    36,   103,    64,    67,    -1,    33,
     106,    -1,    48,    77,   137,   107,    36,   116,    64,    67,
      -1,    44,   106,    -1,   103,   104,    -1,   104,    -1,   126,
     105,    67,    -1,   136,    -1,   137,    -1,    77,   107,    36,
     116,    64,    67,    -1,   136,    -1,     8,   137,    36,   109,
      64,    67,    -1,     8,   137,    67,    -1,   109,   110,    -1,
     110,    -1,   111,   130,    37,   133,    65,    67,    -1,    25,
     120,    67,    -1,   126,    -1,    -1,   114,   115,    -1,   136,
      -1,    12,   113,    36,   116,    -1,   129,    64,    67,    -1,
     116,   117,    -1,   117,    -1,   126,   136,    67,    -1,   126,
     136,    38,   182,    66,    67,    -1,   119,    -1,    34,   119,
      -1,   120,   122,    67,    -1,   126,   136,    -1,   126,   136,
      38,   121,    66,    -1,   182,    -1,    -1,     6,   182,    -1,
       6,   123,    -1,    -1,    36,   124,    64,    -1,   124,    14,
     125,    -1,   125,    -1,   182,    -1,   123,    -1,    76,    -1,
      11,    -1,    72,    -1,    41,    -1,    40,    -1,    81,    -1,
      85,    -1,    83,    -1,    82,    -1,    20,    -1,    84,    -1,
      57,   136,   136,    67,    -1,   126,   129,    -1,   130,    37,
     133,    65,    36,   131,   138,    64,    -1,   136,    -1,   132,
      -1,    -1,   132,   118,    -1,   118,    -1,   134,    -1,    -1,
     134,    14,   135,    -1,   135,    -1,   120,    -1,    21,    -1,
      75,    -1,    58,    -1,   139,    -1,   139,   140,    -1,   140,
      -1,   141,    -1,   142,    67,    -1,    67,    -1,   163,    -1,
     168,    -1,   145,    -1,   146,    -1,   152,    -1,   162,    -1,
     160,    -1,   161,    -1,   167,    -1,   174,    -1,   143,    -1,
     144,    -1,   173,    31,    -1,    31,   173,    -1,   173,    16,
      -1,    16,   173,    -1,   147,    37,   150,    67,   151,    67,
     150,    65,    36,   138,    64,    -1,   148,    36,   138,    64,
      86,    37,   165,    65,    67,    -1,    26,    -1,    18,    -1,
     149,    14,   142,    -1,   142,    -1,   149,    -1,    -1,   165,
      -1,    -1,   153,    37,   182,    65,    36,   154,    64,    -1,
      78,    -1,   155,    -1,   155,   156,    -1,   156,    -1,   158,
     181,    13,   157,    -1,   159,    13,   157,    -1,   138,    -1,
      -1,    10,    -1,    17,    -1,     9,    67,    -1,    15,    67,
      -1,    62,    67,    -1,    62,   182,    67,    -1,    30,    37,
     165,    65,    36,   138,    64,   164,    -1,    22,    36,   138,
      64,    -1,    -1,   166,    -1,    37,   166,    65,    -1,    24,
      37,   166,    65,    -1,   182,    43,   182,    -1,   182,    28,
     182,    -1,   182,    35,   182,    -1,   182,    27,   182,    -1,
     182,    23,   182,    -1,   182,    59,   182,    -1,   182,    60,
     182,    -1,   182,    49,   182,    -1,   165,     4,   165,    -1,
     165,    51,   165,    -1,   136,    37,   177,    65,    -1,   169,
      37,   165,    65,    36,   138,    64,    -1,    86,    -1,   136,
      -1,   170,    19,   170,    -1,   136,   171,   182,   172,    -1,
      38,    -1,    66,    -1,   170,    -1,   175,    -1,   176,    -1,
     173,     6,   182,    -1,   173,     6,   123,    -1,   173,    56,
     182,    -1,   173,    46,   182,    -1,   173,    80,   182,    -1,
     173,    74,   182,    -1,   173,    47,   182,    -1,   173,     5,
     182,    -1,   173,    52,   182,    -1,   173,    87,   182,    -1,
     173,    70,   182,    -1,   173,    71,   182,    -1,   178,    -1,
      -1,   178,    14,   182,    -1,   182,    -1,    32,    -1,    61,
      -1,    55,    32,    -1,    55,    61,    -1,    45,    32,    -1,
      45,    61,    -1,   181,    -1,   173,    -1,   179,    -1,   137,
      -1,    50,    -1,   184,    -1,    37,   184,    65,    -1,    37,
     165,    63,   182,    13,   182,    65,    -1,    37,   174,    65,
      -1,    38,   182,    66,    -1,   180,    -1,   167,    -1,   173,
      31,    -1,    31,   173,    -1,   173,    16,    -1,    16,   173,
      -1,     3,   173,    -1,    39,   126,   183,    -1,    42,   136,
     183,    -1,   182,    55,   182,    -1,   182,    45,   182,    -1,
     182,     7,   182,    -1,   182,    73,   182,    -1,   182,    53,
     182,    -1,   182,     3,   182,    -1,   182,    54,   182,    -1,
     182,    29,   182,    -1,   182,    68,   182,    -1,   182,    69,
     182,    -1,    37,    37,   126,    65,   182,    65,    -1,     7,
      37,    37,   126,     7,    65,   182,    65,    -1,    79,   182,
      -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   371,   371,   392,   393,   396,   397,   398,   399,   400,
     401,   402,   403,   404,   405,   419,   446,   453,   470,   477,
     483,   493,   529,   533,   539,   555,   566,   596,   603,   608,
     614,   670,   679,   684,   689,   714,   720,   746,   757,   763,
     775,   808,   866,   870,   877,   926,   965,  1032,  1037,  1042,
    1046,  1053,  1058,  1068,  1073,  1079,  1089,  1095,  1099,  1103,
    1107,  1111,  1115,  1119,  1123,  1127,  1131,  1135,  1147,  1170,
    1193,  1239,  1259,  1264,  1270,  1276,  1285,  1297,  1302,  1309,
    1317,  1321,  1329,  1335,  1341,  1347,  1353,  1359,  1363,  1367,
    1375,  1382,  1389,  1396,  1403,  1410,  1417,  1424,  1434,  1441,
    1452,  1461,  1473,  1483,  1495,  1505,  1517,  1533,  1545,  1552,
    1559,  1564,  1570,  1575,  1580,  1585,  1591,  1602,  1608,  1614,
    1619,  1625,  1631,  1638,  1643,  1648,  1655,  1662,  1675,  1688,
    1695,  1705,  1716,  1721,  1726,  1730,  1736,  1744,  1752,  1760,
    1768,  1776,  1784,  1792,  1800,  1808,  1815,  1824,  1870,  1882,
    1889,  1914,  1918,  1959,  1966,  1972,  2005,  2009,  2015,  2029,
    2051,  2059,  2067,  2075,  2083,  2091,  2099,  2107,  2115,  2123,
    2133,  2138,  2143,  2148,  2154,  2158,  2162,  2166,  2170,  2175,
    2182,  2186,  2192,  2201,  2207,  2215,  2219,  2226,  2236,  2244,
    2250,  2261,  2267,  2273,  2279,  2285,  2291,  2324,  2370,  2434,
    2443,  2452,  2461,  2488,  2497,  2506,  2515,  2524,  2533,  2542,
    2579,  2610
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "AMPERSAND", "AND", "AND_EQ", "ASSIGN",
  "ASTERISK", "ATTACH", "BREAK", "CASE", "CHAR_TYPE", "CLASS", "COLON",
  "COMMA", "CONTINUE", "DECREMENT", "DEFAULT", "DO", "DOT", "DOUBLE_TYPE",
  "ELLIPSIS", "ELSE", "EQ", "EXCLAMATION", "EXTERN", "FOR", "GE", "GT",
  "HAT", "IF", "INCREMENT", "INTEGER", "KSTAT", "KVM", "LE", "LEFT_CURLY",
  "LEFT_PAREN", "LEFT_SQUARE", "LNEW", "LONGLONG_TYPE", "LONG_TYPE",
  "LRENEW", "LT", "MIB", "MINUS", "MINUS_EQ", "MOD_EQ", "NDD", "NE", "NIL",
  "OR", "OR_EQ", "PERCENT", "PIPE", "PLUS", "PLUS_EQ", "PRAGMA", "QSTRING",
  "RE_EQ", "RE_NEQ", "REAL", "LRETURN", "QUESTION", "RIGHT_CURLY",
  "RIGHT_PAREN", "RIGHT_SQUARE", "SEMICOLON", "SHIFT_LEFT", "SHIFT_RIGHT",
  "SHIFT_LEFT_EQ", "SHIFT_RIGHT_EQ", "SHORT_TYPE", "SLASH", "SLASH_EQ",
  "STRING", "STRING_TYPE", "STRUCT", "SWITCH", "TILDE", "TIMES_EQ",
  "UCHAR_TYPE", "ULONGLONG_TYPE", "ULONG_TYPE", "USER_TYPE", "USHORT_TYPE",
  "WHILE", "XOR_EQ", "AT_SIGN", "BACKSLASH", "DOT_DOT", "EOLN",
  "BI_MAX_CPU", "BI_MAX_DISK", "BI_MAX_IF", "BI_MAX_INTS", "$accept",
  "program", "list_of_decs", "dec", "kstat_struct", "ndd_struct",
  "mib_struct", "list_of_kmembers", "kmember", "kname", "struct",
  "struct_id", "attach", "list_of_attachments", "attachment",
  "type_specifier", "class", "class_tag", "struct_part", "class_part",
  "list_of_members", "member", "declared_variable", "initialized_variable",
  "variable", "array_size", "initializer", "aggregate", "list_of_inits",
  "init", "type_name", "pragma", "block", "typeless_block", "block_id",
  "local_variables", "list_of_variables", "list_of_parameters",
  "parameter_list", "param", "string", "qstring", "list_of_statements",
  "statement_list", "statement", "control_statement", "sequence_statement",
  "increment_statement", "decrement_statement", "for_statement",
  "do_statement", "for_id", "do_id", "for_list", "before_part",
  "while_part", "switch_statement", "switch_id", "list_of_cases",
  "case_list", "case_part", "case_statement_list", "case_id", "default_id",
  "break_statement", "continue_statement", "return_statement",
  "if_statement", "else_part", "l_expression", "plain_l_expression",
  "call_statement", "while_statement", "while_id", "l_value",
  "left_square", "right_square", "lvalue", "assign_statement",
  "plain_assignment", "compound_assignment", "list_of_args", "arg_list",
  "digit", "value", "constant_value", "expression", "size_spec",
  "plain_expression", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,   310,   311,   312,   313,   314,
     315,   316,   317,   318,   319,   320,   321,   322,   323,   324,
     325,   326,   327,   328,   329,   330,   331,   332,   333,   334,
     335,   336,   337,   338,   339,   340,   341,   342,   343,   344,
     345,   346,   347,   348,   349,   350
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    96,    97,    98,    98,    99,    99,    99,    99,    99,
      99,    99,    99,    99,    99,   100,   100,   101,   102,   103,
     103,   104,   105,   105,   106,   107,   108,   108,   109,   109,
     110,   110,   111,   111,   112,   113,   114,   115,   116,   116,
     117,   117,   118,   118,   119,   120,   120,   121,   121,   122,
     122,   122,   123,   124,   124,   125,   125,   126,   126,   126,
     126,   126,   126,   126,   126,   126,   126,   126,   127,   128,
     129,   130,   131,   131,   132,   132,   133,   133,   134,   134,
     135,   135,   136,   137,   138,   139,   139,   140,   140,   140,
     141,   141,   141,   141,   141,   141,   141,   141,   142,   142,
     142,   142,   143,   143,   144,   144,   145,   146,   147,   148,
     149,   149,   150,   150,   151,   151,   152,   153,   154,   155,
     155,   156,   156,   157,   157,   158,   159,   160,   161,   162,
     162,   163,   164,   164,   165,   165,   165,   166,   166,   166,
     166,   166,   166,   166,   166,   166,   166,   167,   168,   169,
     170,   170,   170,   171,   172,   173,   174,   174,   175,   175,
     176,   176,   176,   176,   176,   176,   176,   176,   176,   176,
     177,   177,   178,   178,   179,   179,   179,   179,   179,   179,
     180,   180,   181,   181,   181,   182,   182,   182,   182,   183,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184,   184,   184,   184,   184,   184,   184,   184,   184,
     184,   184
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,     2,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     8,     2,     8,     2,     2,
       1,     3,     1,     1,     6,     1,     6,     3,     2,     1,
       6,     3,     1,     0,     2,     1,     4,     3,     2,     1,
       3,     6,     1,     2,     3,     2,     5,     1,     0,     2,
       2,     0,     3,     3,     1,     1,     1,     1,     1,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     4,     2,
       8,     1,     1,     0,     2,     1,     1,     0,     3,     1,
       1,     1,     1,     1,     1,     2,     1,     1,     2,     1,
       1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
       1,     1,     2,     2,     2,     2,    11,     9,     1,     1,
       3,     1,     1,     0,     1,     0,     7,     1,     1,     2,
       1,     4,     3,     1,     0,     1,     1,     2,     2,     2,
       3,     8,     4,     0,     1,     3,     4,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     4,     7,     1,
       1,     3,     4,     1,     1,     1,     1,     1,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     3,
       1,     0,     3,     1,     1,     1,     2,     2,     2,     2,
       1,     1,     1,     1,     1,     1,     3,     7,     3,     3,
       1,     1,     2,     2,     2,     2,     2,     3,     3,     3,
       3,     3,     3,     3,     3,     3,     3,     3,     3,     6,
       8,     2
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     0,    58,     0,    66,     0,     0,    61,    60,     0,
       0,     0,    59,    82,    57,     0,    62,    65,    64,    67,
      63,     0,     2,     4,     6,     7,     8,     5,     9,    10,
       0,    11,    42,    51,     0,    12,    13,    14,     0,    71,
      83,     0,     0,    35,     0,    16,    43,     0,    18,     0,
       0,     0,    25,     1,     3,    34,     0,     0,     0,    69,
      45,    77,    33,    27,     0,     0,    45,     0,     0,     0,
       0,     0,     0,     0,     0,   174,     0,     0,     0,     0,
       0,   184,     0,   175,     0,    50,   150,   183,   191,   155,
     181,   182,   190,   180,    49,   185,    44,    48,    81,    80,
       0,    76,    79,     0,    33,    29,     0,    32,    36,    39,
       0,     0,     0,    68,     0,    37,   150,   196,     0,   195,
     193,    56,     0,    54,    55,     0,     0,     0,   134,   181,
       0,   156,   157,     0,   185,     0,     0,   178,   179,   176,
     177,   211,   171,   153,     0,     0,   194,   192,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,    47,
       0,     0,     0,     0,    28,     0,    38,     0,     0,     0,
       0,     0,     0,    52,     0,     0,   134,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
       0,   188,     0,     0,     0,     0,     0,     0,     0,     0,
     186,     0,   197,   198,     0,   170,   173,     0,   151,   204,
     201,   206,   200,   203,   205,   199,   207,   208,   202,    46,
      73,    78,    31,    26,    77,     0,    40,     0,    20,     0,
       0,    24,     0,    53,     0,     0,   134,     0,   135,   145,
     146,     0,   165,   159,   158,   161,   164,   166,   160,   168,
     169,   163,   162,   167,   141,   140,   138,   139,   137,   144,
     142,   143,     0,   147,     0,   154,   152,    75,     0,    72,
       0,     0,     0,    19,     0,    22,    23,     0,     0,   136,
       0,     0,   189,   172,     0,     0,     0,   109,   108,     0,
       0,     0,    89,   117,   149,     0,    84,    86,    87,     0,
     100,   101,    92,    93,     0,     0,    94,     0,    96,    97,
      95,    90,    98,    91,     0,     0,    99,    74,     0,     0,
      15,    21,    17,     0,   209,     0,   127,   128,   105,     0,
     103,   129,     0,    70,    85,    88,   113,     0,     0,     0,
     104,   102,    30,    41,     0,   187,     0,   130,   111,   112,
       0,     0,     0,     0,   210,     0,     0,   115,     0,     0,
       0,     0,   110,     0,   114,     0,     0,     0,     0,   113,
       0,   125,   126,     0,   118,   120,     0,     0,     0,   133,
       0,     0,   116,   119,     0,   124,   148,     0,   131,     0,
       0,   124,   123,   122,     0,     0,   107,   121,     0,     0,
     132,   106
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int16 yydefgoto[] =
{
      -1,    21,    22,    23,    24,    25,    26,   227,   228,   274,
      27,    51,    28,   104,   105,   106,    29,    42,    30,    55,
     108,   109,    31,    32,    33,   158,    58,   121,   122,   123,
      47,    35,    36,    37,    38,   268,   269,   100,   101,   102,
      86,    87,   392,   296,   297,   298,   299,   300,   301,   302,
     303,   304,   305,   349,   350,   363,   306,   307,   373,   374,
     375,   393,   376,   377,   308,   309,   310,   311,   388,   127,
     128,    88,   313,   314,    89,   144,   266,    90,   316,   131,
     132,   204,   205,    91,    92,    93,   133,   202,    95
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -251
static const yytype_int16 yypact[] =
{
     404,   -25,  -251,   -51,  -251,   -41,   713,  -251,  -251,   -28,
       5,   -51,  -251,  -251,  -251,   -51,  -251,  -251,  -251,  -251,
    -251,    93,   404,  -251,  -251,  -251,  -251,  -251,  -251,  -251,
     -51,  -251,  -251,    90,   -51,  -251,  -251,  -251,    68,  -251,
    -251,   -14,    74,  -251,   -32,  -251,  -251,   -51,  -251,   -25,
     -51,    82,  -251,  -251,  -251,  -251,    62,   461,    61,  -251,
      85,   325,   612,  -251,   713,   -51,   107,   -51,    84,   713,
      86,   -51,   115,   -51,   -51,  -251,   461,   502,   713,   -51,
      -3,  -251,    55,  -251,   596,  -251,    87,  -251,  -251,   136,
      78,  -251,  -251,  -251,   980,  -251,  -251,   596,  -251,  -251,
      91,   143,  -251,   713,   584,  -251,   -51,  -251,   713,  -251,
     -51,   124,   125,  -251,    19,  -251,   127,  -251,   141,  -251,
    -251,  -251,     0,  -251,   980,   150,   302,    34,  -251,   324,
     126,  -251,  -251,   776,   128,   151,   151,  -251,  -251,  -251,
    -251,  -251,   596,  -251,   596,   -51,  -251,  -251,   596,   596,
     596,   596,   596,   596,   596,   596,   596,   596,   129,   980,
     164,   325,   137,   138,  -251,   166,  -251,    32,   713,   713,
     139,   713,   461,  -251,   514,   142,   146,   514,   514,   596,
     596,   461,   596,   596,   596,   596,   596,   596,   596,   596,
     596,  -251,   596,   596,   596,   596,   596,   596,   596,   596,
    -251,   596,  -251,  -251,   149,   202,   980,   773,  -251,    81,
      44,    81,   206,    44,    81,   206,  -251,  -251,    44,  -251,
     638,  -251,  -251,  -251,   325,   596,  -251,   662,  -251,   -32,
     687,  -251,   201,  -251,   502,    38,   152,   596,  -251,  -251,
    -251,   779,   980,  -251,   980,   980,   980,   980,   980,   980,
     980,   980,   980,   980,   980,   980,   980,   980,   980,   980,
     980,   980,   809,  -251,   596,  -251,  -251,  -251,   416,   638,
     156,   850,   155,  -251,   160,  -251,  -251,   161,   167,  -251,
     867,   596,  -251,   980,   171,   174,   -51,  -251,  -251,   197,
     -51,   555,  -251,  -251,  -251,   178,   416,  -251,  -251,   176,
    -251,  -251,  -251,  -251,   208,   212,  -251,   213,  -251,  -251,
    -251,  -251,  -251,  -251,   217,   383,  -251,  -251,   195,   196,
    -251,  -251,  -251,   596,  -251,   884,  -251,  -251,  -251,   514,
    -251,  -251,   921,  -251,  -251,  -251,     3,   416,   596,   514,
    -251,  -251,  -251,  -251,   927,  -251,    11,  -251,  -251,   247,
     200,   205,   948,    14,  -251,   228,     3,   514,   184,   235,
     236,   416,  -251,   209,    38,   240,    15,   416,   216,     3,
     514,  -251,  -251,   218,    15,  -251,   194,   260,   219,   259,
     221,    16,  -251,  -251,   271,   416,  -251,   252,  -251,   253,
     225,   416,  -251,  -251,   416,   416,  -251,  -251,   229,   230,
    -251,  -251
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -251,  -251,  -251,   273,  -251,  -251,  -251,  -251,    70,  -251,
      41,    50,  -251,  -251,   198,  -251,  -251,  -251,  -251,  -251,
     -61,   -97,  -192,   293,   -34,  -251,  -251,   -47,  -251,   134,
     132,  -251,  -251,    58,   210,  -251,  -251,    80,  -251,   147,
       1,     8,  -247,  -251,    21,  -251,  -250,  -251,  -251,  -251,
    -251,  -251,  -251,  -251,   -62,  -251,  -251,  -251,  -251,  -251,
     -63,   -79,  -251,  -251,  -251,  -251,  -251,  -251,  -251,  -137,
    -113,  -138,  -251,  -251,   170,  -251,  -251,   -71,   -72,  -251,
    -251,  -251,  -251,  -251,  -251,   -57,   -13,   185,   -70
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -72
static const yytype_int16 yytable[] =
{
     117,    39,   119,   120,    43,   130,   129,   134,   114,    41,
      85,   166,    50,   176,   172,   177,    52,   166,   177,   286,
     177,   295,    62,    39,    13,   371,    40,    99,   267,   137,
       2,    39,   372,    40,   290,    60,    44,   235,   177,     4,
     239,   240,   177,    13,    94,    52,    45,   148,    66,    15,
      48,    68,    65,    63,   130,   129,   134,    67,   138,     7,
       8,   236,   178,   124,   173,   178,    52,   178,    52,   162,
     225,   141,   116,   150,   116,   116,   355,   317,    13,   360,
     136,   390,    49,   170,   159,   178,   348,   139,    56,   178,
     351,    12,    59,    53,   146,    14,    57,   179,   153,   226,
      16,    17,    18,    19,    20,    61,   362,    39,   230,   147,
      64,   167,   155,   156,   368,   111,   140,   112,    69,   348,
     378,   176,   -71,    97,   142,   143,    70,    99,    96,   206,
     312,   207,    34,   166,   243,   209,   210,   211,   212,   213,
     214,   215,   216,   217,   218,    97,   116,   398,   399,   155,
     156,   113,   118,   115,    34,   145,   160,   161,   312,   124,
     168,   169,   130,   129,   134,   143,   241,   242,   244,   245,
     246,   247,   248,   249,   250,   251,   252,   253,   171,   254,
     255,   256,   257,   258,   259,   260,   261,   174,   262,   201,
      99,   191,   346,   200,   107,   219,   110,   315,   312,   312,
     220,   110,   353,   224,   222,   223,   231,   237,   278,   148,
     135,   238,   271,   149,   263,   328,   264,   279,   312,   330,
     364,   318,   320,   312,   280,   315,    75,   321,   322,   312,
     275,   312,   323,   381,   329,   150,   107,   276,   326,    80,
     110,   327,   333,   335,    81,   336,   110,   312,   337,    82,
     338,   283,    40,   312,   339,    83,   312,   312,   175,   152,
     153,   356,   342,   343,   361,   315,   315,   357,   325,   358,
     365,   366,   367,   385,   155,   156,   369,   370,   332,   157,
     379,   387,   382,   386,   391,   315,   389,   116,   394,   395,
     315,   116,   396,   400,   401,    54,   315,   273,   315,    46,
     229,   110,   164,   232,   270,    71,   233,   380,   221,    72,
     344,   383,   397,     2,   315,   208,   165,   334,    73,   384,
     315,   203,     4,   315,   315,   352,   125,     0,     0,   180,
     181,     0,     0,    74,    75,     0,     2,     0,     0,   126,
     146,    78,     7,     8,    79,     4,    98,    80,     0,     0,
       0,     0,    81,     0,     0,   147,     0,    82,     0,   229,
      40,     0,   110,    83,     0,     7,     8,     0,     0,     0,
     182,   183,     0,     0,    12,     0,   184,    13,    14,     0,
     185,    84,     0,    16,    17,    18,    19,    20,   180,   181,
       0,     0,     0,     0,   186,   187,     0,    12,   188,   340,
       0,    14,     0,     0,   189,     0,    16,    17,    18,    19,
      20,   190,     1,     0,   341,     2,     3,     0,     0,     0,
       0,     0,     0,     0,     4,   284,     0,     0,     0,   182,
     183,   285,   286,     0,   287,   184,     0,     5,     6,   185,
       0,     0,   288,     0,     7,     8,   289,   290,     9,     0,
       0,     0,    10,   186,   187,     0,     0,   188,     0,     0,
       0,    11,     0,   189,    71,     0,     0,     0,    72,     0,
     190,     0,     0,     0,     0,     0,    12,    73,   291,    13,
      14,    15,     0,   292,     0,    16,    17,    18,    19,    20,
       0,    13,    74,    75,   293,     0,     0,    76,    77,     0,
      78,     0,   294,    79,     0,    71,    80,     0,     0,    72,
       0,    81,     0,     0,     0,     0,    82,    71,    73,    40,
       0,    72,    83,     0,     0,     0,   125,     0,     0,     0,
      73,     0,     0,    74,    75,     0,    13,     0,   125,   126,
      84,    78,     0,     0,    79,    74,    75,    80,     0,     0,
       0,   234,    81,    78,     0,     0,    79,    82,    71,    80,
      40,     0,    72,    83,    81,     0,     0,     0,     0,    82,
       0,    73,    40,     0,     0,    83,     0,    13,     0,     0,
       0,    84,     0,     0,     0,     0,    74,    75,     0,    13,
       0,     0,    77,    84,    78,     2,     0,    79,     0,    71,
      80,     0,     0,    72,     4,    81,     0,     0,     0,   103,
      82,     0,    73,    40,     0,     0,    83,     0,     0,     0,
       0,     0,   331,     2,     7,     8,     0,    74,    75,     0,
      13,     0,     4,    77,    84,    78,     0,   103,    79,     0,
       0,    80,     0,     0,     0,     0,    81,     0,   163,     2,
       0,    82,     7,     8,    40,     0,    12,    83,     4,     0,
      14,     0,     0,     0,     0,    16,    17,    18,    19,    20,
       0,    13,     6,     2,     0,    84,     0,     0,     7,     8,
       0,     0,     4,     0,    12,     0,     0,     0,    14,     0,
       0,     0,     0,    16,    17,    18,    19,    20,     2,     0,
       0,     0,     7,     8,     0,     0,     0,     4,     0,     0,
      12,     0,     0,     0,    14,     0,     0,     0,     0,    16,
      17,    18,    19,    20,     2,     0,   272,     7,     8,     0,
       0,     0,     0,     4,    12,     0,     0,     0,    14,     0,
       0,     0,     0,    16,    17,    18,    19,    20,     0,     0,
       0,   277,     0,     7,     8,     0,     0,     0,     0,    12,
       0,     0,     0,    14,     0,     0,     0,     0,    16,    17,
      18,    19,    20,     0,     0,     0,   148,     0,     0,   148,
     149,     0,   148,   149,     0,    12,   149,     0,     0,    14,
       0,     0,   281,     0,    16,    17,    18,    19,    20,   192,
       0,     0,   150,   193,   194,   150,     0,     0,   150,     0,
       0,   195,   148,     0,     0,     0,   149,     0,   151,   196,
       0,   151,     0,     0,   151,   197,   152,   153,   154,   152,
     153,   154,   152,   153,   154,   198,   199,     0,   150,   265,
       0,   155,   156,     0,   155,   156,   157,   155,   156,   157,
       0,     0,   157,   148,   151,     0,     0,   149,     0,     0,
       0,     0,   152,   153,   154,     0,     0,     0,     0,     0,
     148,     0,     0,     0,   149,   282,     0,   155,   156,   150,
       0,     0,   157,     0,     0,     0,     0,   148,     0,     0,
       0,   149,     0,     0,     0,   151,   150,     0,     0,     0,
       0,     0,     0,   152,   153,   154,     0,     0,     0,     0,
       0,     0,   151,   150,     0,     0,   319,     0,   155,   156,
     152,   153,   154,   157,   148,     0,     0,     0,   149,   151,
     148,     0,   324,     0,   149,   155,   156,   152,   153,   154,
     157,     0,     0,     0,     0,     0,     0,     0,     0,   345,
     150,   148,   155,   156,     0,   149,   150,   157,     0,     0,
       0,     0,     0,     0,     0,     0,   151,     0,     0,     0,
       0,     0,   151,     0,   152,   153,   154,   150,     0,     0,
     152,   153,   154,   148,     0,     0,     0,   149,   347,   155,
     156,     0,   354,   151,   157,   155,   156,     0,     0,     0,
     157,   152,   153,   154,     0,     0,     0,     0,     0,   150,
       0,     0,     0,   359,     0,     0,   155,   156,     0,     0,
       0,   157,     0,     0,     0,   151,     0,     0,     0,     0,
       0,     0,     0,   152,   153,   154,     0,     0,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,   155,   156,
       0,     0,     0,   157
};

static const yytype_int16 yycheck[] =
{
      71,     0,    73,    74,     3,    77,    77,    77,    69,     1,
      57,   108,    11,   126,    14,     4,    15,   114,     4,    16,
       4,   268,    36,    22,    75,    10,    58,    61,   220,    32,
      11,    30,    17,    58,    31,    34,    77,   174,     4,    20,
     177,   178,     4,    75,    57,    44,     5,     3,    47,    77,
       9,    50,    44,    67,   126,   126,   126,    49,    61,    40,
      41,   174,    51,    76,    64,    51,    65,    51,    67,   103,
      38,    84,    71,    29,    73,    74,    65,   269,    75,    65,
      79,    65,    77,    64,    97,    51,   336,    32,    30,    51,
     337,    72,    34,     0,    16,    76,     6,    63,    54,    67,
      81,    82,    83,    84,    85,    37,   356,   106,   169,    31,
      36,   110,    68,    69,   361,    65,    61,    67,    36,   369,
     367,   234,    37,    38,    37,    38,    64,   161,    67,   142,
     268,   144,     0,   230,   181,   148,   149,   150,   151,   152,
     153,   154,   155,   156,   157,    38,   145,   394,   395,    68,
      69,    67,    37,    67,    22,    19,    65,    14,   296,   172,
      36,    36,   234,   234,   234,    38,   179,   180,   181,   182,
     183,   184,   185,   186,   187,   188,   189,   190,    37,   192,
     193,   194,   195,   196,   197,   198,   199,    37,   201,    38,
     224,    65,   329,    65,    62,    66,    64,   268,   336,   337,
      36,    69,   339,    37,    67,    67,    67,    65,     7,     3,
      78,    65,   225,     7,    65,   286,    14,    65,   356,   290,
     357,    65,    67,   361,   237,   296,    32,    67,    67,   367,
     229,   369,    65,   370,    37,    29,   104,   229,    67,    45,
     108,    67,    64,    67,    50,    37,   114,   385,    36,    55,
      37,   264,    58,   391,    37,    61,   394,   395,   126,    53,
      54,    14,    67,    67,    36,   336,   337,    67,   281,    64,
      86,    36,    36,    13,    68,    69,    67,    37,   291,    73,
      64,    22,    64,    64,    13,   356,    65,   286,    36,    36,
     361,   290,    67,    64,    64,    22,   367,   227,   369,     6,
     168,   169,   104,   171,   224,     3,   172,   369,   161,     7,
     323,   374,   391,    11,   385,   145,   106,   296,    16,   376,
     391,   136,    20,   394,   395,   338,    24,    -1,    -1,     5,
       6,    -1,    -1,    31,    32,    -1,    11,    -1,    -1,    37,
      16,    39,    40,    41,    42,    20,    21,    45,    -1,    -1,
      -1,    -1,    50,    -1,    -1,    31,    -1,    55,    -1,   227,
      58,    -1,   230,    61,    -1,    40,    41,    -1,    -1,    -1,
      46,    47,    -1,    -1,    72,    -1,    52,    75,    76,    -1,
      56,    79,    -1,    81,    82,    83,    84,    85,     5,     6,
      -1,    -1,    -1,    -1,    70,    71,    -1,    72,    74,    16,
      -1,    76,    -1,    -1,    80,    -1,    81,    82,    83,    84,
      85,    87,     8,    -1,    31,    11,    12,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    20,     9,    -1,    -1,    -1,    46,
      47,    15,    16,    -1,    18,    52,    -1,    33,    34,    56,
      -1,    -1,    26,    -1,    40,    41,    30,    31,    44,    -1,
      -1,    -1,    48,    70,    71,    -1,    -1,    74,    -1,    -1,
      -1,    57,    -1,    80,     3,    -1,    -1,    -1,     7,    -1,
      87,    -1,    -1,    -1,    -1,    -1,    72,    16,    62,    75,
      76,    77,    -1,    67,    -1,    81,    82,    83,    84,    85,
      -1,    75,    31,    32,    78,    -1,    -1,    36,    37,    -1,
      39,    -1,    86,    42,    -1,     3,    45,    -1,    -1,     7,
      -1,    50,    -1,    -1,    -1,    -1,    55,     3,    16,    58,
      -1,     7,    61,    -1,    -1,    -1,    24,    -1,    -1,    -1,
      16,    -1,    -1,    31,    32,    -1,    75,    -1,    24,    37,
      79,    39,    -1,    -1,    42,    31,    32,    45,    -1,    -1,
      -1,    37,    50,    39,    -1,    -1,    42,    55,     3,    45,
      58,    -1,     7,    61,    50,    -1,    -1,    -1,    -1,    55,
      -1,    16,    58,    -1,    -1,    61,    -1,    75,    -1,    -1,
      -1,    79,    -1,    -1,    -1,    -1,    31,    32,    -1,    75,
      -1,    -1,    37,    79,    39,    11,    -1,    42,    -1,     3,
      45,    -1,    -1,     7,    20,    50,    -1,    -1,    -1,    25,
      55,    -1,    16,    58,    -1,    -1,    61,    -1,    -1,    -1,
      -1,    -1,    67,    11,    40,    41,    -1,    31,    32,    -1,
      75,    -1,    20,    37,    79,    39,    -1,    25,    42,    -1,
      -1,    45,    -1,    -1,    -1,    -1,    50,    -1,    64,    11,
      -1,    55,    40,    41,    58,    -1,    72,    61,    20,    -1,
      76,    -1,    -1,    -1,    -1,    81,    82,    83,    84,    85,
      -1,    75,    34,    11,    -1,    79,    -1,    -1,    40,    41,
      -1,    -1,    20,    -1,    72,    -1,    -1,    -1,    76,    -1,
      -1,    -1,    -1,    81,    82,    83,    84,    85,    11,    -1,
      -1,    -1,    40,    41,    -1,    -1,    -1,    20,    -1,    -1,
      72,    -1,    -1,    -1,    76,    -1,    -1,    -1,    -1,    81,
      82,    83,    84,    85,    11,    -1,    64,    40,    41,    -1,
      -1,    -1,    -1,    20,    72,    -1,    -1,    -1,    76,    -1,
      -1,    -1,    -1,    81,    82,    83,    84,    85,    -1,    -1,
      -1,    64,    -1,    40,    41,    -1,    -1,    -1,    -1,    72,
      -1,    -1,    -1,    76,    -1,    -1,    -1,    -1,    81,    82,
      83,    84,    85,    -1,    -1,    -1,     3,    -1,    -1,     3,
       7,    -1,     3,     7,    -1,    72,     7,    -1,    -1,    76,
      -1,    -1,    13,    -1,    81,    82,    83,    84,    85,    23,
      -1,    -1,    29,    27,    28,    29,    -1,    -1,    29,    -1,
      -1,    35,     3,    -1,    -1,    -1,     7,    -1,    45,    43,
      -1,    45,    -1,    -1,    45,    49,    53,    54,    55,    53,
      54,    55,    53,    54,    55,    59,    60,    -1,    29,    66,
      -1,    68,    69,    -1,    68,    69,    73,    68,    69,    73,
      -1,    -1,    73,     3,    45,    -1,    -1,     7,    -1,    -1,
      -1,    -1,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,
       3,    -1,    -1,    -1,     7,    66,    -1,    68,    69,    29,
      -1,    -1,    73,    -1,    -1,    -1,    -1,     3,    -1,    -1,
      -1,     7,    -1,    -1,    -1,    45,    29,    -1,    -1,    -1,
      -1,    -1,    -1,    53,    54,    55,    -1,    -1,    -1,    -1,
      -1,    -1,    45,    29,    -1,    -1,    66,    -1,    68,    69,
      53,    54,    55,    73,     3,    -1,    -1,    -1,     7,    45,
       3,    -1,    65,    -1,     7,    68,    69,    53,    54,    55,
      73,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    65,
      29,     3,    68,    69,    -1,     7,    29,    73,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    45,    -1,    -1,    -1,
      -1,    -1,    45,    -1,    53,    54,    55,    29,    -1,    -1,
      53,    54,    55,     3,    -1,    -1,    -1,     7,    67,    68,
      69,    -1,    65,    45,    73,    68,    69,    -1,    -1,    -1,
      73,    53,    54,    55,    -1,    -1,    -1,    -1,    -1,    29,
      -1,    -1,    -1,    65,    -1,    -1,    68,    69,    -1,    -1,
      -1,    73,    -1,    -1,    -1,    45,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    53,    54,    55,    -1,    -1,    -1,    -1,
      -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    68,    69,
      -1,    -1,    -1,    73
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     8,    11,    12,    20,    33,    34,    40,    41,    44,
      48,    57,    72,    75,    76,    77,    81,    82,    83,    84,
      85,    97,    98,    99,   100,   101,   102,   106,   108,   112,
     114,   118,   119,   120,   126,   127,   128,   129,   130,   136,
      58,   137,   113,   136,    77,   106,   119,   126,   106,    77,
     136,   107,   136,     0,    99,   115,   129,     6,   122,   129,
     136,    37,    36,    67,    36,   137,   136,   137,   136,    36,
      64,     3,     7,    16,    31,    32,    36,    37,    39,    42,
      45,    50,    55,    61,    79,   123,   136,   137,   167,   170,
     173,   179,   180,   181,   182,   184,    67,    38,    21,   120,
     133,   134,   135,    25,   109,   110,   111,   126,   116,   117,
     126,   107,   107,    67,   116,    67,   136,   173,    37,   173,
     173,   123,   124,   125,   182,    24,    37,   165,   166,   173,
     174,   175,   176,   182,   184,   126,   136,    32,    61,    32,
      61,   182,    37,    38,   171,    19,    16,    31,     3,     7,
      29,    45,    53,    54,    55,    68,    69,    73,   121,   182,
      65,    14,   120,    64,   110,   130,   117,   136,    36,    36,
      64,    37,    14,    64,    37,   126,   166,     4,    51,    63,
       5,     6,    46,    47,    52,    56,    70,    71,    74,    80,
      87,    65,    23,    27,    28,    35,    43,    49,    59,    60,
      65,    38,   183,   183,   177,   178,   182,   182,   170,   182,
     182,   182,   182,   182,   182,   182,   182,   182,   182,    66,
      36,   135,    67,    67,    37,    38,    67,   103,   104,   126,
     116,    67,   126,   125,    37,   165,   166,    65,    65,   165,
     165,   182,   182,   123,   182,   182,   182,   182,   182,   182,
     182,   182,   182,   182,   182,   182,   182,   182,   182,   182,
     182,   182,   182,    65,    14,    66,   172,   118,   131,   132,
     133,   182,    64,   104,   105,   136,   137,    64,     7,    65,
     182,    13,    66,   182,     9,    15,    16,    18,    26,    30,
      31,    62,    67,    78,    86,   138,   139,   140,   141,   142,
     143,   144,   145,   146,   147,   148,   152,   153,   160,   161,
     162,   163,   167,   168,   169,   173,   174,   118,    65,    66,
      67,    67,    67,    65,    65,   182,    67,    67,   173,    37,
     173,    67,   182,    64,   140,    67,    37,    36,    37,    37,
      16,    31,    67,    67,   182,    65,   165,    67,   142,   149,
     150,   138,   182,   165,    65,    65,    14,    67,    64,    65,
      65,    36,   142,   151,   165,    86,    36,    36,   138,    67,
      37,    10,    17,   154,   155,   156,   158,   159,   138,    64,
     150,   165,    64,   156,   181,    13,    64,    22,   164,    65,
      65,    13,   138,   157,    36,    36,    67,   157,   138,   138,
      64,    64
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *yybottom, yytype_int16 *yytop)
#else
static void
yy_stack_print (yybottom, yytop)
    yytype_int16 *yybottom;
    yytype_int16 *yytop;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; yybottom <= yytop; yybottom++)
    {
      int yybot = *yybottom;
      YYFPRINTF (stderr, " %d", yybot);
    }
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      YYFPRINTF (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      YYFPRINTF (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}

/* Prevent warnings from -Wmissing-prototypes.  */
#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */


/* The lookahead symbol.  */
int yychar;

/* The semantic value of the lookahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*-------------------------.
| yyparse or yypush_parse.  |
`-------------------------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{


    int yystate;
    /* Number of tokens to shift before error messages enabled.  */
    int yyerrstatus;

    /* The stacks and their tools:
       `yyss': related to states.
       `yyvs': related to semantic values.

       Refer to the stacks thru separate pointers, to allow yyoverflow
       to reallocate them elsewhere.  */

    /* The state stack.  */
    yytype_int16 yyssa[YYINITDEPTH];
    yytype_int16 *yyss;
    yytype_int16 *yyssp;

    /* The semantic value stack.  */
    YYSTYPE yyvsa[YYINITDEPTH];
    YYSTYPE *yyvs;
    YYSTYPE *yyvsp;

    YYSIZE_T yystacksize;

  int yyn;
  int yyresult;
  /* Lookahead token as an internal (translated) token number.  */
  int yytoken;
  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;

#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  yytoken = 0;
  yyss = yyssa;
  yyvs = yyvsa;
  yystacksize = YYINITDEPTH;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY; /* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */
  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;

	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),
		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss_alloc, yyss);
	YYSTACK_RELOCATE (yyvs_alloc, yyvs);
#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;

      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  if (yystate == YYFINAL)
    YYACCEPT;

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     lookahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to lookahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid lookahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the lookahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token.  */
  yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:

    {
                        T_FCALL *cp;
                        T_BLOCK *bp;

                        if (Se_errors == 0) {
                          symbol_check();
                          bp = GET_BLOCK("main");
                          if (bp == 0)
                            yyerror("undeclared block: main", ERR_FATAL);
                          do_main_check(bp);
                          for(cp=call_list; cp; cp=cp->c_next) {
                            cp->c_block = GET_BLOCK(cp->c_name);
                            if (cp->c_block)
                              do_param_check(cp);
                          }
                        }
                        }
    break;

  case 5:

    { }
    break;

  case 6:

    { }
    break;

  case 7:

    { }
    break;

  case 8:

    { }
    break;

  case 9:

    { }
    break;

  case 10:

    { }
    break;

  case 11:

    { }
    break;

  case 12:

    { }
    break;

  case 13:

    { }
    break;

  case 14:

    {
                        T_RETURN *rp;

                        for(rp=return_list; rp; rp=rp->ret_next)
                          if (rp->ret_expr) {
                            snprintf(error_buf, sizeof error_buf,
                              "typeless function: %s may not return a value",
                               (yyvsp[(1) - (1)].block)->b_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        }
    break;

  case 15:

    {
                        char name[BUFSIZ];
                        T_VARIABLE *vp;

                        (yyval.structure) = NEW(T_STRUCT);
                        (yyval.structure)->st_flags = SF_KSTAT;
                        (yyval.structure)->st_kname = (yyvsp[(3) - (8)].string);
                        (yyval.structure)->st_name = (yyvsp[(4) - (8)].string);
                        (yyval.structure)->st_missing = 1;
                        (yyval.structure)->st_members = reverse_member_list((yyvsp[(6) - (8)].variable));
                        for(vp=(yyval.structure)->st_members; vp; vp=vp->var_next) {
                          if (vp->var_name[0] == '\0') {
                            snprintf(name, sizeof name,
                              "missing%d", (yyval.structure)->st_missing++);
                            se_new_string(&vp->var_name, name);
                            vp->var_qname = se_string_save("");
                          }
                        }
                        PUT_STRUCT((yyvsp[(4) - (8)].string), (yyval.structure), NO_DUPS);
                        do_structure_check((yyval.structure));
                        if ((yyvsp[(3) - (8)].string))
                          se_add_kstat_type((yyval.structure));
                        in_local_scope = 0;
                        current_scope = 0;
                        }
    break;

  case 16:

    {
                          (yyval.structure) = (yyvsp[(2) - (2)].structure);
                          (yyval.structure)->st_flags = SF_KSTAT;
                          }
    break;

  case 17:

    {
                        (yyval.structure) = NEW(T_STRUCT);
                        (yyval.structure)->st_flags = SF_NDD;
                        (yyval.structure)->st_kname = (yyvsp[(3) - (8)].string);
                        (yyval.structure)->st_name = (yyvsp[(4) - (8)].string);
                        (yyval.structure)->st_missing = 1;
                        (yyval.structure)->st_members = reverse_member_list((yyvsp[(6) - (8)].variable));
                        PUT_STRUCT((yyvsp[(4) - (8)].string), (yyval.structure), NO_DUPS);
                        do_structure_check((yyval.structure));
                        se_add_ndd_type((yyval.structure));
                        in_local_scope = 0;
                        current_scope = 0;
                        }
    break;

  case 18:

    {
                          (yyval.structure) = (yyvsp[(2) - (2)].structure);
                          (yyval.structure)->st_flags = SF_MIB;
                          }
    break;

  case 19:

    {
                        (yyvsp[(2) - (2)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(2) - (2)].variable);
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        }
    break;

  case 20:

    {
                        (yyvsp[(1) - (1)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(1) - (1)].variable);
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 21:

    {
                        char name[BUFSIZ];
                        T_VARIABLE *vp;

                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (3)].var_type);
                        (yyval.variable)->var_name = (yyvsp[(2) - (3)].string);
                        if ((yyvsp[(1) - (3)].var_type) == VAR_USER)
                          yyerror("kstat contains no structures", ERR_FATAL);
                        if (se_get_keyword((yyvsp[(2) - (3)].string))) {
                          (yyval.variable)->var_qname = se_string_save((yyvsp[(2) - (3)].string));
                          snprintf(name, sizeof name, "SYM_%s", (yyvsp[(2) - (3)].string));
                          se_new_string(&((yyvsp[(2) - (3)].string)), name);
                        } else {
                          (yyval.variable)->var_qname = se_string_save((yyvsp[(2) - (3)].string));
                          if (se_cleanup_tok_syms((yyvsp[(2) - (3)].string)) == 0) {
                            se_free((yyval.variable)->var_qname);
                            (yyval.variable)->var_qname = 0;
                          }
                        }
                        /* do the missing thing in kstat_struct */
                        if ((yyvsp[(2) - (3)].string)[0] && (valid_name((yyvsp[(2) - (3)].string)) == 0)) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", (yyvsp[(2) - (3)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        for(vp=current_scope; vp; vp=vp->var_next)
                          if ((yyvsp[(2) - (3)].string)[0] && (strcmp(vp->var_name, (yyvsp[(2) - (3)].string)) == 0)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", (yyvsp[(2) - (3)].string));
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        }
    break;

  case 22:

    {
                        (yyval.string) = (yyvsp[(1) - (1)].string);
                        }
    break;

  case 23:

    {
                        (yyval.string) = (yyvsp[(1) - (1)].string);
                        }
    break;

  case 24:

    {
                        T_VARIABLE *vp;
                        int size;

                        (yyval.structure) = NEW(T_STRUCT);
                        (yyval.structure)->st_name = (yyvsp[(2) - (6)].string);
                        (yyval.structure)->st_members = reverse_member_list((yyvsp[(4) - (6)].variable));
                        PUT_STRUCT((yyvsp[(2) - (6)].string), (yyval.structure), NO_DUPS);
                        do_structure_check((yyval.structure));
                        in_local_scope = 0;
                        current_scope = 0;
                        }
    break;

  case 25:

    {
                        if (valid_name((yyvsp[(1) - (1)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid struct name: %s", (yyvsp[(1) - (1)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        in_local_scope = 1;
                        }
    break;

  case 26:

    {
                        T_BLOCK *bp;
                        T_BLOCK *current = 0;
                        T_BLOCK *next;

                        do_attach_check((yyvsp[(2) - (6)].string), (yyvsp[(4) - (6)].block));
                        for(bp=(yyvsp[(4) - (6)].block); bp; bp=next) {
                          /* extern variable declaration within attach */
                          next = bp->b_next;
                          if (bp->b_flags == B_EXTERN) {
                            T_VARIABLE *vp = bp->b_variables;

                            vp->var_flags |= VF_EXTERN;
                            vp->var_address = (caddr_t) bp->b_attachment;
                            vp->var_attach_lib = (yyvsp[(2) - (6)].string);
                            if (vp->var_type == VAR_USER)
                              se_address_inherit(vp, vp->var_address);
                            member_inherit(vp, VF_EXTERN);
                            se_free(bp);
                          } else {
                            bp->b_attach_lib = (yyvsp[(2) - (6)].string);
                            if (current == 0)
                              current = bp;
                            else
                              current = current->b_next = bp;
                          }
                        }
                        }
    break;

  case 27:

    {
                        do_attach_check((yyvsp[(2) - (3)].string), 0);
                        se_free((yyvsp[(2) - (3)].string));
                        }
    break;

  case 28:

    {
                        (yyvsp[(2) - (2)].block)->b_next = (yyvsp[(1) - (2)].block);
                        (yyval.block) = (yyvsp[(2) - (2)].block);
                        }
    break;

  case 29:

    {
                        (yyval.block) = (yyvsp[(1) - (1)].block);
                        }
    break;

  case 30:

    {
                        T_VARIABLE *vp;
                        int i;

                        /* count the params */
                        for(i=0, vp=(yyvsp[(4) - (6)].variable); vp; vp=vp->var_next, i++) {
#ifdef _LP64
                          if (vp->var_type == VAR_DOUBLE)
                            yyerror( 
                              "cannot pass double values to attached functions",
                               ERR_NONFATAL);
#else
                          if (Se_type_sizes[vp->var_type] == 8)
                            yyerror( 
                              "cannot pass 8 byte values to attached functions",
                               ERR_NONFATAL);
#endif
                          if (vp->var_type == VAR_ELLIPSIS)
                            if (vp->var_next)
                              yyerror("ellipsis must be last parameter",
                                       ERR_NONFATAL);
                        }
                        (yyval.block) = NEW(T_BLOCK);
                        (yyval.block)->b_name = (yyvsp[(2) - (6)].string);
                        (yyval.block)->b_parameters = (yyvsp[(4) - (6)].variable);
                        (yyval.block)->b_param_count = i;
                        if (block_already_called)
                          (yyval.block)->b_flags = B_REFERENCED;
                        block_already_called = 0;
                        if (i > MAX_ATT_ARGS) {
                          snprintf(error_buf, sizeof error_buf,
                          "cannot send more than %d args to attached functions",
                             MAX_ATT_ARGS);
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        PUT_BLOCK((yyvsp[(2) - (6)].string), (yyval.block), NO_DUPS);
                        if (get_builtin((yyvsp[(2) - (6)].string))) {
                          snprintf(error_buf, sizeof error_buf,
                            "redeclaration of builtin: %s",(yyvsp[(2) - (6)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if ((yyvsp[(1) - (6)].var_type)) {
                          vp = NEW(T_VARIABLE);
                          vp->var_type = (yyvsp[(1) - (6)].var_type);
                          if ((yyvsp[(1) - (6)].var_type) == VAR_USER) {
                            vp->var_struct = GET_STRUCT(block_type);
                            vp->var_un.var_user = new_user_type(vp);
                            fix_offsets(vp->var_un.var_user, 0, 0);
                          }
                          (yyval.block)->b_return = vp;
                        }
                        current_scope = 0;
                        in_local_scope = 0;
                        }
    break;

  case 31:

    {
                        (yyval.block) = NEW(T_BLOCK);
                        (yyval.block)->b_flags = B_EXTERN;
                        (yyval.block)->b_variables = (yyvsp[(2) - (3)].variable);
                        (yyval.block)->b_name = (yyvsp[(2) - (3)].variable)->var_name;
                        }
    break;

  case 32:

    {
                      (yyval.var_type) = (yyvsp[(1) - (1)].var_type);
                      }
    break;

  case 33:

    {
                      (yyval.var_type) = 0;
                      }
    break;

  case 34:

    {
                        if ((yyvsp[(2) - (2)].block)->b_variables) {
                          T_VARIABLE *vp;
                          T_STRUCT *sp;

                          /* build the struct */
                          sp = NEW(T_STRUCT);
                          sp->st_members = (yyvsp[(2) - (2)].block)->b_variables;

                          /* build a variable of this struct */
                          vp = NEW(T_VARIABLE);
                          vp->var_type = VAR_USER;
                          vp->var_name =
                            se_string_save("class_local_variables");
                          vp->var_struct = sp;
                          vp->var_un.var_user = sp;
                          (yyvsp[(1) - (2)].structure)->st_local_vars = vp;
                        }
                        (yyvsp[(1) - (2)].structure)->st_class = (yyvsp[(2) - (2)].block);
                        (yyval.structure) = (yyvsp[(1) - (2)].structure);
                        current_class_name = 0;
                        }
    break;

  case 35:

    {
                        current_class_name = (yyvsp[(1) - (1)].string);
                        }
    break;

  case 36:

    {
                        T_VARIABLE *vp;

                        in_class_scope = 1;
                        if (valid_name((yyvsp[(2) - (4)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid class name: %s", (yyvsp[(2) - (4)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        (yyval.structure) = NEW(T_STRUCT);
                        (yyval.structure)->st_name = (yyvsp[(2) - (4)].string);
                        (yyval.structure)->st_members = reverse_member_list((yyvsp[(4) - (4)].variable));
                        /* arrays must be allocated */
                        for(vp=(yyval.structure)->st_members; vp; vp=vp->var_next)
                          if (vp->var_dimension)
                            vp->var_un.var_array = new_array_type(vp);
                          /* as do structures */
                          else if (vp->var_type == VAR_USER)
                            vp->var_un.var_user = new_user_type(vp);
                        class_scope = (yyval.structure)->st_members;
                        PUT_STRUCT((yyvsp[(2) - (4)].string), (yyval.structure), NO_DUPS);
                        do_structure_check((yyval.structure));
                        }
    break;

  case 37:

    {
                        (yyval.block) = (yyvsp[(1) - (3)].block);
                        if ((yyvsp[(1) - (3)].block)->b_parameters)
                          yyerror("class code may not accept parameters",
                                   ERR_NONFATAL);
                        in_class_scope = 0;
                        class_scope = 0;
                        }
    break;

  case 38:

    {
                        (yyvsp[(2) - (2)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(2) - (2)].variable);
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        }
    break;

  case 39:

    {
                        (yyvsp[(1) - (1)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(1) - (1)].variable);
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 40:

    {
                        T_VARIABLE *vp;

                        if (valid_name((yyvsp[(2) - (3)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", (yyvsp[(2) - (3)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (3)].var_type);
                        (yyval.variable)->var_name = (yyvsp[(2) - (3)].string);
                        if (get_special_name((yyvsp[(2) - (3)].string)))
                          yyerror(
                            "structure members may not be active variables",
                               ERR_NONFATAL);
                        if ((yyvsp[(1) - (3)].var_type) == VAR_USER)
                          (yyval.variable)->var_struct = GET_STRUCT(type_name);
                        if (in_class_scope) {
                          for(vp=class_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, (yyvsp[(2) - (3)].string)) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", (yyvsp[(2) - (3)].string));
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } else
                          for(vp=current_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, (yyvsp[(2) - (3)].string)) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", (yyvsp[(2) - (3)].string));
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        }
    break;

  case 41:

    {
                        int n = 1;	/* if bad dimension, size is 1 */
                        T_VARIABLE *vp;
                        T_VARIABLE var;

                        if (valid_name((yyvsp[(2) - (6)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid member name: %s", (yyvsp[(2) - (6)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if ((yyvsp[(4) - (6)].expression)) {
                          if (integral_constant_expression((yyvsp[(4) - (6)].expression), INT_TYPES) == 0)
                            yyerror("integral constant expression expected",
                                     ERR_NONFATAL);
                          else {
                            var = zero_variable;
                            se_resolve_expression(&var, (yyvsp[(4) - (6)].expression), 0);
                            n = var.var_un.var_register;
                            if (n <= 0) {
                              snprintf(error_buf, sizeof error_buf,
                                      "absurd subscript value: %d", n);
                              yyerror(error_buf, ERR_NONFATAL);
                              n = 1;
                            }
                          }
                        } else
                          n = -1;
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (6)].var_type);
                        (yyval.variable)->var_name = (yyvsp[(2) - (6)].string);
                        (yyval.variable)->var_dimension = n;
                        if (n == -1)
                          (yyval.variable)->var_flags = VF_EMPTY;
                        if (get_special_name((yyvsp[(2) - (6)].string)))
                          yyerror(
                            "structure members may not be active variables",
                               ERR_NONFATAL);
                        if ((yyvsp[(1) - (6)].var_type) == VAR_USER)
                          (yyval.variable)->var_struct = GET_STRUCT(type_name);
                        if (in_class_scope) {
                          for(vp=class_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, (yyvsp[(2) - (6)].string)) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", (yyvsp[(2) - (6)].string));
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        } else
                          for(vp=current_scope; vp; vp=vp->var_next)
                            if (strcmp(vp->var_name, (yyvsp[(2) - (6)].string)) == 0) {
                              snprintf(error_buf, sizeof error_buf,
                                "redeclaration of %s", (yyvsp[(2) - (6)].string));
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                        }
    break;

  case 42:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 43:

    {
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        (yyval.variable)->var_special = SS_KVM;
                        }
    break;

  case 44:

    {
                        (yyvsp[(1) - (3)].variable)->var_initial = (yyvsp[(2) - (3)].expression);
                        if ((yyvsp[(2) - (3)].expression)) {
                          if ((yyvsp[(1) - (3)].variable)->var_dimension ||
                               (((yyvsp[(1) - (3)].variable)->var_type == VAR_USER) &&
                                ((yyvsp[(2) - (3)].expression)->e_type == E_AGGREGATE))) {
                            T_VARIABLE *vp = 0;
                            char *op = "\"CALL\"";

                            switch ((yyvsp[(2) - (3)].expression)->e_type) {
                            case E_EXPRESSION:
                              yyerror("{}-enclosed initializer required",
                                       ERR_NONFATAL);
                              break;
                            case E_VALUE:
                              if (((yyvsp[(1) - (3)].variable)->var_type == VAR_CHAR) &&
                                  ((yyvsp[(2) - (3)].expression)->e_variable->var_type == VAR_STRING)) {
                                vp = (yyvsp[(2) - (3)].expression)->e_variable;
                                break;
                              }
                              /* fall through */
                            default:
                              op = "\"VALUE\"";
                              /* fall through */
                            case E_CALL:
                              snprintf(error_buf, sizeof error_buf,
                                "non-constant initializer: op %s", op);
                              yyerror(error_buf, ERR_NONFATAL);
                              break;
                            case E_AGGREGATE:
                              vp = (yyvsp[(2) - (3)].expression)->e_variable;
                              (yyvsp[(2) - (3)].expression)->e_type = E_VALUE;
                              break;
                            }
                            if (vp) {
                              do_aggregate_check((yyvsp[(1) - (3)].variable), vp);
                              free_aggregate((yyvsp[(2) - (3)].expression)->e_variable);
                              se_free((yyvsp[(2) - (3)].expression));
                              (yyvsp[(1) - (3)].variable)->var_flags |= VF_AGGREGATE;
                            }
                            (yyvsp[(1) - (3)].variable)->var_initial = 0;
                          } else
                            do_assign_check((yyvsp[(1) - (3)].variable), (yyvsp[(2) - (3)].expression), "initialization", 0);
                        }
                        (yyval.variable) = (yyvsp[(1) - (3)].variable);
                        }
    break;

  case 45:

    {
                        if (valid_name((yyvsp[(2) - (2)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid variable name: %s", (yyvsp[(2) - (2)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (2)].var_type);
                        (yyval.variable)->var_name = (yyvsp[(2) - (2)].string);
                        if (in_local_scope) {
                          /* ok to redeclare global, not local */
                          if (GET_VARIABLE((yyval.variable)->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                                "declaration of %s hides earlier one",
                                (yyval.variable)->var_name);
                            yyerror(error_buf, ERR_WARNING);
                          } else if (get_variable((yyval.variable)->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", (yyval.variable)->var_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } else
                          PUT_VARIABLE((yyvsp[(2) - (2)].string), (yyval.variable), NO_DUPS);

                        if ((yyvsp[(1) - (2)].var_type) == VAR_USER) {
                          (yyval.variable)->var_struct = GET_STRUCT(type_name);
                          if (in_class_scope &&
                             (strcmp(type_name, current_class_name) == 0)) {
                              snprintf(error_buf, sizeof error_buf,
                                "incomplete type: %s", type_name);
                              yyerror(error_buf, ERR_FATAL);
                          } else {
                            (yyval.variable)->var_un.var_user = new_user_type((yyval.variable));
                            fix_offsets((yyval.variable)->var_un.var_user, 0, 0);
                          }
                        }
                        do_special_check((yyvsp[(2) - (2)].string), (yyval.variable));
                        }
    break;

  case 46:

    {
                        int i;
                        int n = 1;	/* if bad dimension, size is 1 */
                        T_VARIABLE var;

                        if (valid_name((yyvsp[(2) - (5)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid variable name: %s", (yyvsp[(2) - (5)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if ((yyvsp[(4) - (5)].expression)) {
                          if (integral_constant_expression((yyvsp[(4) - (5)].expression), INT_TYPES) == 0)
                            yyerror("integral constant expression expected",
                                     ERR_NONFATAL);
                          else {
                            var = zero_variable;
                            se_resolve_expression(&var, (yyvsp[(4) - (5)].expression), 0);
                            n = var.var_un.var_register;
                            if (n <= 0) {
                              snprintf(error_buf, sizeof error_buf,
                                      "absurd subscript value: %d", n);
                              yyerror(error_buf, ERR_NONFATAL);
                              n = 1;
                            }
                          }
                        } else
                          n = -1;
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (5)].var_type);
                        (yyval.variable)->var_name = (yyvsp[(2) - (5)].string);
                        (yyval.variable)->var_dimension = n;
                        if (n == -1)
                          (yyval.variable)->var_flags = VF_EMPTY;
                        if ((yyvsp[(1) - (5)].var_type) == VAR_USER)
                          (yyval.variable)->var_struct = GET_STRUCT(type_name);
                        (yyval.variable)->var_un.var_array = new_array_type((yyval.variable));
                        if (((yyvsp[(1) - (5)].var_type) == VAR_USER) && (n != -1)) {
                          T_STRUCT **spp;
                          int size;

                          spp = ((T_STRUCT **) (yyval.variable)->var_un.var_array);
                          size = spp[0]->st_size;
                          for(i=0; i<n; i++)
                            fix_offsets(spp[i], size * i, 1);
                        }
                        if (in_local_scope) {
                          if (get_variable((yyval.variable)->var_name)) {
                            snprintf(error_buf, sizeof error_buf,
                              "redeclaration of %s", (yyval.variable)->var_name);
                            yyerror(error_buf, ERR_NONFATAL);
                          }
                        } else
                          PUT_VARIABLE((yyvsp[(2) - (5)].string), (yyval.variable), NO_DUPS);
                        do_special_check((yyvsp[(2) - (5)].string), (yyval.variable));
                        if (((yyval.variable)->var_flags & VF_SPECIAL) == VF_CLASS)
                          yyerror(
                            "arrays of active class variables not allowed",
                            ERR_NONFATAL);
                        if ((((yyval.variable)->var_flags & VF_KVM) == VF_KVM) &&
                             ((yyvsp[(4) - (5)].expression) == 0))
                          yyerror(
                            "dynamic arrays of kvm variables not allowed",
                            ERR_NONFATAL);
                        }
    break;

  case 47:

    {
                        (yyval.expression) = (yyvsp[(1) - (1)].expression);
                        }
    break;

  case 48:

    {
                        (yyval.expression) = 0;
                        }
    break;

  case 49:

    {
                        (yyval.expression) = (yyvsp[(2) - (2)].expression);
                        }
    break;

  case 50:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_AGGREGATE;
                        (yyval.expression)->e_variable = (yyvsp[(2) - (2)].variable);
                        }
    break;

  case 51:

    {
                        (yyval.expression) = 0;
                        }
    break;

  case 52:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_name = se_string_save("aggregate");
                        (yyval.variable)->var_type = VAR_USER;
                        (yyval.variable)->var_struct = NEW(T_STRUCT);
                        (yyval.variable)->var_struct->st_members = reverse_member_list((yyvsp[(2) - (3)].variable));
                        }
    break;

  case 53:

    {
                        (yyvsp[(3) - (3)].variable)->var_next = (yyvsp[(1) - (3)].variable);
                        (yyval.variable) = (yyvsp[(3) - (3)].variable);
                        }
    break;

  case 54:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 55:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        if (integral_constant_expression((yyvsp[(1) - (1)].expression), AGG_TYPES) == 0) {
                          yyerror("integral constant expression expected",
                                   ERR_NONFATAL);
                          (yyval.variable)->var_type = VAR_BOGUS;
                        } else
                          se_resolve_expression((yyval.variable), (yyvsp[(1) - (1)].expression), 0);
                        }
    break;

  case 56:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 57:

    {
                        (yyval.var_type) = VAR_STRING;
                        }
    break;

  case 58:

    {
                        (yyval.var_type) = VAR_CHAR;
                        }
    break;

  case 59:

    {
                        (yyval.var_type) = VAR_SHORT;
                        }
    break;

  case 60:

    {
                        (yyval.var_type) = VAR_LONG;
                        }
    break;

  case 61:

    {
                        (yyval.var_type) = VAR_LONGLONG;
                        }
    break;

  case 62:

    {
                        (yyval.var_type) = VAR_UCHAR;
                        }
    break;

  case 63:

    {
                        (yyval.var_type) = VAR_USHORT;
                        }
    break;

  case 64:

    {
                        (yyval.var_type) = VAR_ULONG;
                        }
    break;

  case 65:

    {
                        (yyval.var_type) = VAR_ULONGLONG;
                        }
    break;

  case 66:

    {
                        (yyval.var_type) = VAR_DOUBLE;
                        }
    break;

  case 67:

    {
                        /* the scanner will do a symbol table lookup and *
                         * return this token.  Grab the type name from   *
                         * Lex_currtok.                                  */
                        strcpy(type_name,  Lex_currtok);
                        if (in_local_scope == 0)
                          strcpy(block_type, Lex_currtok);
                        (yyval.var_type) = VAR_USER;
                        }
    break;

  case 68:

    {
                        if (strcmp((yyvsp[(2) - (4)].string), "referenced") == 0) {
                          T_VARIABLE *vp;

                          vp = get_variable((yyvsp[(3) - (4)].string));
                          if (vp == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "pragma: variable %s is not declared", (yyvsp[(3) - (4)].string));
                            yyerror(error_buf, ERR_WARNING);
                          } else
                            vp->var_flags = (T_VFTYPE)
                              ((int) vp->var_flags | (int) (VF_REFERENCED | VF_PRAGMA_REF));
                        } else {
                          snprintf(error_buf, sizeof error_buf,
                            "unknown pragma: %s", (yyvsp[(2) - (4)].string));
                          yyerror(error_buf, ERR_WARNING);
                        }
                        se_free((yyvsp[(2) - (4)].string));
                        se_free((yyvsp[(3) - (4)].string));
                        }
    break;

  case 69:

    {
                        T_VARIABLE *vp;
                        T_RETURN *rp;

                        vp = NEW(T_VARIABLE);
                        vp->var_type = (yyvsp[(1) - (2)].var_type);
                        if ((yyvsp[(1) - (2)].var_type) == VAR_USER) {
                          vp->var_struct = GET_STRUCT(block_type);
                          vp->var_un.var_user = new_user_type(vp);
                        }
                        if (return_list == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "function: %s returns no value", (yyvsp[(2) - (2)].block)->b_name);
                          yyerror(error_buf, ERR_WARNING);
                        }
                        for(rp=return_list; rp; rp=rp->ret_next)
                          do_return_check(vp, rp);
                        (yyvsp[(2) - (2)].block)->b_return = vp;
                        (yyval.block) = (yyvsp[(2) - (2)].block);
                        }
    break;

  case 70:

    {
                        T_RETURN *rp;
                        T_VARIABLE *vp;
                        int i;
                        int ellipsis = 0;

                        /* count the params */
                        for(i=0, vp=(yyvsp[(3) - (8)].variable); vp; vp=vp->var_next, i++)
                          if (vp->var_type == VAR_ELLIPSIS)
                            ellipsis++;
                        if (ellipsis)
                         yyerror("ellipsis only allowed for attached functions",
                                   ERR_NONFATAL);
                        /* unlink the local var list from the param list */
                        if (last_variable) {
                          last_variable->var_next = 0;
                          last_variable = 0;
                        }
                        (yyval.block) = NEW(T_BLOCK);
                        (yyval.block)->b_name = (yyvsp[(1) - (8)].string);
                        (yyval.block)->b_parameters = (yyvsp[(3) - (8)].variable);
                        (yyval.block)->b_param_count = i;
                        (yyval.block)->b_variables = reverse_member_list((yyvsp[(6) - (8)].variable));
                        (yyval.block)->b_statements = (yyvsp[(7) - (8)].statement);
                        if (in_class_scope)
                          add_special_name((yyvsp[(1) - (8)].string));
                        else
                          PUT_BLOCK((yyvsp[(1) - (8)].string), (yyval.block), ALLOW_DUPS);
                        current_scope = 0;
                        in_local_scope = 0;
                        for(rp=return_list; rp; rp=rp->ret_next)
                          rp->ret_block = (yyval.block);
                        current_scope_name = 0;
                        if (get_builtin((yyvsp[(1) - (8)].string))) {
                          snprintf(error_buf, sizeof error_buf,
                            "redeclaration of builtin: %s",(yyvsp[(1) - (8)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        block_already_called = 0;
                        }
    break;

  case 71:

    {
                        if (valid_name((yyvsp[(1) - (1)].string)) == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "invalid block name: %s", (yyvsp[(1) - (1)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                        }
                        if (in_class_scope == 0) {
                          if (avlget(Se_symbol_table, (yyvsp[(1) - (1)].string)))
                            block_already_called = 1;
                          /* this will check for dups */
                          PUT_BLOCK((yyvsp[(1) - (1)].string), 0, NO_DUPS);
                        }
                        in_local_scope = 1;
                        current_scope_name = (yyvsp[(1) - (1)].string);
                        return_list = 0;
                        (yyval.string) = (yyvsp[(1) - (1)].string);
                        }
    break;

  case 72:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 73:

    {
                        (yyval.variable) = 0;
                        }
    break;

  case 74:

    {
                        (yyvsp[(2) - (2)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(2) - (2)].variable);
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        }
    break;

  case 75:

    {
                        (yyvsp[(1) - (1)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(1) - (1)].variable);
                        last_variable = (yyvsp[(1) - (1)].variable);
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 76:

    {
                        T_VARIABLE *vp;

                        (yyval.variable) = reverse_member_list((yyvsp[(1) - (1)].variable));
                        current_scope = (yyval.variable);
                        for(vp=current_scope; vp; vp=vp->var_next)
                          if (vp->var_flags & VF_SPECIAL)
                            yyerror("special variables cannot be parameters",
                                     ERR_NONFATAL);
                        }
    break;

  case 77:

    {
                        (yyval.variable) = 0;
                        }
    break;

  case 78:

    {
                        (yyvsp[(3) - (3)].variable)->var_next = current_scope;
                        current_scope = (yyvsp[(3) - (3)].variable);
                        (yyval.variable) = (yyvsp[(3) - (3)].variable);
                        /* last_parameter = $3; */
                        }
    break;

  case 79:

    {
                        last_parameter = (yyvsp[(1) - (1)].variable);
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        current_scope = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 80:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 81:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = VAR_ELLIPSIS;
                        (yyval.variable)->var_name = se_string_save("ellipsis");
                        }
    break;

  case 82:

    {
                        (yyval.string) = se_string_save(Lex_currtok);
                        }
    break;

  case 83:

    {
                        (yyval.string) = se_string_save(se_kill_double_quotes(Lex_currtok));
                        }
    break;

  case 84:

    {
                        (yyval.statement) = reverse_statement_list((yyvsp[(1) - (1)].statement));
                        }
    break;

  case 85:

    {
                        (yyvsp[(2) - (2)].statement)->s_next = (yyvsp[(1) - (2)].statement);
                        (yyvsp[(2) - (2)].statement)->s_line_no = Lex_line_no;
                        (yyval.statement) = (yyvsp[(2) - (2)].statement);
                        }
    break;

  case 86:

    {
                        (yyval.statement) = (yyvsp[(1) - (1)].statement);
                        }
    break;

  case 87:

    {
                        (yyval.statement) = (yyvsp[(1) - (1)].statement);
                        }
    break;

  case 88:

    {
                        (yyval.statement) = (yyvsp[(1) - (2)].statement);
                        }
    break;

  case 89:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_NULL;
                        (yyval.statement)->s_function = Se_functions[S_NULL];
                        }
    break;

  case 90:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_IF;
                        (yyval.statement)->s_un.s_if = (yyvsp[(1) - (1)].if_statement);
                        (yyval.statement)->s_function = Se_functions[S_IF];
                        }
    break;

  case 91:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_WHILE;
                        (yyval.statement)->s_un.s_while = (yyvsp[(1) - (1)].while_statement);
                        (yyval.statement)->s_function = Se_functions[S_WHILE];
                        }
    break;

  case 92:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_FOR;
                        (yyval.statement)->s_un.s_for = (yyvsp[(1) - (1)].for_statement);
                        (yyval.statement)->s_function = Se_functions[S_FOR];
                        }
    break;

  case 93:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_DO;
                        (yyval.statement)->s_un.s_do = (yyvsp[(1) - (1)].do_statement);
                        (yyval.statement)->s_function = Se_functions[S_DO];
                        }
    break;

  case 94:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_SWITCH;
                        (yyval.statement)->s_un.s_switch = (yyvsp[(1) - (1)].switch_statement);
                        (yyval.statement)->s_function = Se_functions[S_SWITCH];
                        }
    break;

  case 95:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_RETURN;
                        (yyval.statement)->s_un.s_return = (yyvsp[(1) - (1)].return_statement);
                        (yyval.statement)->s_function = Se_functions[S_RETURN];
                        }
    break;

  case 96:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_BREAK;
                        (yyval.statement)->s_un.s_break = (yyvsp[(1) - (1)].break_statement);
                        (yyval.statement)->s_function = Se_functions[S_BREAK];
                        }
    break;

  case 97:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_CONTINUE;
                        (yyval.statement)->s_un.s_continue = (yyvsp[(1) - (1)].continue_statement);
                        (yyval.statement)->s_function = Se_functions[S_CONTINUE];
                        }
    break;

  case 98:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_CALL;
                        (yyval.statement)->s_un.s_call = (yyvsp[(1) - (1)].call_statement);
                        (yyval.statement)->s_function = Se_functions[S_CALL];
                        }
    break;

  case 99:

    {
                        T_VARIABLE *vp = (yyvsp[(1) - (1)].assign_statement)->a_variable;

                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_ASSIGN;
                        (yyval.statement)->s_un.s_assign = (yyvsp[(1) - (1)].assign_statement);
                        (yyval.statement)->s_function = Se_functions[S_ASSIGN];
                        if (is_lazy(vp))
                          (yyval.statement) = do_lazy_lvalue((yyval.statement));
                        }
    break;

  case 100:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_INCREMENT;
                        (yyval.statement)->s_un.s_variable = (yyvsp[(1) - (1)].variable);
                        (yyval.statement)->s_function = Se_functions[S_INCREMENT];
                        if (is_lazy((yyvsp[(1) - (1)].variable)))
                          (yyval.statement) = do_lazy_lvalue((yyval.statement));
                        }
    break;

  case 101:

    {
                        (yyval.statement) = NEW(T_STATEMENT);
                        (yyval.statement)->s_type = S_DECREMENT;
                        (yyval.statement)->s_un.s_variable = (yyvsp[(1) - (1)].variable);
                        (yyval.statement)->s_function = Se_functions[S_DECREMENT];
                        if (is_lazy((yyvsp[(1) - (1)].variable)))
                          (yyval.statement) = do_lazy_lvalue((yyval.statement));
                        }
    break;

  case 102:

    {
                        (yyval.variable) = (yyvsp[(1) - (2)].variable);
                        if ((yyval.variable) && ((((yyval.variable)->var_type & VAR_INTEGRAL) == 0) ||
                                   (((yyval.variable)->var_dimension &&
                                    ((yyval.variable)->var_subscript == 0))))) {
                          yyerror("operands must have scalar type: op \"++\"",
                                   ERR_NONFATAL);
                        }
                        }
    break;

  case 103:

    {
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        if ((yyval.variable) && ((((yyval.variable)->var_type & VAR_INTEGRAL) == 0)) ||
                                   (((yyval.variable)->var_dimension &&
                                    ((yyval.variable)->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"++\"",
                                   ERR_NONFATAL);
                        }
                        }
    break;

  case 104:

    {
                        (yyval.variable) = (yyvsp[(1) - (2)].variable);
                        if ((yyval.variable) && ((((yyval.variable)->var_type & VAR_INTEGRAL) == 0)) ||
                                   (((yyval.variable)->var_dimension &&
                                    ((yyval.variable)->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"--\"",
                                   ERR_NONFATAL);
                        }
                        }
    break;

  case 105:

    {
                        (yyval.variable) = (yyvsp[(2) - (2)].variable);
                        if ((yyval.variable) && ((((yyval.variable)->var_type & VAR_INTEGRAL) == 0)) ||
                                   (((yyval.variable)->var_dimension &&
                                    ((yyval.variable)->var_subscript == 0)))) {
                          yyerror("operands must have scalar type: op \"--\"",
                                   ERR_NONFATAL);
                        }
                        }
    break;

  case 106:

    {
                        (yyval.for_statement) = NEW(T_FOR);
                        (yyval.for_statement)->f_before = (yyvsp[(3) - (11)].statement);
                        (yyval.for_statement)->f_while = (yyvsp[(5) - (11)].l_expression);
                        (yyval.for_statement)->f_after = (yyvsp[(7) - (11)].statement);
                        (yyval.for_statement)->f_statements = (yyvsp[(10) - (11)].statement);
                        do_for_check((yyval.for_statement));
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        }
    break;

  case 107:

    {
                        (yyval.do_statement) = NEW(T_DO);
                        (yyval.do_statement)->do_statements = (yyvsp[(3) - (9)].statement);
                        (yyval.do_statement)->do_while = (yyvsp[(7) - (9)].l_expression);
                        do_do_check((yyval.do_statement));
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        }
    break;

  case 108:

    {
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        }
    break;

  case 109:

    {
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        }
    break;

  case 110:

    {
                        (yyvsp[(3) - (3)].statement)->s_next = (yyvsp[(1) - (3)].statement);
                        (yyval.statement) = (yyvsp[(3) - (3)].statement);
                        }
    break;

  case 111:

    {
                        (yyval.statement) = (yyvsp[(1) - (1)].statement);
                        }
    break;

  case 112:

    {
                        (yyval.statement) = reverse_statement_list((yyvsp[(1) - (1)].statement));
                        }
    break;

  case 113:

    {
                        (yyval.statement) = 0;
                        }
    break;

  case 114:

    {
                        (yyval.l_expression) = (yyvsp[(1) - (1)].l_expression);
                        }
    break;

  case 115:

    {
                        (yyval.l_expression) = 0;
                        }
    break;

  case 116:

    {
                        (yyval.switch_statement) = NEW(T_SWITCH);
                        (yyval.switch_statement)->sw_expr = (yyvsp[(3) - (7)].expression);
                        (yyval.switch_statement)->sw_case_list = (yyvsp[(6) - (7)].case_statement);
                        do_switch_check((yyval.switch_statement));
                        break_list = (T_BREAK *) pop(&break_stack);
                        }
    break;

  case 117:

    {
                        push(break_list, &break_stack);
                        }
    break;

  case 118:

    {
                        (yyval.case_statement) = reverse_case_list((yyvsp[(1) - (1)].case_statement));
                        }
    break;

  case 119:

    {
                        (yyvsp[(2) - (2)].case_statement)->ca_next = (yyvsp[(1) - (2)].case_statement);
                        (yyval.case_statement) = (yyvsp[(2) - (2)].case_statement);
                        }
    break;

  case 120:

    {
                        (yyval.case_statement) = (yyvsp[(1) - (1)].case_statement);
                        }
    break;

  case 121:

    {
                        (yyval.case_statement) = (yyvsp[(1) - (4)].case_statement);
                        (yyval.case_statement)->ca_value = (yyvsp[(2) - (4)].variable);
                        (yyval.case_statement)->ca_statements = (yyvsp[(4) - (4)].statement);
                        }
    break;

  case 122:

    {
                        (yyval.case_statement) = (yyvsp[(1) - (3)].case_statement);
                        (yyval.case_statement)->ca_statements = (yyvsp[(3) - (3)].statement);
                        }
    break;

  case 123:

    {
                        (yyval.statement) = (yyvsp[(1) - (1)].statement);
                        }
    break;

  case 124:

    {
                        (yyval.statement) = 0;
                        }
    break;

  case 125:

    {
                        (yyval.case_statement) = NEW(T_CASE);
                        (yyval.case_statement)->ca_line_no = Lex_line_no;
                        }
    break;

  case 126:

    {
                        (yyval.case_statement) = NEW(T_CASE);
                        (yyval.case_statement)->ca_line_no = Lex_line_no;
                        }
    break;

  case 127:

    {
                        (yyval.break_statement) = NEW(T_BREAK);
                        if (break_stack.st_top == 0)
                          yyerror("\"break\" outside loop or switch",
                                    ERR_NONFATAL);
                        else {
                          (yyval.break_statement)->brk_next = break_list;
                          break_list = (yyval.break_statement);
                        }
                        }
    break;

  case 128:

    {
                        (yyval.continue_statement) = NEW(T_CONTINUE);
                        if (continue_stack.st_top == 0)
                          yyerror("\"continue\" outside loop",
                                    ERR_NONFATAL);
                        else {
                          (yyval.continue_statement)->con_next = continue_list;
                          continue_list = (yyval.continue_statement);
                        }
                        }
    break;

  case 129:

    {
                        (yyval.return_statement) = NEW(T_RETURN);
                        (yyval.return_statement)->ret_line_no = Lex_line_no;
                        (yyval.return_statement)->ret_next = return_list;
                        return_list = (yyval.return_statement);
                        }
    break;

  case 130:

    {
                        (yyval.return_statement) = NEW(T_RETURN);
                        (yyval.return_statement)->ret_expr = (yyvsp[(2) - (3)].expression);
                        (yyval.return_statement)->ret_line_no = Lex_line_no;
                        (yyval.return_statement)->ret_next = return_list;
                        return_list = (yyval.return_statement);
                        }
    break;

  case 131:

    {
                        (yyval.if_statement) = NEW(T_IF);
                        (yyval.if_statement)->i_if = (yyvsp[(3) - (8)].l_expression);
                        (yyval.if_statement)->i_then = (yyvsp[(6) - (8)].statement);
                        (yyval.if_statement)->i_else = (yyvsp[(8) - (8)].statement);
                        }
    break;

  case 132:

    {
                        (yyval.statement) = (yyvsp[(3) - (4)].statement);
                        }
    break;

  case 133:

    {
                        (yyval.statement) = 0;
                        }
    break;

  case 134:

    {
                        (yyval.l_expression) = (yyvsp[(1) - (1)].l_expression);
                        }
    break;

  case 135:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (T_EXPR *) (yyvsp[(2) - (3)].l_expression);
                        (yyval.l_expression)->le_op = LE_PREC;
                        }
    break;

  case 136:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (T_EXPR *) (yyvsp[(3) - (4)].l_expression);
                        (yyval.l_expression)->le_op = LE_NOT;
                        }
    break;

  case 137:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_LT;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "<");
                        }
    break;

  case 138:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_GT;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), ">");
                        }
    break;

  case 139:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_LE;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "<=");
                        }
    break;

  case 140:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_GE;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), ">=");
                        }
    break;

  case 141:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_EQ;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "==");
                        }
    break;

  case 142:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_RE_EQ;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "=~");
                        }
    break;

  case 143:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_RE_NEQ;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "!=~");
                        }
    break;

  case 144:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (yyvsp[(1) - (3)].expression);
                        (yyval.l_expression)->le_op = LE_NE;
                        (yyval.l_expression)->le_right = (yyvsp[(3) - (3)].expression);
                        l_expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "!=");
                        }
    break;

  case 145:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (T_EXPR *) (yyvsp[(1) - (3)].l_expression);
                        (yyval.l_expression)->le_op = LE_AND;
                        (yyval.l_expression)->le_right = (T_EXPR *) (yyvsp[(3) - (3)].l_expression);
                        }
    break;

  case 146:

    {
                        (yyval.l_expression) = NEW(T_LEXPR);
                        (yyval.l_expression)->le_left = (T_EXPR *) (yyvsp[(1) - (3)].l_expression);
                        (yyval.l_expression)->le_op = LE_OR;
                        (yyval.l_expression)->le_right = (T_EXPR *) (yyvsp[(3) - (3)].l_expression);
                        }
    break;

  case 147:

    {
                        T_BMAP *bp;
                        T_EXPR *ep;
                        int i;

                        /* count the args */
                        for(i=0, ep=(yyvsp[(3) - (4)].expression); ep; ep=ep->e_next, i++)
                          ;
                        (yyval.call_statement) = NEW(T_FCALL);
                        (yyval.call_statement)->c_name = (yyvsp[(1) - (4)].string);
                        (yyval.call_statement)->c_args = (yyvsp[(3) - (4)].expression);
                        (yyval.call_statement)->c_arg_count = i;
                        (yyval.call_statement)->c_line_no = Lex_line_no;
                        (yyval.call_statement)->c_block = GET_BLOCK((yyvsp[(1) - (4)].string));
                        bp = get_builtin((yyvsp[(1) - (4)].string));
                        if (bp) {
                          do_builtin_check(bp, 0, (yyval.call_statement), (yyvsp[(3) - (4)].expression), i);
                          (yyval.call_statement)->c_builtin = Se_functions[bp->bm_stype];
                        } else {
                          (yyval.call_statement)->c_next = call_list;
                          call_list = (yyval.call_statement);
                          if ((yyval.call_statement)->c_block) {
                            if (current_scope_name &&
                               (strcmp((yyvsp[(1) - (4)].string), current_scope_name) == 0)) {
                              snprintf(error_buf, sizeof error_buf,
                                "recursive call to: %s", (yyvsp[(1) - (4)].string));
                              yyerror(error_buf, ERR_NONFATAL);
                            }
                            if ((yyval.call_statement)->c_block->b_attachment) {
                              if ((yyval.call_statement)->c_arg_count > MAX_ATT_ARGS) {
                                snprintf(error_buf, sizeof error_buf,
                          "cannot send more than %d args to attached functions",
                                   MAX_ATT_ARGS);
                                yyerror(error_buf, ERR_NONFATAL);
                              }
                              (yyval.call_statement)->c_block->b_flags |= B_REFERENCED;
                              (yyval.call_statement)->c_builtin = Se_functions[S_ATTACHMENT];
                            }
                          } else {
                            PUT_BLOCK((yyvsp[(1) - (4)].string), 0, ALLOW_DUPS);
                          }
                        }
                        }
    break;

  case 148:

    {
                        (yyval.while_statement) = NEW(T_WHILE);
                        (yyval.while_statement)->w_expr = (yyvsp[(3) - (7)].l_expression);
                        (yyval.while_statement)->w_statements = (yyvsp[(6) - (7)].statement);
                        do_while_check((yyval.while_statement));
                        break_list = (T_BREAK *) pop(&break_stack);
                        continue_list = (T_CONTINUE *) pop(&continue_stack);
                        }
    break;

  case 149:

    {
                        push(break_list, &break_stack);
                        push(continue_list, &continue_stack);
                        }
    break;

  case 150:

    {
                        T_VARIABLE *vp;

                        if (last_dot_component) {
                          (yyval.variable) = last_dot_component;
                          last_dot_component =
                            do_dot_check((yyval.variable)->var_name, (yyvsp[(1) - (1)].string), (yyval.variable), 0);
                          if (last_dot_component)
                            last_dot_component->var_parent = (yyval.variable);
                          (yyval.variable) = last_dot_component;
                        } else {
                          (yyval.variable) = get_variable((yyvsp[(1) - (1)].string));
                          if ((yyval.variable) == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "undeclared variable: %s", (yyvsp[(1) - (1)].string));
                            yyerror(error_buf, ERR_NONFATAL);
                          } else {
                            (yyval.variable)->var_flags |= VF_REFERENCED;
                            if ((yyval.variable)->var_type == VAR_USER)
                              (yyval.variable)->var_struct->st_flags |= SF_REFERENCED;
                          }
                          last_dot_component = (yyval.variable);
                        }
                        }
    break;

  case 151:

    {
                        (yyval.variable) = (yyvsp[(3) - (3)].variable);
                        }
    break;

  case 152:

    {
                        int already_new = 0;

                        if (last_dot_component) {
                          (yyval.variable) = last_dot_component;
                          last_dot_component =
                            do_dot_check((yyval.variable)->var_name, (yyvsp[(1) - (4)].string), (yyval.variable), &already_new);
                          if (last_dot_component)
                            last_dot_component->var_parent = (yyval.variable);
                          (yyval.variable) = last_dot_component;
                        } else {
                          (yyval.variable) = get_variable((yyvsp[(1) - (4)].string));
                          if ((yyval.variable) == 0) {
                            snprintf(error_buf, sizeof error_buf,
                              "undeclared variable: %s", (yyvsp[(1) - (4)].string));
                            yyerror(error_buf, ERR_NONFATAL);
                          } else {
                            (yyval.variable)->var_flags |= VF_REFERENCED;
                            if ((yyval.variable)->var_type == VAR_USER)
                              (yyval.variable)->var_struct->st_flags |= SF_REFERENCED;
                          }
                          last_dot_component = (yyval.variable);
                        }
                        if ((yyval.variable)) {
                          T_VARIABLE *vp;

                          if (already_new)
                            vp = (yyval.variable);
                          else {
                            vp = NEW(T_VARIABLE);
                            *vp = *(yyval.variable);
                            vp->var_next = (yyval.variable)->var_instances;
                            (yyval.variable)->var_instances = vp;
                          }
                          (yyval.variable) = do_array_check((yyvsp[(1) - (4)].string), (yyvsp[(3) - (4)].expression), vp);
                          last_dot_component = vp;
                        }
                        }
    break;

  case 153:

    {
                        push(last_dot_component, &component_stack);
                        last_dot_component = 0;
                        }
    break;

  case 154:

    {
                      last_dot_component = (T_VARIABLE *) pop(&component_stack);
                        }
    break;

  case 155:

    {
                        T_VARIABLE *vp;
                        T_VARIABLE *last;
                        T_VARIABLE *parent;

                        last_dot_component = 0;
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);

                        /* trim trailing instances from previous lvalues     *
                         * collected by already_new code in l_value nonterm. */

                        if ((yyvsp[(1) - (1)].variable) && ((yyvsp[(1) - (1)].variable)->var_flags & VF_MEMBER) &&
                                   (yyvsp[(1) - (1)].variable)->var_instances) {
                          parent = (yyvsp[(1) - (1)].variable)->var_instances->var_parent;
                          for(vp=(yyvsp[(1) - (1)].variable)->var_instances; vp; vp=vp->var_next) {
                            if (vp->var_parent != parent) {
                              last->var_next = 0;
                              break;
                            }
                            last = vp;
                          }
                        }
/*
{
printf("%s: 0x%x\n", $1->var_name, $1);
for(vp=$1->var_instances; vp; vp=vp->var_next)
  printf("\t0x%x: 0x%x\n", vp, vp->var_parent);
}
*/
                        }
    break;

  case 156:

    {
                        (yyval.assign_statement) = (yyvsp[(1) - (1)].assign_statement);
                        }
    break;

  case 157:

    {
                        (yyval.assign_statement) = (yyvsp[(1) - (1)].assign_statement);
                        }
    break;

  case 158:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_ASSIGN;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        if ((yyvsp[(3) - (3)].expression)->e_type == E_CALL &&
                            (yyvsp[(3) - (3)].expression)->e_call->c_name &&
                            (strcmp((yyvsp[(3) - (3)].expression)->e_call->c_name, "new") == 0) &&
                            ((yyvsp[(1) - (3)].variable) && ((yyvsp[(1) - (3)].variable)->var_flags & VF_EMPTY) == 0))
                            yyerror("cannot new non-dynamic array",
                                     ERR_NONFATAL);
                        do_assign_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "assignment", 0);
                        }
    break;

  case 159:

    {
                        T_VARIABLE *vp = new_variable((yyvsp[(1) - (3)].variable));

                        if ((yyvsp[(1) - (3)].variable)->var_dimension == -1)
                          yyerror("too many array initializers", ERR_NONFATAL);
                        else {
                          /* init a clone of the assigned var with an agg */
                          do_aggregate_check(vp, (yyvsp[(3) - (3)].variable));
                          vp->var_flags |= VF_AGGREGATE;
                        }

                        /* now, it's just a variable assignment */
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_ASSIGN;
                        (yyval.assign_statement)->a_expression = NEW(T_EXPR);
                        (yyval.assign_statement)->a_expression->e_type = E_VALUE;
                        (yyval.assign_statement)->a_expression->e_variable = vp;
                        }
    break;

  case 160:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_ADD;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "+=");
                        }
    break;

  case 161:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_SUBTRACT;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "-=");
                        }
    break;

  case 162:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_MULTIPLY;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "*=");
                        }
    break;

  case 163:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_DIVIDE;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "/=");
                        }
    break;

  case 164:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_MODULUS;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "%=");
                        }
    break;

  case 165:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_BIT_AND;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "&=");
                        }
    break;

  case 166:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_BIT_OR;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "|=");
                        }
    break;

  case 167:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_BIT_XOR;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "^=");
                        }
    break;

  case 168:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_SHIFT_LEFT;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), "<<=");
                        }
    break;

  case 169:

    {
                        (yyval.assign_statement) = NEW(T_ASSIGN);
                        (yyval.assign_statement)->a_variable = (yyvsp[(1) - (3)].variable);
                        (yyval.assign_statement)->a_op = A_SHIFT_RIGHT;
                        (yyval.assign_statement)->a_expression = (yyvsp[(3) - (3)].expression);
                        do_compound_check((yyvsp[(1) - (3)].variable), (yyvsp[(3) - (3)].expression), ">>=");
                        }
    break;

  case 170:

    {
                        (yyval.expression) = reverse_arg_list((yyvsp[(1) - (1)].expression));
                        }
    break;

  case 171:

    {
                        (yyval.expression) = 0;
                        }
    break;

  case 172:

    {
                        (yyvsp[(3) - (3)].expression)->e_next = (yyvsp[(1) - (3)].expression);
                        (yyval.expression) = (yyvsp[(3) - (3)].expression);
                        }
    break;

  case 173:

    {
                        (yyval.expression) = (yyvsp[(1) - (1)].expression);
                        }
    break;

  case 174:

    {
                        (yyval.var_type) = VAR_CONSTANT;
                        }
    break;

  case 175:

    {
                        (yyval.var_type) = VAR_DOUBLE;
                        }
    break;

  case 176:

    {
                        (yyval.var_type) = VAR_CONSTANT;
                        }
    break;

  case 177:

    {
                        (yyval.var_type) = VAR_DOUBLE;
                        }
    break;

  case 178:

    {
                        Lex_integerValue = Lex_integerValue * -1;
                        (yyval.var_type) = VAR_CONSTANT;
                        }
    break;

  case 179:

    {
                        Lex_doubleValue = -Lex_doubleValue;
                        (yyval.var_type) = VAR_DOUBLE;
                        }
    break;

  case 180:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 181:

    {
                        (yyval.variable) = (yyvsp[(1) - (1)].variable);
                        }
    break;

  case 182:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = (yyvsp[(1) - (1)].var_type);
                        if ((yyvsp[(1) - (1)].var_type) == VAR_CONSTANT)
                          (yyval.variable)->var_un.var_register = Lex_integerValue;
                        else
                          (yyval.variable)->var_un.var_rdigit = Lex_doubleValue;
                        }
    break;

  case 183:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = VAR_STRING;
                        (yyval.variable)->var_un.var_string = (yyvsp[(1) - (1)].string);
                        }
    break;

  case 184:

    {
                        (yyval.variable) = NEW(T_VARIABLE);
                        (yyval.variable)->var_type = VAR_STRING;
                        (yyval.variable)->var_un.var_string = 0;
                        }
    break;

  case 185:

    {
                        (yyval.expression) = (yyvsp[(1) - (1)].expression);
                        }
    break;

  case 186:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_op   = EO_PRECEDENCE;
                        (yyval.expression)->e_left = (yyvsp[(2) - (3)].expression);
                        }
    break;

  case 187:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_QCOP;
                        (yyval.expression)->e_lexpr = (yyvsp[(2) - (7)].l_expression);
                        (yyval.expression)->e_left = (yyvsp[(4) - (7)].expression);
                        (yyval.expression)->e_right = (yyvsp[(6) - (7)].expression);
                        expr_clash_check((yyvsp[(4) - (7)].expression), (yyvsp[(6) - (7)].expression), "?:");
                        }
    break;

  case 188:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_ASSIGN;
                        (yyval.expression)->e_assign = (yyvsp[(2) - (3)].assign_statement);
                        }
    break;

  case 189:

    {
                        (yyval.expression) = (yyvsp[(2) - (3)].expression);
                        }
    break;

  case 190:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        /* inline a call to the lazy evaluator */
                        if (is_lazy((yyvsp[(1) - (1)].variable)))
                          do_lazy_value((yyval.expression), (yyvsp[(1) - (1)].variable));
                        else {
                          (yyval.expression)->e_type = E_VALUE;
                          (yyval.expression)->e_variable = (yyvsp[(1) - (1)].variable);
                        }
                        }
    break;

  case 191:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = (yyvsp[(1) - (1)].call_statement);
                        }
    break;

  case 192:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_variable = (yyvsp[(1) - (2)].variable);
                        (yyval.expression)->e_type = is_lazy((yyvsp[(1) - (2)].variable)) ? E_LAZY_INCRA : E_INCRA;
                        }
    break;

  case 193:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_variable = (yyvsp[(2) - (2)].variable);
                        (yyval.expression)->e_type = is_lazy((yyvsp[(2) - (2)].variable)) ? E_LAZY_INCRB : E_INCRB;
                        }
    break;

  case 194:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_variable = (yyvsp[(1) - (2)].variable);
                        (yyval.expression)->e_type = is_lazy((yyvsp[(1) - (2)].variable)) ? E_LAZY_DECRA : E_DECRA;
                        }
    break;

  case 195:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_variable = (yyvsp[(2) - (2)].variable);
                        (yyval.expression)->e_type = is_lazy((yyvsp[(2) - (2)].variable)) ? E_LAZY_DECRB : E_DECRB;
                        }
    break;

  case 196:

    {
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;

                        (yyval.expression) = NEW(T_EXPR);
                        if ((yyvsp[(2) - (2)].variable) && ((yyvsp[(2) - (2)].variable)->var_type == VAR_USER) || is_lazy((yyvsp[(2) - (2)].variable)))
                          yyerror("cannot take structure addresses",
                                   ERR_NONFATAL);

                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = (yyvsp[(2) - (2)].variable);

                        cp = NEW(T_FCALL);
                        cp->c_name = "address_of";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_ADDR_OF];
                        cp->c_args = ep;
                        cp->c_arg_count = 1;

                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = VAR_REGISTER;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        }
    break;

  case 197:

    {
                        T_VARIABLE *vp;
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;

                        vp = NEW(T_VARIABLE);
                        vp->var_type = (yyvsp[(2) - (3)].var_type);
                        if (vp->var_type == VAR_USER)
                          vp->var_struct = GET_STRUCT(type_name);
                        vp->var_initial = (yyvsp[(3) - (3)].expression);

                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = vp;

                        cp = NEW(T_FCALL);
                        cp->c_name = "new";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_NEW];
                        cp->c_args = ep;
                        cp->c_arg_count = 2;

                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = (yyvsp[(2) - (3)].var_type);
                        if ((yyvsp[(2) - (3)].var_type) == VAR_USER)
                          bp.bm_user_type = type_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        vp = cp->c_block->b_return;
                        if ((yyvsp[(2) - (3)].var_type) == VAR_USER) {
                          /* new will allocate this, free this version */
                          free_user_type(vp->var_un.var_user);
                          vp->var_un.var_user = 0;
                        }
                        /* note vp's array-ness for semantics */
                        vp->var_dimension = -1;
                        }
    break;

  case 198:

    {
                        T_VARIABLE *vp;
                        T_FCALL *cp;
                        T_EXPR *ep;
                        T_BMAP bp;
                        T_VARTYPE type;

                        vp = get_variable((yyvsp[(2) - (3)].string));
                        if (vp == 0) {
                          snprintf(error_buf, sizeof error_buf,
                            "undeclared variable: %s", (yyvsp[(2) - (3)].string));
                          yyerror(error_buf, ERR_NONFATAL);
                          type = VAR_BOGUS;
                        } else {
                          type = vp->var_type;
                          if (vp->var_dimension == 0)
                            yyerror("cannot renew non-array type",
                                     ERR_NONFATAL);
                          if ((vp->var_flags & VF_EMPTY) == 0)
                            yyerror("cannot renew non-dynamic array",
                                     ERR_NONFATAL);
                        }

                        /* build renew(variable, size) function call */

                        /* here's the variable arg */
                        ep = NEW(T_EXPR);
                        ep->e_type = E_VALUE;
                        ep->e_variable = vp;

                        /* here's the size arg */
                        ep->e_next = (yyvsp[(3) - (3)].expression);

                        /* here's the function call */
                        cp = NEW(T_FCALL);
                        cp->c_name = "renew";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_RENEW];
                        cp->c_args = ep;
                        cp->c_arg_count = 2;

                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = type;
                        if (type == VAR_USER)
                          bp.bm_user_type = vp->var_struct->st_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, ep, 1);
                        vp = cp->c_block->b_return;
                        if (type == VAR_USER) {
                          /* new will allocate this, free this version */
                          free_user_type(vp->var_un.var_user);
                          vp->var_un.var_user = 0;
                        }
                        /* note vp's array-ness for semantics */
                        vp->var_dimension = -1;
                        }
    break;

  case 199:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_ADD;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "+");
                        }
    break;

  case 200:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_SUBTRACT;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "-");
                        }
    break;

  case 201:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_MULTIPLY;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "*");
                        }
    break;

  case 202:

    {
                        if ((yyvsp[(3) - (3)].expression)->e_type == E_VALUE) {
                          T_VARIABLE *vp = (yyvsp[(3) - (3)].expression)->e_variable;
                          int byzero = 0;

                          if (vp && ((vp->var_type & VAR_NUMERIC) &&
                             (vp->var_name == 0))) {
                            switch(vp->var_type) {
                            case VAR_LONG:
                              byzero = (vp->var_un.var_udigit == 0);
                              break;
                            case VAR_DOUBLE:
                              byzero = (vp->var_un.var_rdigit == 0);
                              break;
                            }
                          }
                          if (byzero)
                            yyerror("division by zero", ERR_NONFATAL);
                        }
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_DIVIDE;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "/");
                        }
    break;

  case 203:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_MODULUS;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "%");
                        }
    break;

  case 204:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_BIT_AND;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "&");
                        }
    break;

  case 205:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_BIT_OR;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "|");
                        }
    break;

  case 206:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_BIT_XOR;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "^");
                        }
    break;

  case 207:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_SHIFT_LEFT;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), "<<");
                        }
    break;

  case 208:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(1) - (3)].expression);
                        (yyval.expression)->e_op = EO_SHIFT_RIGHT;
                        (yyval.expression)->e_right = (yyvsp[(3) - (3)].expression);
                        expr_clash_check((yyvsp[(1) - (3)].expression), (yyvsp[(3) - (3)].expression), ">>");
                        }
    break;

  case 209:

    {
                        T_FCALL *cp;
                        T_BMAP bp;
                        T_VARTYPE etype = type_value((yyvsp[(5) - (6)].expression));

                        if (Se_type_sizes[(yyvsp[(3) - (6)].var_type)] < 0)
                          yyerror("illegal type cast", ERR_NONFATAL);
                        else {
                          if (Se_type_sizes[(yyvsp[(3) - (6)].var_type)] != Se_type_sizes[etype]) {
                            if ((((yyvsp[(3) - (6)].var_type) & VAR_NUMERIC) &&
                                (type_value((yyvsp[(5) - (6)].expression)) & VAR_NUMERIC)) == 0) {
                              yyerror("invalid cast expression", ERR_NONFATAL);
                            }
                          }
                        }

                        cp = NEW(T_FCALL);
                        cp->c_name = "type_cast";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_TYPE_CAST];
                        cp->c_args = (yyvsp[(5) - (6)].expression);
                        cp->c_arg_count = 1;

                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = (yyvsp[(3) - (6)].var_type);
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, (yyval.expression), 1);
                        }
    break;

  case 210:

    {
                        T_FCALL *cp;
                        T_BMAP bp;

                        if (type_value((yyvsp[(7) - (8)].expression)) != VAR_REGISTER)
                          yyerror("indirection only on ulong types",
                                  ERR_NONFATAL);

                        cp = NEW(T_FCALL);
                        cp->c_name = "indirection";
                        cp->c_line_no = Lex_line_no;
                        cp->c_builtin = Se_functions[S_INDIRECT];
                        cp->c_args = (yyvsp[(7) - (8)].expression);
                        cp->c_arg_count = 1;

                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_CALL;
                        (yyval.expression)->e_call = cp;

                        /* spoof a builtin to build the return value */
                        bp.bm_name = cp->c_name;
                        bp.bm_stype = 0;
                        bp.bm_param_count = 1;
                        bp.bm_return_type = (yyvsp[(4) - (8)].var_type);
                        if ((yyvsp[(4) - (8)].var_type) == VAR_USER)
                          bp.bm_user_type = type_name;
                        bp.bm_check = 0;
                        do_builtin_check(&bp, 0, cp, (yyvsp[(7) - (8)].expression), 1);
                        }
    break;

  case 211:

    {
                        (yyval.expression) = NEW(T_EXPR);
                        (yyval.expression)->e_type = E_EXPRESSION;
                        (yyval.expression)->e_left = (yyvsp[(2) - (2)].expression);
                        (yyval.expression)->e_op = EO_BIT_NOT;
                        expr_clash_check((yyvsp[(2) - (2)].expression), 0, "~");
                        }
    break;



      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;

  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse lookahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse lookahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#if !defined(yyoverflow) || YYERROR_VERBOSE
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}





/*
 * exported functions
 */

void
se_parse_init(void)
{
  T_VARIABLE *vp;

  Se_symbol_table = avlinit();
  if (Se_symbol_table == 0)
    yyerror("cannot initialize parser", ERR_LATER);

  Se_type_sizes[VAR_STRING]    =  sizeof(char *);
  Se_type_sizes[VAR_CHAR]      =  sizeof(char);
  Se_type_sizes[VAR_UCHAR]     =  sizeof(unsigned char);
  Se_type_sizes[VAR_SHORT]     =  sizeof(short);
  Se_type_sizes[VAR_USHORT]    =  sizeof(unsigned short);
  Se_type_sizes[VAR_LONG]      =  sizeof(int);
  Se_type_sizes[VAR_ULONG]     =  sizeof(unsigned int);
  Se_type_sizes[VAR_LONGLONG]  =  sizeof(T_LLONG);
  Se_type_sizes[VAR_ULONGLONG] =  sizeof(T_ULLONG);
  Se_type_sizes[VAR_DOUBLE]    =  sizeof(double);
  Se_type_sizes[VAR_USER]      = -1;
  Se_type_sizes[VAR_ELLIPSIS]  =  sizeof(void *);
  Se_type_sizes[VAR_BOGUS]     = -2;

  vp = NEW(T_VARIABLE);
  vp->var_name = "stdin";
  vp->var_un.var_register = (T_REGISTER) stdin;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);

  vp = NEW(T_VARIABLE);
  vp->var_name = "stdout";
  vp->var_un.var_register = (T_REGISTER) stdout;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);

  vp = NEW(T_VARIABLE);
  vp->var_name = "stderr";
  vp->var_un.var_register = (T_REGISTER) stderr;
  vp->var_flags = VF_REFERENCED | VF_GENERATED;
  vp->var_type = VAR_REGISTER;
  put_symbol(SYM_VARIABLE, vp->var_name, vp, 0);
}

T_BLOCK *
se_get_block(char *name)
{
  return (T_BLOCK *) get_symbol(SYM_BLOCK, name);
}

static T_VARIABLE *
get_variable(char *name)
{
  T_VARIABLE *vp;

  if (in_local_scope) {
    for(vp=current_scope; vp; vp=vp->var_next)
      if (strcmp(vp->var_name, name) == 0)
        return vp;
    if (in_class_scope) {
      for(vp=class_scope; vp; vp=vp->var_next)
        if (strcmp(vp->var_name, name) == 0)
          return vp;
    }
  }
  return (T_VARIABLE *) GET_VARIABLE(name);
}

T_VARIABLE *
se_get_variable(char *name)
{
  return get_variable(name);
}

T_STRUCT *
se_get_struct(char *name)
{
  return (T_STRUCT *) get_symbol(SYM_STRUCT, name);
}


/*
 * list reversal functions
 */


static T_STATEMENT *
reverse_statement_list(T_STATEMENT *sp)
{
  T_STATEMENT *head = 0;
  T_STATEMENT *ssp;

  for(; sp; sp=ssp) {
    ssp = sp->s_next;
    sp->s_next = head;
    head = sp;
  }
  return head;
}

static T_EXPR *
reverse_arg_list(T_EXPR *ep)
{
  T_EXPR *head = 0;
  T_EXPR *eep;

  for(; ep; ep=eep) {
    eep = ep->e_next;
    ep->e_next = head;
    head = ep;
  }
  return head;
}

static T_VARIABLE *
reverse_member_list(T_VARIABLE *vp)
{
  T_VARIABLE *head = 0;
  T_VARIABLE *vvp;

  for(; vp; vp=vvp) {
    vvp = vp->var_next;
    vp->var_next = head;
    head = vp;
  }
  return head;
}

static T_CASE *
reverse_case_list(T_CASE *cp)
{
  T_CASE *head = 0;
  T_CASE *ccp;

  for(; cp; cp=ccp) {
    ccp = cp->ca_next;
    cp->ca_next = head;
    head = cp;
  }
  return head;
}


/*
 * symbol getting and putting
 */


static void *
get_symbol(T_SYMTYPE type, char *name)
{
  anode *anp = avlget(Se_symbol_table, name);
  T_SYMBOL *sp;

  if ((anp == 0) || (anp->an_data == 0))
    return 0;
  sp = (T_SYMBOL *) anp->an_data;
  if (sp->sym_type != type)
    return 0;
  return (void *) sp->sym_un.sym_block;
}

static void
put_symbol(T_SYMTYPE type, char *name, void *p, int allow_dups)
{
  int redeclared = 0;
  anode *anp;
  T_SYMBOL *sp;

  switch(avlinsert(Se_symbol_table, name, 0, &anp)) {
  case AVL_THERE:
    sp = (T_SYMBOL *) anp->an_data;
    if ((allow_dups == 0) && sp->sym_un.sym_block) {
      snprintf(error_buf, sizeof error_buf, "redeclaration of %s", name);
      yyerror(error_buf, ERR_NONFATAL);
      redeclared = 1;
      break;
    } /* else fall through */
  case AVL_INSERT:
    if (anp->an_data == 0) {
      sp = NEW(T_SYMBOL);
      sp->sym_type = type;
      anp->an_data = sp;
    }
    if ((redeclared == 0) && p)
      sp->sym_un.sym_block = (T_BLOCK *) p;
    break;
  case AVL_NOMEM:
    yyerror("out of memory", ERR_LATER);
    break;
  }
}

static void
add_special_name(char *name)
{
  T_NAME *tp;
  T_NAME *np = NEW(T_NAME);

  for(tp=name_list; tp; tp=tp->n_next)
    if (strcmp(tp->n_name, name) == 0) {
      snprintf(error_buf, sizeof error_buf,
        "redeclaration of special prefix: %s", name);
      yyerror(error_buf, ERR_NONFATAL);
    }
  np->n_name = name;
  np->n_next = name_list;
  name_list = np;
}

static T_NAME *
get_special_name(char *name)
{
  T_NAME *np;

  if (name == 0)
    return 0;
  for(np=name_list; np; np=np->n_next)
    if (strncmp(np->n_name, name, strlen(np->n_name)) == 0)
      return np;
  return 0;
}

static T_BMAP *
get_builtin(char *name)
{
  static avlhdr *builtin_tree;
  int i;
  int n;
  anode *anp;

  if (builtin_tree == 0) {
    builtin_tree = avlinit();
    if (builtin_tree == 0)
      yyerror("out of builtin_tree memory", ERR_FATAL);
    builtin_tree->ah_cmp = AVC_NONE;
    n = sizeof(builtins) / sizeof(T_BMAP);
    for(i=0; i<n; i++)
      if (avlinsert(builtin_tree, builtins[i].bm_name,
                   &builtins[i], &anp) == AVL_NOMEM)
        yyerror("out of builtin_tree node memory", ERR_FATAL);
  }
  anp = avlget(builtin_tree, name);
  if (anp == 0)
    return 0;
  return (T_BMAP *) anp->an_data;
}

/*
 * checking functions
 */


static int
check_symbol(anode *anp)
{
  T_SYMBOL *sp = (T_SYMBOL *) anp->an_data;
  T_BLOCK *bp;
  T_VARIABLE *vp;

  if (sp == 0)
    return 0;
  switch(sp->sym_type) {
  case SYM_BLOCK:
    bp = sp->sym_un.sym_block;
    if (bp == 0) {
      snprintf(error_buf, sizeof error_buf,
        "undeclared block: %s", anp->an_tag);
      yyerror(error_buf, ERR_NONFATAL);
    } else {
      for(vp=bp->b_variables; vp; vp=vp->var_next)
        if ((vp->var_flags & VF_REFERENCED) == 0) {
          snprintf(error_buf, sizeof error_buf,
            "variable: %s unused in block: %s", vp->var_name, bp->b_name);
          yyerror(error_buf, ERR_WARNING);
        }
    }
    break;
  case SYM_VARIABLE:
    vp = sp->sym_un.sym_variable;
    if (vp && ((vp->var_flags & (VF_REFERENCED|VF_EXTERN)) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "unused global variable: %s", vp->var_name);
      yyerror(error_buf, ERR_WARNING);
    }
    vp->var_flags |= VF_GLOBAL;
    for(vp=vp->var_instances; vp; vp=vp->var_next)
      vp->var_flags |= VF_GLOBAL;
    break;
  case SYM_STRUCT:
    break;
  }
  return 0;
}

/* hunt for blocks called but not declared */
static void
symbol_check(void)
{
  anode *anp;

  for(anp=avlfirst(Se_symbol_table); anp; anp=avlnext(Se_symbol_table, anp, 0))
    check_symbol(anp);
}

static T_VARTYPE
type_value(T_EXPR *ep)
{
  T_VARIABLE *vp;

  if (ep == 0)
    return VAR_BOGUS;

  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    vp = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      vp = ep->e_call->c_block->b_return;
    else
      return VAR_BOGUS;
    break;
  case E_ASSIGN:
    vp = ep->e_assign->a_variable;
    break;
  default:
    if (ep->e_right == 0)
      return type_value(ep->e_left);
    else
      return type_value(ep->e_left) | type_value(ep->e_right);
  }

  if (vp) {
    if (vp->var_dimension && (vp->var_subscript == 0))
      if (vp->var_type == VAR_CHAR)
        return VAR_STRING;
      else
        return VAR_BOGUS;
    else
      return vp->var_type;
  } else
    return VAR_BOGUS;
}

static int
integral_constant_expression(T_EXPR *ep, int allowed_types)
{
  T_VARIABLE *vp = 0;

  if (ep == 0)
    return 0;

  switch(ep->e_type) {
  case E_VALUE:
    vp = ep->e_variable;
    break;
  case E_CALL:
  case E_QCOP:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
  case E_ASSIGN:
    return 0;
  default:
    if (ep->e_right == 0)
      return integral_constant_expression(ep->e_left, allowed_types);
    else
      return integral_constant_expression(ep->e_left, allowed_types) &&
             integral_constant_expression(ep->e_right, allowed_types);
  }

  /* only E_VALUE here */
  if (vp == 0)
    return 0;

  return ((vp->var_name == 0) && (vp->var_type & allowed_types));
}

static void
expr_clash_check(T_EXPR *left, T_EXPR *right, char *op)
{
  T_VARTYPE left_value = type_value(left);
  T_VARTYPE right_value = (right ? type_value(right) : VAR_NUMERIC);

  switch(*op) {
  case '+':
  case '-':
  case '*':
  case '/':
    if (((left_value  & VAR_NUMERIC) == 0) ||
        ((right_value & VAR_NUMERIC) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "operands have incompatible types: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    break;
  case '%':
  case '&':
  case '|':
  case '^':
  case '<':
  case '>':
  case '~':
    if (((left_value  & VAR_NUMERIC) == 0) ||
        ((right_value & VAR_NUMERIC) == 0)) {
      snprintf(error_buf, sizeof error_buf,
        "operands have incompatible types: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    if ((left_value == VAR_DOUBLE) || (right_value == VAR_DOUBLE)) {
      snprintf(error_buf, sizeof error_buf,
        "operands must have integral type: op \"%s\"", op);
      yyerror(error_buf, ERR_NONFATAL);
    }
    break;
  default:
    /* ?: */
    break;
  }
}

static void
l_expr_clash_check(T_EXPR *left, T_EXPR *right, char *op)
{
  T_VARTYPE left_value = type_value(left);
  T_VARTYPE right_value = type_value(right);
  T_VARTYPE result_value = left_value | right_value;

  switch(result_value) {
  case VAR_USER:
    yyerror("structure comparisons not supported", ERR_NONFATAL);
    return;
  case VAR_STRING:
    return;
  default:
    if ((op[0] == '=') && (op[1] == '~'))
      yyerror("operands must be type string: op \"=~\"", ERR_NONFATAL);
    else
      /* if they're not both numeric then it's wrong */
      if (result_value & ~VAR_NUMERIC) {
        snprintf(error_buf, sizeof error_buf,
          "operands have incompatible types: op \"%s\"", op);
        yyerror(error_buf, ERR_NONFATAL);
      }
  }
}

static int
theres_an_array_in_the_family(T_VARIABLE *vp)
{
  T_VARIABLE *vvp;

  for(vvp=vp->var_parent; vvp; vvp=vvp->var_parent)
    if (vvp->var_dimension)
      return 1;
  return 0;
}

static T_VARIABLE *
do_dot_check(char *var_name, char *member_name, T_VARIABLE *vp, int *newed)
{
  T_VARIABLE *vvp;
  T_VARIABLE *xvp;

  if (vp->var_type != VAR_USER) {
    snprintf(error_buf, sizeof error_buf,
      "variable: %s is not a structure", var_name);
    yyerror(error_buf, ERR_NONFATAL);
    return 0;
  }
  if (vp->var_dimension) {
    if (vp->var_subscript == 0)
      yyerror("left operand of \".\" must be struct object", ERR_NONFATAL);

    /* even dynamic arrays will have at least one (see new_array()) */
    vvp = ((T_STRUCT **) vp->var_un.var_array)[0]->st_members;
  } else
    vvp = vp->var_un.var_user->st_members;
  for(; vvp; vvp=vvp->var_next) {
    if (strcmp(vvp->var_name, member_name) == 0) {
      vvp->var_parent = vp;
      if (theres_an_array_in_the_family(vvp)) {
        xvp = NEW(T_VARIABLE);
        *xvp = *vvp;
        xvp->var_next = vvp->var_instances;
        vvp->var_instances = xvp;
        if (newed)
          *newed = 1;
        return xvp;
      } else
        return vvp;
    }
  }
  snprintf(error_buf, sizeof error_buf, "invalid member name: %s", member_name);
  yyerror(error_buf, ERR_NONFATAL);
  return 0;
}

static T_VARIABLE *
do_array_check(char *var_name, T_EXPR *sub, T_VARIABLE *vp)
{
  int n;
  T_VARIABLE *vvp;

  /* is this an array? */
  if (vp->var_dimension == 0) {
    snprintf(error_buf, sizeof error_buf, "%s: %s is not an array",
      (vp->var_flags & VF_MEMBER) ? "member" : "variable", var_name);
    yyerror(error_buf, ERR_NONFATAL);
    return 0;
  }
  if ((type_value(sub) & VAR_INTEGRAL) == 0) {
    yyerror("invalid subscript type", ERR_NONFATAL);
    return 0;
  }
  /* see if it's subscripted with a constant and do a bounds check */
  if ((sub->e_type == E_VALUE) && (vp->var_dimension != -1)) {
    vvp = sub->e_variable;
    if (vvp->var_name == 0) {
      n = vvp->var_un.var_digit;
      if ((n < 0) || (n >= vp->var_dimension)) {
        snprintf(error_buf, sizeof error_buf,
          "subscript: %d out of range for: %s", n, vp->var_name);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
  }
  vp->var_subscript = sub;
  return vp;
}

static void
do_digit_checks(T_VARIABLE *vp, T_EXPR *ep)
{
  char c;
  short s;
  double d;
  int i;
  T_LLONG li;
  unsigned char uc;
  unsigned short us;
  unsigned int ui;
  T_ULLONG uli;
  T_VARIABLE *vvp = 0;

  /* make sure all constant values in the expression are the same type *
   * as the variable that the expression is being assigned to.         */

  switch(ep->e_type) {
  case E_EXPRESSION:
  case E_QCOP:
    do_digit_checks(vp, ep->e_left);
    if (ep->e_right)
      do_digit_checks(vp, ep->e_right);
    return;
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    /* variable/constant in question */
    vvp = ep->e_variable;
    break;
  case E_CALL:
  case E_ASSIGN:
    return;
  }

  /* not a constant or not a digit, return */
  if ((vvp == 0) || vvp->var_name || ((vvp->var_type & VAR_NUMERIC) == 0))
    return;

  /* the constant is stored as a VAR_CONSTANT or a VAR_DOUBLE. *
   * Grab it and make it what the variable is.                 */

  switch(vp->var_type) {
  case VAR_CHAR:
    c = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) c;
    vvp->var_type = vp->var_type;
    break;
  case VAR_UCHAR:
    uc = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (unsigned int) uc;
    vvp->var_type = vp->var_type;
    break;
  case VAR_SHORT:
    s = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) s;
    vvp->var_type = vp->var_type;
    break;
  case VAR_USHORT:
    us = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (unsigned int) us;
    vvp->var_type = vp->var_type;
    break;
  case VAR_LONG:
#ifdef _LP64
    li = vvp->var_un.var_register;
    vvp->var_un.var_digit = (int) li;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_ULONG:
#ifdef _LP64
    uli = vvp->var_un.var_register;
    vvp->var_un.var_udigit = (int) uli;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_LONGLONG:
#ifndef _LP64
    i = vvp->var_un.var_register;
    vvp->var_un.var_ldigit = (T_LLONG) i;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_ULONGLONG:
#ifndef _LP64
    ui = vvp->var_un.var_register;
    vvp->var_un.var_ldigit = (T_ULLONG) ui;
    vvp->var_type = vp->var_type;
#endif
    break;
  case VAR_DOUBLE:
    if (vvp->var_type != VAR_DOUBLE) {
      d = (double) vvp->var_un.var_register;
      vvp->var_un.var_rdigit = d;
      vvp->var_type = vp->var_type;
    }
    break;
  }
}

static int
r_integrals(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  /* if neither is a digit, then this check doesn't care */
  if (((left->var_type & VAR_NUMERIC) == 0) &&
      ((right->var_type & VAR_NUMERIC) == 0))
    return 0;

  /* if either is an array then the array checker will check */
  if ((left->var_dimension && (left->var_subscript == 0)) ||
      (right->var_dimension && (right->var_subscript == 0)))
    return 0;

  /* if both are numeric then it's ok */
  if ((left->var_type & VAR_NUMERIC) && (right->var_type & VAR_NUMERIC)) {

#if ANYONE_REALLY_CARED

    /* if right is bigger (and isn't a constant, since constants are LONGLONG)
       than left then there's precision loss */
    if (right->var_name && right->var_type > left->var_type) {
      if (arg)
        snprintf(error_buf, sizeof error_buf,
          "possible loss of precision in call: arg #%d: %s", arg, fn);
      else
        snprintf(error_buf, sizeof error_buf,
          "possible loss of precision in %s", fn);
      yyerror(error_buf, ERR_WARNING);
    }

#endif

    return 0;
  }

  /* one is, the other isn't. wrong. */
  return 1;
}

static int
r_arrays(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  int left_is_array = (left->var_dimension != 0) && (left->var_subscript == 0);
  int left_is_dynamic = left->var_dimension == -1;
  int right_is_array =
    (right->var_dimension != 0) && (right->var_subscript == 0);
  int right_is_dynamic = right->var_dimension == -1;

  /* neither is an array, this check doesn't care */
  if (!left_is_array && !right_is_array)
    return 0;

  /* if left is array and right is not, then it must be strings */
  if (left_is_array && !right_is_array)
    if ((left->var_type == VAR_CHAR) && (right->var_type == VAR_STRING))
      return 0;
    else
      return 1;

  /* if right is array and left is not, then it must be strings */
  if (!left_is_array && right_is_array)
    if ((left->var_type == VAR_STRING) && (right->var_type == VAR_CHAR))
      return 0;
    else
      return 1;

  /* ok, they're both arrays */

  /* they must be the same type */
  if (left->var_type != right->var_type)
    return 1;

  /* both are not dynamic and the right is bigger than the left */
  if (!left_is_dynamic && !right_is_dynamic)
    if (right->var_dimension > left->var_dimension)
      return 1;

  return 0;
}

static int
r_users(T_VARIABLE *left, T_VARIABLE *right, char *fn, int arg)
{
  /* only checking user types here */
  if ((left->var_type != VAR_USER) && (right->var_type != VAR_USER))
    return 0;

  if ((left->var_type | right->var_type) != VAR_USER)
    return 1;

  return strcmp(left->var_struct->st_name, right->var_struct->st_name);
}

static void 
do_assign_check(T_VARIABLE *left, T_EXPR *ep, char *fn, int arg)
{
  T_VARIABLE *right = 0;
  T_VARIABLE var;
  static int (*rule_list[])(T_VARIABLE *, T_VARIABLE *, char *, int) = {
    r_integrals,  /* can't assign integral to non-integral, and vice-versa */
    r_arrays,     /* can't assign array to non-array, and vice-versa       */
    r_users,      /* can't assign user defined types of different types    */
    0
  };
  int (**rule)(T_VARIABLE *, T_VARIABLE *, char *, int);

  if (left == 0)
    goto clash;

  if (left->var_type == VAR_ELLIPSIS)
    return;

  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    right = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      right = ep->e_call->c_block->b_return;
    break;
  case E_EXPRESSION:
  case E_QCOP:
    var = zero_variable;
    var.var_type = type_value(ep);
    if ((var.var_type & (VAR_USER | VAR_BOGUS)) == 0)
      right = &var;
    break;
  case E_ASSIGN:
    right = ep->e_assign->a_variable;
    break;
  }
  if (right == 0)
    goto clash;

  /* if a kvm var is assigned to, then we need write access to kvm */
  if ((left->var_flags & VF_SPECIAL) == VF_KVM)
    Se_kvm_open_flags = O_RDWR;

  /* for each rule */
  for(rule=rule_list; *rule; rule++)
    if ((*(*rule))(left, right, fn, arg))
      goto clash;

  /* make numeric constants in the expression be of the same type */
  if ((left->var_type & VAR_NUMERIC) && ep)
    do_digit_checks(left, ep);

  return;

clash:
  if (arg)
    snprintf(error_buf, sizeof error_buf,
      "argument type mismatch: arg #%d: %s", arg, fn);
  else
    snprintf(error_buf, sizeof error_buf, "%s type mismatch", fn);
  yyerror(error_buf, ERR_NONFATAL);
}

#if it_wasnt_fucking_broken

/* for notification of errors */
#define KVM_TOLDEM       1
#define KSTAT_TOLDEM     2
#define MIB_TOLDEM       4

static void 
do_assign_check(T_VARIABLE *left, T_EXPR *ep, char *fn, int arg)
{
  int done = 0;
  int clash = 0;
  static int told_em = 0;
  T_VARIABLE *right = 0;
  T_VARIABLE var;

  if (left == 0)
    clash = 1;
  else if (left->var_type == VAR_ELLIPSIS)
    return;
  switch(ep->e_type) {
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    right = ep->e_variable;
    break;
  case E_CALL:
    if (ep->e_call->c_block)
      right = ep->e_call->c_block->b_return;
    break;
  case E_EXPRESSION:
  case E_QCOP:
    var = zero_variable;
    var.var_type = type_value(ep);
    if ((var.var_type & (VAR_USER | VAR_BOGUS)) == 0)
      right = &var;
    break;
  case E_ASSIGN:
    right = ep->e_assign->a_variable;
    break;
  }
  if (right == 0)
    clash = 1;

  /* do special variable checking */
  if (clash == 0) {
    switch(left->var_flags & VF_SPECIAL) {
    case VF_KVM:
#if CHECK_ACCESS_DURING_PARSE
      if (((told_em & KVM_TOLDEM) == 0) &&
          ((Se_flags & SE_SYNTAX) == 0) &&
          ((getegid() != 3) && (geteuid() != 0))) {
        yyerror("insufficient privilege to modify kvm variables", ERR_NONFATAL);
        told_em |= KVM_TOLDEM;
      }
#endif
      Se_kvm_open_flags = O_RDWR;
      break;
    case VF_KSTAT:
#if CHECK_ACCESS_DURING_PARSE
      if (strcmp(left->var_name, NAME_NAME) &&
          strcmp(left->var_name, NUMBER_NAME) &&
         ((told_em & KSTAT_TOLDEM) == 0) &&
         ((Se_flags & SE_SYNTAX) == 0) &&
         (geteuid() != 0)) {
        yyerror("must be super-user to modify kstat variables", ERR_NONFATAL);
        told_em |= KSTAT_TOLDEM;
      }
#endif
      break;
    case VF_MIB:
#if CHECK_ACCESS_DURING_PARSE
      if (((told_em & MIB_TOLDEM) == 0) && ((Se_flags & SE_SYNTAX) == 0)) {
        yyerror("mib variables are read-only", ERR_WARNING);
        told_em |= MIB_TOLDEM;
      }
#endif
      break;
    default:
      break;
    }
  }

  if (clash == 0) {
    /* if left is an array then */
    if (left->var_dimension && (left->var_subscript == 0)) {
      switch(left->var_type) {
      case VAR_CHAR:
        /* left side is a character array */
        switch(right->var_type) {
        case VAR_STRING:
          /* if right is a constant then */
          if (right->var_name == 0)
            /* but right is not a function call or the value "nil" */
            if ((ep->e_type != E_CALL) && right->var_un.var_string)
              /* if the length of the constant is > the size of left then */
              if (strlen(right->var_un.var_string) >
                  (size_t) left->var_dimension)
                clash = 1;
          done = 1;
          break;
        default:
          /* if left size is not equal to right size then */
          if (((left->var_dimension != right->var_dimension) &&
               (left->var_dimension != -1) && (right->var_dimension != -1)) ||
              (left->var_subscript && (right->var_subscript == 0)) ||
             ((left->var_subscript == 0) && right->var_subscript))
            clash = 1;
          break;
        }
        break;
      default:
        /* if left size is not equal to right size then */
        if (((left->var_dimension != right->var_dimension) &&
             (left->var_dimension != -1) && (right->var_dimension != -1)) ||
            (left->var_subscript && (right->var_subscript == 0)) ||
           ((left->var_subscript == 0) && right->var_subscript))
          clash = 1;
        break;
      }
    /* if the left is a string */
    } else if (left->var_type == VAR_STRING) {
      switch(right->var_type) {
      case VAR_CHAR:
        /* if the right is not an array then */
        if ((right->var_dimension == 0) || right->var_subscript)
          clash = 1;
        done = 1;
        break;
      case VAR_STRING:
        /* if the right is an array then */
        if (right->var_dimension && (right->var_subscript == 0))
          clash = 1;
        done = 1;
        break;
      default:
        clash = 1;
        break;
      }
    /* if the right is an array then */
    } else if (right->var_dimension && (right->var_subscript == 0)) {
      switch(right->var_type) {
      case VAR_CHAR:
        switch(left->var_type) {
        case VAR_STRING:
          done = 1;
          break;
        default:
          clash = 1;
          break;
        }
        break;
      default:
        /* if left is array and right is not or left is not and right is... */
        if ((left->var_dimension && (right->var_dimension == 0)) ||
           ((left->var_dimension == 0) && right->var_dimension))
          clash = 1;

        if (((left->var_dimension != right->var_dimension) &&
             (left->var_dimension != -1) && (right->var_dimension != -1)) ||
            (left->var_subscript && (right->var_subscript == 0)) ||
           ((left->var_subscript == 0) && right->var_subscript))
          clash = 1;
        break;
      }
    }
  }

  if ((clash == 0) && (done == 0)) {
    if (left->var_type & VAR_NUMERIC) {
      if (ep) {
        do_digit_checks(left, ep);
        if ((right->var_type & VAR_NUMERIC) == 0)
          clash = 1;
      }
    } else if (left->var_type == VAR_USER) {
      if (right->var_type != VAR_USER)
        clash = 1;
      else if (strcmp(left->var_struct->st_name, right->var_struct->st_name))
        clash = 1;
    }
  }

  if (clash) {
    if (arg)
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: %s", arg, fn);
    else
      snprintf(error_buf, sizeof error_buf, "%s type mismatch", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
}

#endif

static void
do_switch_check(T_SWITCH *sp)
{
  char *p;
  T_VARTYPE switch_type;
  T_VARTYPE case_type;
  T_CASE *cp;
  T_CASE *ccp;
  T_CASE *default_case = 0;
  T_STATEMENT *stp;
  T_BREAK *bp;
  avlhdr *cases;
  anode *anp;

  switch_type = type_value(sp->sw_expr);
  if (switch_type & (VAR_DOUBLE|VAR_USER)) {
    yyerror("non-integral switch expression", ERR_NONFATAL);
    return;
  }
#ifndef _LP64
  if (switch_type & (VAR_LONGLONG|VAR_ULONGLONG)) {
    yyerror("switching on longlong or ulonglong not supported", ERR_NONFATAL);
    return;
  }
#endif

  /* link breaks back to the switch statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_SWITCH;
    bp->brk_un.brk_switch = sp;
  }

  cases = avlinit();
  if (cases == 0)
    yyerror("out of memory", ERR_FATAL);

  /* either string or int */
  if (switch_type != VAR_STRING)
    cases->ah_cmp = AVC_INT;

  for(cp=sp->sw_case_list; cp; cp=cp->ca_next) {
    /* not the default case */
    if (cp->ca_value) {
      /* the case type can only be VAR_STRING, VAR_CONSTANT, or VAR_DOUBLE */
      case_type = cp->ca_value->var_type;
      if (case_type == VAR_DOUBLE) {
        case_error(cp, "non-integral case expression");
        continue;
      }
      /* we're down to VAR_STRING and VAR_CONSTANT */
      if (case_type == VAR_CONSTANT) {
        if ((switch_type & VAR_INTEGRAL) == 0) {
          case_error(cp, "switch/case type mismatch");
          continue;
        }
      } else {
        if (switch_type != VAR_STRING) {
          case_error(cp, "switch/case type mismatch");
          continue;
        }
      }
    } else {
      if (default_case == 0)
        default_case = cp;
      else
        case_error(cp, "duplicate default in switch");
    }
  }

  /* for each case statement */
  for(cp=sp->sw_case_list; cp; cp=cp->ca_next) {

    if (cp->ca_statements)
      /* mark it as having statements */
      cp->ca_flags |= CA_STATEMENTS;

    /* find the first case that has statements */
    for(ccp=cp->ca_next; ccp; ccp=ccp->ca_next) {
      if (ccp->ca_statements) {

        /* if the source case has statements */
        if (cp->ca_statements) {


          /* find the last statement */
          for(stp=cp->ca_statements; stp->s_next; stp=stp->s_next)
            ;

          /* and link it to the target case's statements */
          stp->s_next = ccp->ca_statements;

        } else {  /* otherwise, make the target's statements the sources's */
          cp->ca_statements = ccp->ca_statements;
        }
        break;   /* found the case with statements, stop searching */
      }
    }

    /* put statement lists into case tree for non-default cases */
    if (cp->ca_value) {
      p = cp->ca_value->var_un.var_string;
      if ((switch_type == VAR_STRING) && (p == 0))
        p = NIL_VALUE;
      switch(avlinsert(cases, p, cp->ca_statements, &anp)) {
      case AVL_INSERT:
        break;
      case AVL_THERE:
        case_error(cp, "duplicate case in switch");
        continue;
      case AVL_NOMEM:
        yyerror("out of memory", ERR_FATAL);
        break;
      }
    }
  }

  sp->sw_cases = cases;
  sp->sw_default = default_case;
}

static void
do_for_check(T_FOR *fp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the for statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_FOR;
    bp->brk_un.brk_for = fp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_FOR;
    cp->con_un.con_for = fp;
  }
}

static void
do_do_check(T_DO *dp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the while statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_DO;
    bp->brk_un.brk_do = dp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_DO;
    cp->con_un.con_do = dp;
  }
}

static void
do_while_check(T_WHILE *wp)
{
  T_BREAK *bp;
  T_CONTINUE *cp;

  /* link breaks back to the while statement */
  for(bp=break_list; bp; bp=bp->brk_next) {
    bp->brk_type = BRK_WHILE;
    bp->brk_un.brk_while = wp;
  }
  for(cp=continue_list; cp; cp=cp->con_next) {
    cp->con_type = CON_WHILE;
    cp->con_un.con_while = wp;
  }
}

static void 
do_special_check(char *name, T_VARIABLE *vp)
{
  static int told_em = 0;
  char *p;

  if (strncmp(name, KVM_PREFIX, KVM_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_KVM;
    Se_kvm_var_count++;
    member_inherit(vp, VF_KVM);
#if CHECK_ACCESS_DURING_PARSE
    if ((told_em == 0) && ((Se_flags & SE_SYNTAX) == 0) &&
        (getegid() != 3) && (geteuid() != 0)) {
      yyerror("insufficient privilege to access kvm variables", ERR_NONFATAL);
      told_em = 1;
    }
#endif
    Se_kvm_open_flags = O_RDONLY;
  } else if (strncmp(name, KSTAT_PREFIX, KSTAT_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_KSTAT;
    Se_kstat_var_count++;
    member_inherit(vp, VF_KSTAT);
  } else if (strncmp(name, MIB_PREFIX, MIB_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_MIB;
    Se_mib_var_count++;
    member_inherit(vp, VF_MIB);
  } else if (strncmp(name, NDD_PREFIX, NDD_PREFIX_LEN) == 0) {
    vp->var_flags |= VF_NDD;
    member_inherit(vp, VF_NDD);
  } else if (get_special_name(name)) {
    if (vp->var_struct && vp->var_struct->st_class) {
      p = vp->var_struct->st_class->b_name;
      if (strncmp(name, p, strlen(p))) {
        snprintf(error_buf, sizeof error_buf,
          "incorrect special class prefix for class %s, use %s",
                vp->var_struct->st_name, p);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
    vp->var_flags |= VF_CLASS;
    member_inherit(vp, VF_CLASS);
  } else
    member_inherit(vp, (T_VFTYPE) 0);
}

/* We compute the offsets for this structure only here.  The offsets for  *
 * members inside of structures that may be the members of this structure *
 * are computed elsewhere.                                                */

static void 
do_structure_check(T_STRUCT *sp)
{
  T_VARIABLE *vp;
  T_VARIABLE *vvp;
  int size = 0;
  int m;
  int n;
  int do_pad = 0;

  /* assign offsets and compute structure size */
  for (vp = sp->st_members; vp; vp = vp->var_next) {
    n = Se_type_sizes[vp->var_type];
    if (n == -1) {
      /* this member is a structure, pad offset to register size */
      if (size % sizeof(T_REGISTER))
        size += (sizeof(T_REGISTER) - (size % sizeof(T_REGISTER)));
      n = vp->var_struct->st_size;
      for(vvp=vp->var_struct->st_members; vvp; vvp=vvp->var_next) {
        /* hunt through the structure and see if it has anything in it other *
         * than a char type.  If it does, it gets padded.                    */
        if (vvp->var_type != VAR_USER) {
          if ((m = Se_type_sizes[vvp->var_type]) > 1) {
            if (size % m)
              size += (m - (size % m));
            do_pad = 1;
          }
          break;
        }
      }
    } else {
      if (n > 1) {
        if (size % n)
          size += (n - (size % n));
        do_pad = 1;
      }
    }
    if (vp->var_dimension)
      n *= vp->var_dimension;
    vp->var_offset = size;
    vp->var_flags |= VF_MEMBER;
    size += n;
  }
  if ((do_pad) && (size % sizeof(T_REGISTER)))
    size += (sizeof(T_REGISTER) - (size % sizeof(T_REGISTER)));
  sp->st_size = size;
}

static void
do_member_check(T_VARIABLE *left, T_VARIABLE *right)
{
  void *array;
  int i;
  int n;
  T_VARIABLE *rp;
  T_VARIABLE subv;
  T_EXPR sub;
  T_EXPR e;

  if (left->var_type == VAR_USER) {
    do_aggregate_check(left, right);
    return;
  }
  /* array of simple types */
  if (left->var_dimension) {
    switch(right->var_type) {
    case VAR_USER:
      break;
    case VAR_STRING:
      /* char hello[6] = "hello"; */
      if (left->var_type == VAR_CHAR) {
        if (right->var_un.var_string == 0) {
          yyerror("illegal initializer", ERR_NONFATAL);
          return;
        }
        if (strlen(right->var_un.var_string) > (size_t) left->var_dimension) {
          yyerror("initializer does not fit", ERR_NONFATAL);
          return;
        }
        goto exceptional_case;
      }
      /* else fall through */
    default:
      yyerror("initialization type mismatch", ERR_NONFATAL);
      return;
    }
    /* dummy subscript constant */
    subv = zero_variable;
    subv.var_type = VAR_LONG;

    /* dummy subscript expression */
    sub = zero_expr;
    sub.e_type = E_VALUE;
    sub.e_variable = &subv;

    /* set it up */
    left->var_subscript = &sub;

    /* dummy expression */
    e = zero_expr;
    e.e_type = E_VALUE;

    /* members of aggregate */
    rp = right->var_struct->st_members;

    /* aggregate assignment to not-yet-new'ed var */
    if (left->var_dimension == -1) {
      T_VARIABLE *xp;

      for(n=0, xp=rp; xp; xp=xp->var_next, n++)
        ;
    } else
      n = left->var_dimension;
    for(i=0; (i<n) && rp; rp=rp->var_next, i++) {
      subv.var_un.var_digit = i;
      e.e_variable = rp;
      do_assign_check(left, &e, "initialization", 0);
      if (Se_errors == 0)
        se_run_assign(left, &e);
    }
    /* return to normal */
    left->var_subscript = 0;

    if (rp)
      yyerror("too many array initializers", ERR_NONFATAL);

    return;
  }

exceptional_case:

  /* dummy expression */
  e = zero_expr;
  e.e_type = E_VALUE;
  e.e_variable = right;
  do_assign_check(left, &e, "initialization", 0);
  if (Se_errors == 0)
    se_run_assign(left, &e);
}

static void
do_aggregate_check(T_VARIABLE *left, T_VARIABLE *right)
{
  int i;
  T_STRUCT **lpp;
  T_VARIABLE *rpp;
  T_VARIABLE *lp;
  T_VARIABLE *rp;

  /* an array of simple types */
  if (left->var_type != VAR_USER) {
    do_member_check(left, right);
    return;
  }
  /* an array of structures */
  if (left->var_dimension) {
    lpp = (T_STRUCT **) left->var_un.var_array;
    rpp = right->var_struct->st_members;
    if (rpp->var_type != VAR_USER) {
      yyerror("initialization type mismatch", ERR_NONFATAL);
      return;
    }
    for(i=0; (i<left->var_dimension) && rpp; i++, rpp=rpp->var_next) {
      lp = lpp[i]->st_members;
      rp = rpp->var_struct->st_members;
      for(; lp && rp; lp=lp->var_next, rp=rp->var_next)
        do_member_check(lp, rp);
    }
    if (rpp)
      yyerror("too many struct initializers", ERR_NONFATAL);
    return;
  }
  lp = left->var_un.var_user->st_members;
  rp = right->var_struct->st_members;
  for(; lp && rp; lp=lp->var_next, rp=rp->var_next)
    do_member_check(lp, rp);
}

static void
free_aggregate(T_VARIABLE *vp)
{
  T_VARIABLE *xp;
  T_VARIABLE *next;

  if (vp->var_type != VAR_USER)
    return;
  se_free(vp->var_name);
  for(xp=vp->var_struct->st_members; xp; xp=next) {
    next = xp->var_next;
    switch(xp->var_type) {
    case VAR_STRING:
      se_free(xp->var_un.var_string);
      break;
    case VAR_USER:
      free_aggregate(xp);
      continue; /* xp already free from recursive call */
    default:
      break;
    }
    se_free(xp);
  }
  se_free(vp);
}

static void
do_param_check(T_FCALL *cp)
{
  int i;
  int n;
  int ellipsis = 0;
  T_VARIABLE *vp;
  T_EXPR *ep;

  n = Lex_line_no;
  for(vp=cp->c_block->b_parameters; vp && vp->var_next; vp=vp->var_next)
    ;
  if (vp && (vp->var_type == VAR_ELLIPSIS))
    ellipsis = 1;
  Lex_line_no = cp->c_line_no;
  if ((ellipsis == 0) && (cp->c_arg_count != cp->c_block->b_param_count)) {
    snprintf(error_buf, sizeof error_buf,
      "function: %s expects %d parameter%s, %d sent",
      cp->c_name, cp->c_block->b_param_count,
      (cp->c_block->b_param_count != 1) ? "s" : "", cp->c_arg_count);
    yyerror(error_buf, ERR_NONFATAL);
    Lex_line_no = n;
    return;
  }
  vp = cp->c_block->b_parameters;
  ep = cp->c_args;
  for(i=1; ep && vp; vp=vp->var_next, ep=ep->e_next, i++)
    do_assign_check(vp, ep, cp->c_name, i);
  Lex_line_no = n;
}

static void
do_main_check(T_BLOCK *bp)
{
  T_VARIABLE *vp = bp->b_parameters;
  int error = 0;

  if (vp) {
    if ((vp->var_type != VAR_LONG) || vp->var_dimension)
      error = 1;
    else {
      vp = vp->var_next;
      if (vp && ((vp->var_type != VAR_STRING) || (vp->var_dimension == 0)))
        error = 2;
      if (vp->var_next)
        yyerror("function: main accepts only 2 parameters\n", ERR_WARNING);
    }
    if (error) {
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: main", error);
      yyerror(error_buf, ERR_NONFATAL);
    }
  }
  if (bp->b_return && bp->b_return->var_type != VAR_LONG)
    yyerror("main must have a return type of int", ERR_NONFATAL);
}

static void
do_return_check(T_VARIABLE *vp, T_RETURN *rp)
{
  int n;

  n = Lex_line_no;
  Lex_line_no = rp->ret_line_no;
  if (rp->ret_expr == 0) {
    snprintf(error_buf, sizeof error_buf,
      "function expects to return value: %s",
            rp->ret_block->b_name);
    yyerror(error_buf, ERR_NONFATAL);
  } else
    do_assign_check(vp, rp->ret_expr, "return value", 0);
  Lex_line_no = n;
}

static void
do_long_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_REGISTER;
  do_assign_check(&var, args, fn, arg);
}

static void
do_int_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_LONG;
  do_assign_check(&var, args, fn, arg);
}

static void
do_dbl_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_DOUBLE;
  do_assign_check(&var, args, fn, arg);
}

static void
do_long_check(char *fn, T_EXPR *args)
{
  do_long_arg_check(fn, args, 1);
}

static void
do_dbl_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
}

static void
do_2dbl_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
  if (args->e_next)
    do_dbl_arg_check(fn, args->e_next, 2);
}

static void
do_dbl_long_check(char *fn, T_EXPR *args)
{
  do_dbl_arg_check(fn, args, 1);
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_long_dbl_check(char *fn, T_EXPR *args)
{
  do_long_arg_check(fn, args, 1);
  if (args->e_next)
    do_dbl_arg_check(fn, args->e_next, 2);
}

static void
do_string_arg_check(char *fn, T_EXPR *args, int arg)
{
  T_VARIABLE var;

  if (args == 0)
    return;
  var = zero_variable;
  var.var_type = VAR_STRING;
  do_assign_check(&var, args, fn, arg);
}

static void
do_string_check(char *fn, T_EXPR *args)
{
  do_string_arg_check(fn, args, 1);
}

static void
do_refresh_check(char *fn, T_EXPR *args)
{
  int flags;
  T_VARIABLE *vp;

  /* must be a variable and not a constant */
  if ((args->e_type != E_VALUE) || (args->e_variable == 0)) {
    yyerror("argument type mismatch: arg #1: refresh$", ERR_NONFATAL);
    return;
  }
  vp = args->e_variable;
  if ((vp->var_type == VAR_USER) &&
      (vp->var_un.var_user->st_class != 0) &&
      (vp->var_dimension != 0)) {
    yyerror("arrays of active class variables not allowed", ERR_NONFATAL);
    return;
  }
  if (vp->var_special == SS_KVM) {
    Se_kvm_var_count++;
    return;
  }

  /* if it's not kvm, then it's a structure. */
  flags = (int) (vp->var_struct->st_flags & (SF_KSTAT|SF_MIB|SF_NDD));
  switch(flags) {
  case SF_KSTAT:
    Se_kstat_var_count++;
    vp->var_special = SS_KSTAT;
    break;
  case SF_NDD:
    vp->var_special = SS_NDD;
    break;
  case SF_MIB:
    vp->var_special = SS_MIB;
    Se_mib_var_count++;
    break;
  default:
    break;
  }
}

static void
do_printf_check(char *fn, T_EXPR *args)
{
  int i;
  T_VARIABLE *vp;
  T_VARIABLE var;
  T_EXPR *ep;

  if (args == 0)
    return;

  var = zero_variable;
  var.var_type = VAR_STRING;
  do_assign_check(&var, args, fn, 1);

  /* check the other args for nonsense */
  for(i=1, ep=args->e_next; ep; ep=ep->e_next, i++) {
    switch(ep->e_type) {
    case E_VALUE:
    case E_INCRA:
    case E_INCRB:
    case E_DECRA:
    case E_DECRB:
    case E_LAZY_INCRA:
    case E_LAZY_INCRB:
    case E_LAZY_DECRA:
    case E_LAZY_DECRB:
      vp = ep->e_variable;
      break;
    case E_QCOP:
      var.var_type = type_value(ep->e_left);
      vp = &var;
      break;
    case E_CALL:
      if (ep->e_call->c_block)
        vp = ep->e_call->c_block->b_return;
      else
        vp = 0;
      break;
    case E_ASSIGN:
      vp = ep->e_assign->a_variable;
      break;
    default:
      continue;
    }
    if ((vp == 0) || ((vp->var_type == VAR_USER) ||
                      (vp->var_dimension &&
                      (vp->var_subscript == 0) && vp->var_type != VAR_CHAR))) {
      snprintf(error_buf, sizeof error_buf,
        "argument type mismatch: arg #%d: %s", i+1, fn);
      yyerror(error_buf, ERR_NONFATAL);
    }
  }
}

static void
do_qsort_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args) {
    do_long_arg_check(fn, args, 2);
    args = args->e_next;
    if (args) {
      do_long_arg_check(fn, args, 3);
      args = args->e_next;
      if (args)
        do_string_arg_check(fn, args, 4);
    }
  }
}

static void
do_bsearch_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args) {
    do_long_arg_check(fn, args, 2);
    args = args->e_next;
    if (args) {
      do_long_arg_check(fn, args, 3);
      args = args->e_next;
      if (args) {
        do_long_arg_check(fn, args, 4);
        args = args->e_next;
        if (args)
          do_string_arg_check(fn, args, 5);
      }
    }
  }
}

static void
do_fprintf_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  if (args->e_next == 0) {
    snprintf(error_buf, sizeof error_buf, "insufficent arguments to %s", fn);
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  do_printf_check(fn, args->e_next);
}

static void
do_syslog_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_int_arg_check(fn, args, 1);
  if (args->e_next == 0) {
    snprintf(error_buf, sizeof error_buf, "insufficent arguments to %s", fn);
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  do_printf_check(fn, args->e_next);
}

static void
do_signal_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  do_long_arg_check(fn, args, 1);
  args = args->e_next;
  if (args)
    do_string_arg_check(fn, args, 2);
}

static void
do_sizeof_check (char *fn, T_EXPR *args)
{
  T_VARIABLE var;
  T_BLOCK *bp;

  if (args == 0)
    return;
  switch(args->e_type) {
  case E_CALL:
    bp = args->e_call->c_block;
    if ((bp == 0) || (bp->b_return == 0)) {
      yyerror("cannot take sizeof void", ERR_NONFATAL);
      return;
    }
    break;
  case E_VALUE:
  case E_INCRA:
  case E_INCRB:
  case E_DECRA:
  case E_DECRB:
  case E_LAZY_INCRA:
  case E_LAZY_INCRB:
  case E_LAZY_DECRA:
  case E_LAZY_DECRB:
    if (args->e_variable && (Se_type_sizes[args->e_variable->var_type] == -2))
      yyerror("internal error", ERR_FATAL);
    break;
  case E_EXPRESSION:
  case E_QCOP:
  case E_ASSIGN:
    /* it's silly, but hey */
    break;
  }
}

static void
do_kvm_cvt_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_name == 0) ||
      (strncmp(args->e_variable->var_name, KVM_PREFIX, KVM_PREFIX_LEN) &&
      (args->e_variable->var_special != SS_KVM))) {
    snprintf(error_buf, sizeof error_buf,
      "%s must take kvm variable as arg #1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_kvm_addr_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_name == 0) ||
      (strncmp(args->e_variable->var_name, KVM_PREFIX, KVM_PREFIX_LEN) &&
      (args->e_variable->var_special != SS_KVM))) {
    snprintf(error_buf, sizeof error_buf,
      "%s must take kvm variable as arg #1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
}

static void
do_str_fill_check(char *fn, T_EXPR *args)
{
  if (args == 0)
    return;
  if ((args->e_type != E_VALUE) ||
      (args->e_variable == 0) ||
      (args->e_variable->var_type != VAR_USER)) {
    snprintf(error_buf, sizeof error_buf,
      "%s requires a struct variable as arg# 1", fn);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (args->e_next)
    do_long_arg_check(fn, args->e_next, 2);
}

static void
do_builtin_check(T_BMAP *bp, T_VARIABLE *vp, T_FCALL *cp, T_EXPR *ep, int sent)
{
  T_STRUCT *sp;
  T_VARIABLE var;
  int n = bp->bm_param_count;

  if ((n != -1) && (n != sent)) {
    snprintf(error_buf, sizeof error_buf,
      "builtin: %s expects %d parameter%s, %d sent",
      bp->bm_name, bp->bm_param_count, (n != 1) ? "s" : "", sent);
    yyerror(error_buf, ERR_NONFATAL);
  }
  if (bp->bm_return_type) {
    cp->c_block = NEW(T_BLOCK);
    if (bp->bm_return_type == VAR_USER) {
      sp = (T_STRUCT *) get_symbol(SYM_STRUCT, bp->bm_user_type);
      if (sp == 0) {
        snprintf(error_buf, sizeof error_buf,
          "undefined user type: struct %s", bp->bm_user_type);
        yyerror(error_buf, ERR_NONFATAL);
      } else if (vp) {
        /* prototype passed in, possibly lazy value of array of structs */
        cp->c_block->b_return = new_variable(vp);
      } else {
        var = zero_variable;
        var.var_type = VAR_USER;
        var.var_struct = sp;
        cp->c_block->b_return = new_variable(&var);
      }
      fix_offsets(cp->c_block->b_return->var_un.var_user, 0, 0);
    } else {
      if (vp)
        cp->c_block->b_return = new_variable(vp);
      else {
        cp->c_block->b_return = NEW(T_VARIABLE);
        cp->c_block->b_return->var_type = bp->bm_return_type;
      }
    }
  }
  if (bp->bm_check)
    (*bp->bm_check)(bp->bm_name, ep);
}

static void
do_compound_check(T_VARIABLE *vp, T_EXPR *ep, char *op)
{
  T_EXPR expr;

  expr = zero_expr;
  expr.e_type = E_VALUE;
  expr.e_variable = vp;
  expr_clash_check(&expr, ep, op);
  do_assign_check(vp, ep, "assignment", 0);
}

static void
do_lazy_value(T_EXPR *re, T_VARIABLE *vp)
{
  T_FCALL *cp;
  T_EXPR *ep;
  T_BMAP bp;

  /* spoof this to a call */
  re->e_type = E_CALL;

  /* build the arg list with the member in it */
  ep = NEW(T_EXPR);
  ep->e_type = E_VALUE;
  ep->e_variable = vp;

  /* build the call with the arg list */
  cp = NEW(T_FCALL);
  cp->c_name = "se_lazy_value";
  cp->c_line_no = Lex_line_no;
  cp->c_builtin = Se_functions[S_LAZY_VALUE];
  cp->c_args = ep;
  cp->c_arg_count = 1;

  /* put it into the expr */
  re->e_call = cp;

  /* spoof a builtin to build the return value */
  bp.bm_name = cp->c_name;
  bp.bm_stype = 0;
  bp.bm_param_count = 1;
  bp.bm_return_type = vp->var_type;
  if (bp.bm_return_type == VAR_USER)
    bp.bm_user_type = vp->var_struct->st_name;
  bp.bm_check = 0;
  do_builtin_check(&bp, vp, cp, ep, 1);
}

static T_STATEMENT *
do_lazy_lvalue(T_STATEMENT *sp)
{
  T_VARIABLE *vp;
  T_EXPR *ep;
  T_FCALL *cp;
  T_STATEMENT *ssp;

  /* totally fake this */
  vp = NEW(T_VARIABLE);
  vp->var_type = VAR_REGISTER;
  vp->var_un.var_register = (T_REGISTER) sp;

  /* build the arg list with the member in it */
  ep = NEW(T_EXPR);
  ep->e_type = E_VALUE;
  ep->e_variable = vp;

  /* build the call with the arg list */
  cp = NEW(T_FCALL);
  cp->c_name = "se_lazy_lvalue";
  cp->c_line_no = Lex_line_no;
  cp->c_builtin = Se_functions[S_LAZY_LVALUE];
  cp->c_args = ep;
  cp->c_arg_count = 1;

  /* different statement */
  ssp = NEW(T_STATEMENT);
  ssp->s_type = S_CALL;
  ssp->s_un.s_call = cp;
  ssp->s_function = Se_functions[S_CALL];

  return ssp;
}

static int
try_to_attach(void *handle, char *lib, T_BLOCK *attach_list, int last_try)
{
  T_BLOCK *bp;
  int not_found = 0;

  for(bp = attach_list; bp; bp = bp->b_next) {
    bp->b_attachment = (void *(*)(T_REGISTER, ...)) dlsym(handle, bp->b_name);
    if (bp->b_attachment == 0) {
      not_found++;
      if (last_try) {
        snprintf(error_buf, sizeof error_buf,
          "cannot find: %s in library: %s", bp->b_name, lib);
        yyerror(error_buf, ERR_NONFATAL);
      }
    }
  }
  return not_found;
}

char *
se_basedir(char *cmd, int first)
{
  static char path[BUFSIZ];
  static char *tmp;
  static char *p;

  if (first && strchr(cmd, '/')) {
    p = strcpy(path, cmd);
    *strrchr(path, '/') = '\0';
  } else {
    if (first) {
      se_new_string(&tmp, getenv("PATH"));
      p = strtok(tmp, ":");
    } else
      p = strtok(0, ":");
    for(; p; p=strtok(0, ":")) {
      snprintf(path, sizeof path, "%s/%s", p, cmd);
      if (access(path, F_OK) == 0)
        break;
    }
    if (p == 0) {
      if (tmp) {
        se_free(tmp);
        tmp = 0;
      }
    }
  }
  return p;
}

static char *
canonicalize_lib(char *lib)
{
  static char path[BUFSIZ];
  static char processor[32];
  char *p;
  char *tmp;
  int first;

  /* ahh what the hey, let's see if it's actually where I'd like it to be */
  if (processor[0] == '\0')
#ifdef _LP64
# ifdef SI_ARCHITECTURE_64
    sysinfo(SI_ARCHITECTURE_64, processor, sizeof processor);
# else
    strcpy(processor, "sparcv9");
# endif
#else
    sysinfo(SI_ARCHITECTURE, processor, sizeof processor);
#endif
  snprintf(path, sizeof path, DEFAULT_SE_LIB "/%s/%s", processor, lib);
  if (access(path, F_OK) == 0)
    return path;
  snprintf(path, sizeof path, DEFAULT_SE_LIB "/%s", lib);
  if (access(path, F_OK) == 0)
    return path;
  p = getenv("LD_LIBRARY_PATH");
  if (p) {
    tmp = se_string_save(p);
    for(p=strtok(tmp, ":"); p; p=strtok(0, ":")) {
      snprintf(path, sizeof path, "%s/%s", p, lib);
      if (access(path, F_OK) == 0) {
        p = path;
        break;
      }
    }
    free(tmp);
    if (p)
      return p;
  }
  /* not in LD_LIBRARY_PATH, maybe SE isn't installed in /opt/RICHPse */
  for(first = 1;; first = 0) {
    p = se_basedir(Se_programName, first);
    if (p == 0)
      break;
    snprintf(path, sizeof path, "%s/../lib/%s/%s", p, processor, lib);
    if (access(path, F_OK) == 0)
      return path;
  }
  return lib;
}

static void
do_attach_check(char *lib, T_BLOCK *attach_list)
{
  static void *my_handle = 0;
  void *handle = 0;

  if (my_handle == 0) {
    my_handle = dlopen(0, RTLD_LAZY);
    if (my_handle == 0) {
      snprintf(error_buf, sizeof error_buf, "dlopen(0): %s", dlerror());
      yyerror(error_buf, ERR_FATAL);
    }
#ifdef _LP64
    {
      char buf[BUFSIZ];
      char *p;

      p = getenv("LD_LIBRARY_PATH");
      if (p)
        snprintf(buf, sizeof buf, "LD_LIBRARY_PATH=/usr/lib/64:%s", p);
      else
        strcpy(buf, "LD_LIBRARY_PATH=/usr/lib/64");
      putenv(buf);
    }
#endif
  }
  if (attach_list && (try_to_attach(my_handle, lib, attach_list, 0) == 0))
    return;
  lib = canonicalize_lib(lib);
  handle = dlopen(lib, RTLD_LAZY);
  if (handle == 0) {
    snprintf(error_buf, sizeof error_buf, "dlopen(%s): %s", lib, dlerror());
    yyerror(error_buf, ERR_NONFATAL);
    return;
  }
  if (attach_list) 
    try_to_attach(handle, lib, attach_list, 1);
  /* DO NOT dlclose(handle) */
}

/*
 * newing functions
 */


static T_VARIABLE *
new_variable(T_VARIABLE *mp)
{
  T_VARIABLE *new_mp;

  /* common members */
  new_mp = NEW(T_VARIABLE);
  *new_mp = *mp;
  if (new_mp->var_dimension)
    new_mp->var_un.var_array = new_array_type(new_mp);
  else if (mp->var_type == VAR_USER)
    new_mp->var_un.var_user = new_user_type(mp);

  return new_mp;
}

static T_STRUCT *
new_user_type(T_VARIABLE *vp)
{
  register T_VARIABLE *mp;
  T_VARIABLE *head = 0;
  register T_VARIABLE *current;
  T_VARIABLE *new_mp;
  T_VARIABLE *xp;
  T_STRUCT   str;
  T_STRUCT   *sp;

  if (vp->var_struct == 0)
    return 0;

  /* foreach struct member */
  for(mp=vp->var_struct->st_members; mp; mp=mp->var_next) {

    new_mp = new_variable(mp);
    if (head)
      current = current->var_next = new_mp;
    else
      current = head = new_mp;

    new_mp->var_parent = vp;
  }
  sp = NEW(T_STRUCT);
  sp->st_name = vp->var_struct->st_name;
  sp->st_size = vp->var_struct->st_size;
  sp->st_class = vp->var_struct->st_class;
  sp->st_members = head;

  /* if it's a class and has local variables, then create copies of the   *
   * locals and copy the aggregate values over.                           */
  if (vp->var_struct->st_class && vp->var_struct->st_local_vars) {

    /* build the struct. str can be temp since it gets replaced below */
    str.st_name = "class_local_struct";
    str.st_members = vp->var_struct->st_class->b_variables;
    str.st_size = 0;
    str.st_class = 0;
    str.st_local_vars = 0;

    /* build a variable of this struct */
    mp = NEW(T_VARIABLE);
    mp->var_type = VAR_USER;
    mp->var_name = "class_local_variables";
    mp->var_struct = &str;

    /* &str is used up till here.  Now I build a new user type */
    mp->var_un.var_user = new_user_type(mp);

    /* new instances of an active class variable do not have their own   *
     * instances of class_local variables since they cannot access them. */

    for(xp=mp->var_un.var_user->st_members; xp; xp=xp->var_next)
      xp->var_instances = 0;

    /* replace var_struct with the original pointer to the struct */
    mp->var_struct = vp->var_struct;
    sp->st_local_vars = mp;

    /* bring across aggregately initialized class block local variables */
    se_structure_assignment(/* to   = */ mp,
                            /* from = */ vp->var_struct->st_local_vars);
  }

  return sp;
}

static void *
new_array_type(T_VARIABLE *vp)
{
  int i;
  int unit;
  int dimension;
  T_STRUCT **p;

  /* allocate quantity one for dynamic arrays and let run.c deal with it */
  dimension = vp->var_dimension;
  if (dimension == -1)
    dimension = 1;
  unit = Se_type_sizes[vp->var_type];
  if (unit == -1) {
    p = (T_STRUCT **) se_alloc(sizeof(T_STRUCT *) * dimension);
    for(i=0; i<dimension; i++)
      p[i] = new_user_type(vp);
    return p;
  }
  return se_alloc(unit * dimension);
}

void *
se_new_array_type(T_VARIABLE *vp)
{
  return new_array_type(vp);
}


/*
 * misc. utilities
 */


static void
member_inherit(T_VARIABLE *vp, T_VFTYPE type)
{
  int i;
  T_STRUCT **sp;
  T_VARIABLE *vvp;

  if (vp->var_type != VAR_USER) {
    switch(type) {
    case VF_KSTAT:
      yyerror("kstat variables are structures only", ERR_NONFATAL);
      break;
    case VF_CLASS:
      snprintf(error_buf, sizeof error_buf,
        "name: %s designates a class type", vp->var_name);
      yyerror(error_buf, ERR_NONFATAL);
      break;
    case VF_MIB:
      yyerror("mib variables are structures only", ERR_NONFATAL);
      break;
    }
    return;
  }
  if (vp->var_dimension == 0)
    for(vvp=vp->var_un.var_user->st_members; vvp; vvp=vvp->var_next) {
      vvp->var_parent = vp;
      vvp->var_flags |= (vp->var_flags & VF_SPECIAL);
      if (vvp->var_type == VAR_USER)
        member_inherit(vvp, type);
    }
  else {
    sp = (T_STRUCT **) vp->var_un.var_array;
    for(i=0; i<vp->var_dimension; i++)
      for(vvp=sp[i]->st_members; vvp; vvp=vvp->var_next) {
        vvp->var_parent = vp;
        vvp->var_flags |= (vp->var_flags & VF_SPECIAL);
        if (vvp->var_type == VAR_USER)
          member_inherit(vvp, type);
      }
  }
}

static void
case_error(T_CASE *cp, char *msg)
{
  int n = Lex_line_no;

  Lex_line_no = cp->ca_line_no;
  yyerror(msg, ERR_NONFATAL);
  Lex_line_no = n;
}

static void
push(void *item, T_STACK *sp)
{
  if (sp->st_top == MAX_STACK)
    yyerror("statement stack overflow", ERR_FATAL);
  sp->st_array[sp->st_top++] = item;
}

static void *
pop(T_STACK *sp)
{
  if (sp->st_top == 0)
    return 0;
  return sp->st_array[--sp->st_top];
}

static int
is_lazy(T_VARIABLE *vp)
{
  while(vp) {
    if (vp->var_parent && vp->var_parent->var_dimension)
      return 1;
    vp = vp->var_parent;
  }
  return 0;
}

static void
fix_offsets(T_STRUCT *sp, int offset, int fix)
{
  int i;
  int size;
  T_VARIABLE *vvp;

  for(vvp=sp->st_members; vvp; vvp=vvp->var_next) {
    if (fix)
      vvp->var_offset += offset;
    if (vvp->var_type == VAR_USER) {
      if (vvp->var_dimension == 0)
        fix_offsets(vvp->var_un.var_user, vvp->var_offset, 1);
      else {
        size = ((T_STRUCT **) vvp->var_un.var_array)[0]->st_size;
        for(i=0; i<vvp->var_dimension; i++)
          fix_offsets(((T_STRUCT **) vvp->var_un.var_array)[i],
                      vvp->var_offset + (size * i), 1);
      }
    }
  }
}

static void
free_user_type(T_STRUCT *sp)
{
  int i;
  T_VARIABLE *vp;
  T_VARIABLE *xp;

  /* foreach struct member */
  for(vp=sp->st_members; vp; vp=xp) {
    xp = vp->var_next;
    if (vp->var_dimension) {
      switch(vp->var_type) {
      case VAR_USER:
        if (vp->var_un.var_array) {
          for(i=0; i<vp->var_dimension; i++)
            free_user_type(((T_STRUCT **) vp->var_un.var_array)[i]);
          se_free(vp->var_un.var_array);
        }
        break;
      case VAR_STRING:
        if (vp->var_un.var_array) {
          for(i=0; i<vp->var_dimension; i++)
            if (((char **) vp->var_un.var_array)[i])
              se_free (((char **) vp->var_un.var_array)[i]);
          se_free(vp->var_un.var_array);
        }
        break;
      default:
        if (vp->var_un.var_array)
          se_free(vp->var_un.var_array);
        break;
      }
    } else {
      switch(vp->var_type) {
      case VAR_USER:
        free_user_type(vp->var_un.var_user);
        break;
      case VAR_STRING:
        se_free(vp->var_un.var_string);
        break;
      default:
        break;
      }
    }
    se_free(vp);
  }
  se_free(sp);
}

void
se_free_user_type(T_STRUCT *sp)
{
  free_user_type(sp);
}

void
se_clone_array(T_VARIABLE *to, T_VARIABLE *from)
{
  int i;
  int size;
  T_VARIABLE *vp;
  T_VARIABLE *parent;
  T_STRUCT **spp;

  if (to->var_un.var_array) {
    switch(to->var_type) {
    case VAR_STRING:
      for(i=0; i<to->var_dimension; i++)
        if (((char **) to->var_un.var_array)[i])
          se_free (((char **) to->var_un.var_array)[i]);
      break;
    case VAR_USER:
      for(i=0; i<to->var_dimension; i++)
        free_user_type(((T_STRUCT **) to->var_un.var_array)[i]);
      break;
    default:
      break;
    }
    se_free(to->var_un.var_array);
  }
  to->var_un.var_array = new_array_type(from);
  if (to->var_instances)
    parent = to->var_instances->var_parent;
  for(vp=to->var_instances; vp; vp=vp->var_next) {
    /* struct = struct;  implicit instances not caught by lvalue nonterm. */
    if (vp->var_parent != parent)
      break;
    vp->var_un.var_array = to->var_un.var_array;
    vp->var_dimension = from->var_dimension;
  }
  to->var_dimension = from->var_dimension;
  if (to->var_type == VAR_USER) {
    spp = ((T_STRUCT **) to->var_un.var_array);
    size = spp[0]->st_size;
    for(i=0; i<to->var_dimension; i++)
      fix_offsets(spp[i], size * i, 1);
  }
}

