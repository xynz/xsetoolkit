
/* A Bison parser, made by GNU Bison 2.4.1.  */

/* Skeleton interface for Bison's Yacc-like parsers in C
   
      Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.
   
   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.
   
   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */


/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     AMPERSAND = 258,
     AND = 259,
     AND_EQ = 260,
     ASSIGN = 261,
     ASTERISK = 262,
     ATTACH = 263,
     BREAK = 264,
     CASE = 265,
     CHAR_TYPE = 266,
     CLASS = 267,
     COLON = 268,
     COMMA = 269,
     CONTINUE = 270,
     DECREMENT = 271,
     DEFAULT = 272,
     DO = 273,
     DOT = 274,
     DOUBLE_TYPE = 275,
     ELLIPSIS = 276,
     ELSE = 277,
     EQ = 278,
     EXCLAMATION = 279,
     EXTERN = 280,
     FOR = 281,
     GE = 282,
     GT = 283,
     HAT = 284,
     IF = 285,
     INCREMENT = 286,
     INTEGER = 287,
     KSTAT = 288,
     KVM = 289,
     LE = 290,
     LEFT_CURLY = 291,
     LEFT_PAREN = 292,
     LEFT_SQUARE = 293,
     LNEW = 294,
     LONGLONG_TYPE = 295,
     LONG_TYPE = 296,
     LRENEW = 297,
     LT = 298,
     MIB = 299,
     MINUS = 300,
     MINUS_EQ = 301,
     MOD_EQ = 302,
     NDD = 303,
     NE = 304,
     NIL = 305,
     OR = 306,
     OR_EQ = 307,
     PERCENT = 308,
     PIPE = 309,
     PLUS = 310,
     PLUS_EQ = 311,
     PRAGMA = 312,
     QSTRING = 313,
     RE_EQ = 314,
     RE_NEQ = 315,
     REAL = 316,
     LRETURN = 317,
     QUESTION = 318,
     RIGHT_CURLY = 319,
     RIGHT_PAREN = 320,
     RIGHT_SQUARE = 321,
     SEMICOLON = 322,
     SHIFT_LEFT = 323,
     SHIFT_RIGHT = 324,
     SHIFT_LEFT_EQ = 325,
     SHIFT_RIGHT_EQ = 326,
     SHORT_TYPE = 327,
     SLASH = 328,
     SLASH_EQ = 329,
     STRING = 330,
     STRING_TYPE = 331,
     STRUCT = 332,
     SWITCH = 333,
     TILDE = 334,
     TIMES_EQ = 335,
     UCHAR_TYPE = 336,
     ULONGLONG_TYPE = 337,
     ULONG_TYPE = 338,
     USER_TYPE = 339,
     USHORT_TYPE = 340,
     WHILE = 341,
     XOR_EQ = 342,
     AT_SIGN = 343,
     BACKSLASH = 344,
     DOT_DOT = 345,
     EOLN = 346,
     BI_MAX_CPU = 347,
     BI_MAX_DISK = 348,
     BI_MAX_IF = 349,
     BI_MAX_INTS = 350
   };
#endif
/* Tokens.  */
#define AMPERSAND 258
#define AND 259
#define AND_EQ 260
#define ASSIGN 261
#define ASTERISK 262
#define ATTACH 263
#define BREAK 264
#define CASE 265
#define CHAR_TYPE 266
#define CLASS 267
#define COLON 268
#define COMMA 269
#define CONTINUE 270
#define DECREMENT 271
#define DEFAULT 272
#define DO 273
#define DOT 274
#define DOUBLE_TYPE 275
#define ELLIPSIS 276
#define ELSE 277
#define EQ 278
#define EXCLAMATION 279
#define EXTERN 280
#define FOR 281
#define GE 282
#define GT 283
#define HAT 284
#define IF 285
#define INCREMENT 286
#define INTEGER 287
#define KSTAT 288
#define KVM 289
#define LE 290
#define LEFT_CURLY 291
#define LEFT_PAREN 292
#define LEFT_SQUARE 293
#define LNEW 294
#define LONGLONG_TYPE 295
#define LONG_TYPE 296
#define LRENEW 297
#define LT 298
#define MIB 299
#define MINUS 300
#define MINUS_EQ 301
#define MOD_EQ 302
#define NDD 303
#define NE 304
#define NIL 305
#define OR 306
#define OR_EQ 307
#define PERCENT 308
#define PIPE 309
#define PLUS 310
#define PLUS_EQ 311
#define PRAGMA 312
#define QSTRING 313
#define RE_EQ 314
#define RE_NEQ 315
#define REAL 316
#define LRETURN 317
#define QUESTION 318
#define RIGHT_CURLY 319
#define RIGHT_PAREN 320
#define RIGHT_SQUARE 321
#define SEMICOLON 322
#define SHIFT_LEFT 323
#define SHIFT_RIGHT 324
#define SHIFT_LEFT_EQ 325
#define SHIFT_RIGHT_EQ 326
#define SHORT_TYPE 327
#define SLASH 328
#define SLASH_EQ 329
#define STRING 330
#define STRING_TYPE 331
#define STRUCT 332
#define SWITCH 333
#define TILDE 334
#define TIMES_EQ 335
#define UCHAR_TYPE 336
#define ULONGLONG_TYPE 337
#define ULONG_TYPE 338
#define USER_TYPE 339
#define USHORT_TYPE 340
#define WHILE 341
#define XOR_EQ 342
#define AT_SIGN 343
#define BACKSLASH 344
#define DOT_DOT 345
#define EOLN 346
#define BI_MAX_CPU 347
#define BI_MAX_DISK 348
#define BI_MAX_IF 349
#define BI_MAX_INTS 350




#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
{


  int          integer;
  double       real;
  char        *string;
  T_BLOCK     *block;
  T_STATEMENT *statement;
  T_IF        *if_statement;
  T_FCALL     *call_statement;
  T_WHILE     *while_statement;
  T_ASSIGN    *assign_statement;
  T_EXPR      *expression;
  T_LEXPR     *l_expression;
  T_VARIABLE  *variable;
  T_STRUCT    *structure;
  T_VARTYPE    var_type;
  T_FOR       *for_statement;
  T_DO        *do_statement;
  T_SWITCH    *switch_statement;
  T_CASE      *case_statement;
  T_RETURN    *return_statement;
  T_BREAK     *break_statement;
  T_CONTINUE  *continue_statement;
  T_SFTYPE     struct_flags;



} YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE yylval;


