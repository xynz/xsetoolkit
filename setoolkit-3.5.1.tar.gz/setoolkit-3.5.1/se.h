/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _SE_H_
#define _SE_H_

#include "config.h"
#include <setjmp.h>
#include <sys/types.h>

#ifdef _ALLOC_DEBUG
#define se_alloc(n)         _se_alloc(__FILE__, __LINE__, n)
#endif
#ifdef _FREE_DEBUG
#define se_free(p)          _se_free (__FILE__, __LINE__, p)
#endif
#ifdef _NS_DEBUG
#define se_new_stringn(o,n,l) _se_new_string(__FILE__, __LINE__, o, n, l)
#define se_new_string(o,n)  _se_new_string(__FILE__, __LINE__, o, n)
#endif

/* for yyerror */
typedef enum {
  ERR_WARNING  = 1,
  ERR_NONFATAL = 2,
  ERR_FATAL    = 3,
  ERR_LATER    = 4
} T_SE_ERROR;

#define NEW(T)     ((T *) se_alloc(sizeof(T)))
#define FREE(P)    free(P)
#define NIL_VALUE  "\017\016\016\015\017\012\014\016"

#define _DIGIT_(a) (Se_type_sizes[a.var_type] < 8 ? \
                      a.var_un.var_digit : a.var_un.var_ldigit)

/* special variable prefixes */
#define KVM_PREFIX        "kvm$"
#define KSTAT_PREFIX      "kstat$"
#define MIB_PREFIX        "mib$"
#define NDD_PREFIX        "ndd$"

/* and their lengths */
#define KVM_PREFIX_LEN     (sizeof(KVM_PREFIX) - 1)
#define KSTAT_PREFIX_LEN   (sizeof(KSTAT_PREFIX) - 1)
#define MIB_PREFIX_LEN     (sizeof(MIB_PREFIX) - 1)
#define NDD_PREFIX_LEN     (sizeof(NDD_PREFIX) - 1)

/* flags to se */
#define SE_DEBUG           1
#define SE_NO_CPP          2
#define SE_SYNTAX          4
#define SE_WARNING         8
#define SE_GENERATE        16
#define SE_VANISHED        32

/* this represents how many levels you can nest switch/for/while statements */
#define MAX_STACK        256

/* how many args can be passed to an attachment */
#define MAX_ATT_ARGS      12

/* for kstat */
#define NAME_NAME      "name$"
#define NUMBER_NAME    "number$"
#define INSTANCE_NAME  "instance$"
#define LINK_NAME      "$link"
#define REFRESH_NAME   "$refcount"

/* paths */
#define CPP_CMD                "/usr/ccs/lib/cpp -B -D__symbel"
#define TAIL_CMD               "/usr/bin/tail +2"
#ifndef DEFAULT_SE_BASEDIR
#define DEFAULT_SE_BASEDIR     "/opt/RICHPse"
#endif
#ifndef DEFAULT_SE_INCLUDE
#define DEFAULT_SE_INCLUDE     DEFAULT_SE_BASEDIR "/include"
#endif
#ifndef DEFAULT_SE_LIB
#define DEFAULT_SE_LIB         DEFAULT_SE_BASEDIR "/lib"
#endif

#if defined(ppc) || (defined(i386) && defined(_LP64))
#define _USE_INTF
#endif

/* for Solarii < 2.6 */
#ifndef KSTAT_DATA_INT32
# define KSTAT_DATA_INT32        1
# define KSTAT_DATA_UINT32       2
# define KSTAT_DATA_INT64        3
# define KSTAT_DATA_UINT64       4
#endif

/* this should never change */
#define SYS_GID 3

/* typedefs of structures */
typedef struct _stack      T_STACK;
typedef long long          T_LLONG;
typedef unsigned long long T_ULLONG;
typedef struct _block      T_BLOCK;
typedef struct _statement  T_STATEMENT;
typedef struct _if         T_IF;
typedef struct _fcall      T_FCALL;
typedef struct _while      T_WHILE;
typedef struct _assign     T_ASSIGN;
typedef struct _lexpr      T_LEXPR;
typedef struct _expr       T_EXPR;
typedef struct _symbol     T_SYMBOL;
typedef struct _variable   T_VARIABLE;
typedef struct _struct     T_STRUCT;
typedef struct _for        T_FOR;
typedef struct _do         T_DO;
typedef struct _switch     T_SWITCH;
typedef struct _case       T_CASE;
typedef struct _return     T_RETURN;
typedef struct _break      T_BREAK;
typedef struct _continue   T_CONTINUE;

#ifdef _LP64
# define VAR_CONSTANT VAR_LONGLONG
# define VAR_REGISTER VAR_ULONGLONG
# define var_register var_uldigit
# define T_REGISTER T_ULLONG
#else
# define VAR_CONSTANT VAR_LONG
# define VAR_REGISTER VAR_ULONG
# define var_register var_udigit
# define T_REGISTER ulong_t
#endif

/******/
struct _stack {
  void *st_array[MAX_STACK];
  int   st_top;
};

typedef enum {
  B_INITIALIZED=1, B_ACTIVE=2, B_INITIAL_CALL=4, B_EXTERN=8, B_REFERENCED=16,
  B_GENERATED=32
} T_BFTYPE;

struct _block {
  T_BFTYPE     b_flags;
  int          b_param_count;
  char        *b_name;
  char        *b_attach_lib;
  T_VARIABLE  *b_parameters;
  T_VARIABLE  *b_variables;
  T_STATEMENT *b_statements;
  T_VARIABLE  *b_return;
  void      *(*b_attachment)(T_REGISTER, ...);
  jmp_buf      b_jmpbuf;
  T_BLOCK     *b_next;
};

/******/
typedef enum {

  /* control structures 1 through 10 */
  S_IF=1,
  S_WHILE=2,
  S_FOR=3,
  S_DO=4,
  S_SWITCH=5,
  S_RETURN=6,
  S_BREAK=7,
  S_CONTINUE=8,

  /* statement types 11 through 30 */
  S_CALL=11,
  S_ASSIGN=12,
  S_INCREMENT=13,
  S_DECREMENT=14,
  S_ATTACHMENT=15,
  S_ADDR_OF=16,
  S_LAZY_VALUE=17,
  S_LAZY_LVALUE=18,
  S_INDIRECT=19,
  S_NEW=20,
  S_NULL=21,
  S_RENEW=22,

  /* builtins 31 and up */
  S_PRINTF=31,
  S_ITOA=32,
  S_FIRST_PROC=33,
  S_NEXT_PROC=34,
  S_GET_PROC=35,
  S_FPRINTF=36,
  S_SPRINTF=37,
  S_SIGFUNC=38,
  S_DEBUG_ON=39,
  S_DEBUG_OFF=40,
  S_FILENO=41,
  S_SYSLOG=42,
  S_SIZEOF=43,
  S_KVM_CVT=44,
  S_KVM_ADDR=45,
  S_STRUCT_FILL=46,
  S_STRUCT_EMPTY=47,
  S_KVM_DECLARE=48,
  S_TYPE_CAST=49,
  S_QSORT=50,
  S_ATEXIT=51,
  S_BSEARCH=52,
  S_REFRESH=53,

  /* these are builtins, but all math funcs */
  S_ACOS=60,
  S_ACOSH=61,
  S_ASIN=62,
  S_ASINH=63,
  S_ATAN=64,
  S_ATAN2=65,
  S_ATANH=66,
  S_CBRT=67,
  S_CEIL=68,
  S_COPYSIGN=69,
  S_COS=70,
  S_COSH=71,
  S_ERF=72,
  S_ERFC=73,
  S_EXP=74,
  S_EXPM1=75,
  S_FABS=76,
  S_FLOOR=77,
  S_FMOD=78,
  S_FREXP=79,
  S_GAMMA=80,
  S_GAMMA_R=81,
  S_HYPOT=82,
  S_ILOGB=83,
  S_ISNAN=84,
  S_J0=85,
  S_J1=86,
  S_JN=87,
  S_LDEXP=88,
  S_LGAMMA=89,
  S_LGAMMA_R=90,
  S_LOG=91,
  S_LOG10=92,
  S_LOG1P=93,
  S_LOGB=94,
  S_MATHERR=95,
  S_MODF=96,
  S_NEXTAFTER=97,
  S_POW=98,
  S_REMAINDER=99,
  S_RINT=100,
  S_SCALB=101,
  S_SCALBN=102,
  S_SIGNIFICAND=103,
  S_SIN=104,
  S_SINH=105,
  S_SQRT=106,
  S_TAN=107,
  S_TANH=108,
  S_Y0=109,
  S_Y1=110,
  S_YN=111,
  S_READDIR=112

} T_STYPE;

#define S_CONTROL_START      S_IF
#define S_STATEMENT_START    S_CALL
#define S_BUILTIN_START      S_PRINTF

struct _statement {
  T_STYPE s_type;
  int     s_line_no;
  void  (*s_function)(T_STATEMENT *);
  union {
    T_IF       *s_if;
    T_FCALL    *s_call;
    T_WHILE    *s_while;
    T_ASSIGN   *s_assign;
    T_VARIABLE *s_variable;
    T_FOR      *s_for;
    T_DO       *s_do;
    T_SWITCH   *s_switch;
    T_RETURN   *s_return;
    T_BREAK    *s_break;
    T_CONTINUE *s_continue;
  } s_un;
  T_STATEMENT *s_next;
};

struct _if {
  T_LEXPR     *i_if;
  T_STATEMENT *i_then;
  T_STATEMENT *i_else;
};

struct _fcall {
  int      c_line_no;
  char    *c_name;
  T_BLOCK *c_block;
  void   (*c_builtin)(T_STATEMENT *);
  T_EXPR  *c_args;
  int      c_arg_count;
  T_FCALL *c_next;
};

struct _while {
  T_LEXPR     *w_expr;
  T_STATEMENT *w_statements;
  jmp_buf      w_jmpbuf;
};

typedef enum {
  A_ASSIGN=1, A_ADD=2, A_SUBTRACT=3, A_MULTIPLY=4, A_DIVIDE=5, A_MODULUS=6,
  A_BIT_AND=7, A_BIT_OR=8, A_BIT_XOR=9, A_SHIFT_LEFT=10, A_SHIFT_RIGHT=11
} T_ATYPE;

struct _assign {
  T_VARIABLE *a_variable;
  T_ATYPE     a_op;
  T_EXPR     *a_expression;
};

/******/
typedef enum {
  LE_EQ=1, LE_NE=2, LE_LT=3, LE_GT=4, LE_GE=5, LE_LE=6,
  LE_RE_EQ=7, LE_RE_NEQ=8, LE_AND=9, LE_OR=10, LE_PREC=11, LE_NOT=12
} T_LETYPE;

struct _lexpr {
  T_EXPR  *le_left;
  T_LETYPE le_op;
  T_EXPR  *le_right;
};

/******/
typedef enum {
  E_VALUE=1,  E_EXPRESSION=2,  E_CALL=3,   E_AGGREGATE=4,  E_QCOP=5,
  E_INCRB=6,  E_LAZY_INCRB=7,  E_INCRA=8,  E_LAZY_INCRA=9,
  E_DECRB=10, E_LAZY_DECRB=11, E_DECRA=12, E_LAZY_DECRA=13, E_ASSIGN=14
} T_ETYPE;

typedef enum {
  EO_ADD=1, EO_SUBTRACT=2, EO_MULTIPLY=3, EO_DIVIDE=4, EO_MODULUS=5,
  EO_BIT_AND=6, EO_BIT_OR=7, EO_BIT_XOR=8, EO_SHIFT_LEFT=9, EO_SHIFT_RIGHT=10,
  EO_BIT_NOT=11, EO_PRECEDENCE=12
} T_OTYPE;

struct _expr {
  T_ETYPE     e_type;
  T_VARIABLE *e_variable;
  T_FCALL    *e_call;
  T_LEXPR    *e_lexpr;
  T_EXPR     *e_left;
  T_EXPR     *e_right;
  T_ASSIGN   *e_assign;
  T_OTYPE     e_op;
  T_EXPR     *e_next;
};

/******/
typedef enum {
  SYM_BLOCK=1, SYM_VARIABLE=2, SYM_STRUCT=4
} T_SYMTYPE;

struct _symbol {
  T_SYMTYPE     sym_type;
  union {
    T_BLOCK    *sym_block;
    T_VARIABLE *sym_variable;
    T_STRUCT   *sym_struct;
  } sym_un;
};

/******/
typedef enum {
  VAR_STRING=1,
  VAR_CHAR=2,        VAR_UCHAR=4,       VAR_SHORT=8,        VAR_USHORT=16,
  VAR_LONG=32,       VAR_ULONG=64,      VAR_LONGLONG=128,   VAR_ULONGLONG=256,
  VAR_DOUBLE=512,    VAR_USER=1024,     VAR_ELLIPSIS=2048,  VAR_BOGUS=4096
} T_VARTYPE;

#define VAR_NUMERIC  (VAR_CHAR | VAR_UCHAR | VAR_SHORT    | VAR_USHORT |    \
                      VAR_LONG | VAR_ULONG | VAR_LONGLONG | VAR_ULONGLONG | \
                      VAR_DOUBLE)
#define VAR_INTEGRAL (VAR_CHAR | VAR_UCHAR | VAR_SHORT    | VAR_USHORT |    \
                      VAR_LONG | VAR_ULONG | VAR_LONGLONG | VAR_ULONGLONG)


typedef enum {
  VF_EMPTY=1,     VF_INITIALIZED=2, VF_REFERENCED=4,   VF_MEMBER=8,
  VF_KVM=16,      VF_KSTAT=32,      VF_CLASS=64,       VF_MIB=128,
  VF_NDD=256,     VF_EXTERN=512,    VF_GENERATED=1024, VF_AGGREGATE=2048,
  VF_GLOBAL=4096, VF_PRAGMA_REF=8192
} T_VFTYPE;

#define VF_SPECIAL  (VF_KVM|VF_KSTAT|VF_CLASS|VF_MIB|VF_NDD|VF_EXTERN)

typedef enum {
  SS_KVM=1, SS_KSTAT=2, SS_NDD=4, SS_MIB=8, SS_USER=16
} T_SPECIAL;

struct _variable {
  T_VFTYPE    var_flags;       /* alas, flags                        */
  T_SPECIAL   var_special;     /* if kstat struct, ndd struct, etc.  */
  T_VARTYPE   var_type;        /* what type is this variable         */
  T_STRUCT   *var_struct;      /* pointer to user defined structure  */
  char       *var_name;        /* name of the variable               */
  char       *var_qname;       /* quoted name from a kstat struct    */
  char       *var_attach_lib;  /* lib extern var is attached to      */
  caddr_t     var_address;     /* kernel address of variable         */
  T_EXPR     *var_initial;     /* initial value expression           */
  union {                      /* actual values                      */
    char         *var_string;  /* strings                            */
    int           var_digit;   /* signed integers                    */
    unsigned int  var_udigit;  /* unsigned integers                  */
    T_LLONG       var_ldigit;  /* signed 64 bit integers             */
    T_ULLONG      var_uldigit; /* unsigned 64 bit integers           */
    double        var_rdigit;  /* double precision real              */
    T_STRUCT      *var_user;   /* structure                          */
    void          *var_array;  /* array                              */
  } var_un;

  /* array specific members */
  int         var_dimension;  /* array size if array                 */
  T_EXPR     *var_subscript;  /* subscript if array                  */
  T_VARIABLE *var_instances;  /* all array variable_value instances  */

  /* struct specific members */
  int         var_offset;     /* offset into struct if struct member */
  T_VARIABLE *var_parent;     /* variable that this member is in     */
  T_VARIABLE *var_next;       /* next structure member               */
};

typedef enum {
  SF_REFERENCED=1, SF_GENERATED=2, SF_KSTAT=4, SF_NDD=8, SF_MIB=16, SF_USER=32
} T_SFTYPE;

/******/
struct _struct {
  T_SFTYPE    st_flags;
  char       *st_name;
  char       *st_kname;      /* name in kstat or ndd */
  int         st_size;
  int         st_missing;    /* for missing members, starts at 1 */
  T_VARIABLE *st_members;
  T_VARIABLE *st_local_vars; /* local vars in the class code built  *
                              * to look like a struct variable      */
  T_BLOCK    *st_class;
};

struct _for {
  T_STATEMENT *f_before;
  T_LEXPR     *f_while;
  T_STATEMENT *f_after;
  T_STATEMENT *f_statements;
  jmp_buf      f_jmpbuf;
};

struct _do {
  T_STATEMENT *do_statements;
  T_LEXPR     *do_while;
  jmp_buf      do_jmpbuf;
};

struct _switch {
  T_EXPR      *sw_expr;
  T_CASE      *sw_case_list;
  T_CASE      *sw_default;
  avlhdr      *sw_cases;
  jmp_buf      sw_jmpbuf;
};

typedef enum {
  CA_STATEMENTS=1
} T_CATYPE;

struct _case {
  T_CATYPE     ca_flags;
  int          ca_line_no;
  T_VARIABLE  *ca_value;
  T_STATEMENT *ca_statements;
  T_CASE      *ca_next;
};

struct _return {
  int          ret_line_no;
  T_BLOCK     *ret_block;
  T_EXPR      *ret_expr;
  T_RETURN    *ret_next;
};

typedef enum {
  BRK_SWITCH=1, BRK_FOR=2, BRK_DO=3, BRK_WHILE=4
} T_BTYPE;

struct _break {
  T_BTYPE      brk_type;
  union {
    T_SWITCH  *brk_switch;
    T_FOR     *brk_for;
    T_DO      *brk_do;
    T_WHILE   *brk_while;
  } brk_un;
  T_BREAK     *brk_next;
};

typedef enum {
  CON_FOR=1, CON_DO=2, CON_WHILE=3
} T_CTYPE;

struct _continue {
  T_CTYPE     con_type;
  union {
    T_FOR    *con_for;
    T_DO     *con_do;
    T_WHILE  *con_while;
  } con_un;
  T_CONTINUE *con_next;
};

/******/
extern int           Se_kvm_var_count;
extern int           Se_kvm_open_flags;
extern int           Se_kstat_var_count;
extern int           Se_mib_var_count;

extern char         *Se_core_file;
extern char         *Se_kernel;
extern char         *Se_paging_file;

extern avlhdr       *Se_symbol_table;
extern int           Se_errors;
extern int           Se_flags;
extern int           Se_type_sizes[];
extern int           Se_os_version;
extern char         *Se_programName;
extern char         *Se_basedir;
extern void        (*Se_functions[])(T_STATEMENT *);

extern char          Lex_currentFile[];
extern char          Lex_currtok[];
extern int           Lex_line_no;
extern T_REGISTER    Lex_integerValue;
extern double        Lex_doubleValue;
extern FILE         *Lex_input;

/* internal functions */
extern void          yyerror(char *, ...);
extern int           yyparse(void);
extern int           valid_name(char *);
extern int           se_get_keyword(char *);
extern void          version(void);
extern void          se_debug_statement(T_STATEMENT *);
extern void          se_clone_array(T_VARIABLE *, T_VARIABLE *);
extern void          se_update_extern_variable(T_VARIABLE *);
extern void          se_refresh_extern_variable(T_VARIABLE *);
extern void          se_add_kstat_type(T_STRUCT *);
extern void          se_add_ndd_type(T_STRUCT *);
extern void          se_add_disk_name(char *);
extern int           se_cleanup_tok_syms(char *);

extern char         *se_string_saven(char *, size_t);
extern char         *se_string_save(char *);
extern char         *se_kill_double_quotes(char *);
extern char         *se_basedir(char *, int);
extern int           se_compute_subscript(T_VARIABLE *, int);
extern int           se_run(int, char **);
extern void          se_resolve_expression(T_VARIABLE *, T_EXPR *, int);
extern void          se_run_assign(T_VARIABLE *, T_EXPR *);
extern void          se_run_block(T_BLOCK *);
extern void         *se_new_array_type(T_VARIABLE *);
extern T_VARIABLE   *se_function_call(char *fn, ...);
#ifdef se_alloc
extern void         *_se_alloc(char *, int, int);
#else
extern void         *se_alloc(int);
#endif
#ifdef se_free
extern void          _se_free(char *, int, void *);
#else
extern void          se_free(void *);
#endif
#ifdef se_new_string
extern void          _se_new_string(char *, int, char **, char *);
#else
extern void          se_new_string(char **, char *);
#endif
#ifdef se_new_stringn
extern void          _se_new_stringn(char *, int, char **, char *, size_t);
#else
extern void          se_new_stringn(char **, char *, size_t);
#endif
extern void          se_parse_init(void);
extern void          se_lex_init(char *, char *);
extern void          se_lex_end(void);
#ifdef USE_LICENSE
extern void          se_init_internals(unsigned char *, unsigned char *);
#endif
extern void          se_init_kvm(void);
extern void          se_init_kstat(void);
extern void          se_init_mib(void);
extern void          se_init_ndd(void);
extern void          se_end_kvm(void);
extern void          se_end_kstat(void);
extern void          se_end_mib(void);
extern void          se_end_ndd(void);
extern void          se_free_user_type(T_STRUCT *);
extern void          se_refresh_kvm_variable(T_VARIABLE *);
extern void          se_update_kvm_variable(T_VARIABLE *);
extern int           se_kvm_state_change(void);
extern unsigned long se_kvm_address(char *);
extern void          se_refresh_kstat_variable(T_VARIABLE *);
extern void          se_update_kstat_variable(T_VARIABLE *);
extern void          se_refresh_mib_variable(T_VARIABLE *);
extern void          se_refresh_ndd_variable(T_VARIABLE *);
extern void          se_update_ndd_variable(T_VARIABLE *);
extern void          se_address_inherit(T_VARIABLE *, caddr_t);
extern void          se_fatal(char *, ...);
extern void          se_warning(char *, ...);
extern void          se_structure_assignment(T_VARIABLE *, T_VARIABLE *);
extern void          se_area_into_struct(uchar_t *, T_VARIABLE *);
extern void          se_generate(char *);
extern uchar_t      *se_struct_into_area(T_VARIABLE *, uchar_t *);
extern T_BLOCK      *se_get_block(char *);
extern T_VARIABLE   *se_get_variable(char *);
extern T_STRUCT     *se_get_struct(char *);
extern void          se_fix_type(T_VARIABLE *, T_VARTYPE);

#ifndef HAVE_STRLCPY
extern size_t        strlcpy(char *, const char *, size_t);
#endif

#endif
