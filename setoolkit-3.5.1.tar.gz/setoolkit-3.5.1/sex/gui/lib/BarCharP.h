/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _BAR_CHARP_H_
#define _BAR_CHARP_H_

#include <BarChart.h>
#include <X11/Xaw/SimpleP.h>

/* New fields for the barChart widget instance record */

typedef struct {
  Widget  label;
  Widget  value;
  Widget  upper;
  Widget  lower;
  Widget  bar;
} BarChartChildData;

typedef struct {
  int                is_chart;      /* x86 needs rtc */
  Pixel              fg;            /* foreground pixel */
  Pixel              bg;            /* background pixel */
  GC                 gc;            /* graphics context for fg */
  int                update;        /* update frequency */
  int                value;         /* value set with SetValues (increments) */
  int                last_value;    /* the last value set (pixels) */
  int                min_value;     /* min value in window */
  int                max_value;     /* max value in window */
  Boolean            value_changed; /* for smarter repaints on SetValues */
  XtIntervalId       interval_id;   /* id for timeout event */
  XtOrientation      orientation;   /* XtorientVertical or XtorientHorizontal */
  String             label_string;  /* string for the label on BarChart */
  XtCallbackList     get_value;     /* proc to call to fetch load pt */
  BarChartChildData *bc_data;       /* other Widgets in the bar chart */
} BarChartPart;

/* Full instance record declaration */
typedef struct _BarChartRec {
   CorePart     core;
   SimplePart   simple;
   BarChartPart bar_chart;
} BarChartRec;

/* New fields for the BarChart widget class record */
typedef struct {int dummy;} BarChartClassPart;

/* Full class record declaration. */
typedef struct _BarChartClassRec {
   CoreClassPart     core_class;
   SimpleClassPart   simple_class;
   BarChartClassPart bar_chart_class;
} BarChartClassRec;

/* Class pointer. */
extern BarChartClassRec barChartClassRec;

#endif
