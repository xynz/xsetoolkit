/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/* necessary to get the intrinsics to shut up */
#define XT_REVISION 5

#include <stdio.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Xfuncs.h>
#include <X11/Xaw/XawInit.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/Label.h>
#include <Xm/RowColumn.h>
#include "BarCharP.h"
#include "gui.h"

#define MS_PER_SEC 1000

#define LABEL_NAME   "label"
#define VALUE_NAME   "value"
#define LOWER_NAME   "lower"
#define UPPER_NAME   "upper"
#define BAR_NAME     "bar"

/* Private Data */

static XtResource resources[] = {
    {XtNwidth, XtCWidth, XtRDimension, sizeof(Dimension),
        XtOffsetOf(BarChartRec, core.width),
        XtRImmediate, (XtPointer) 120},
    {XtNheight, XtCHeight, XtRDimension, sizeof(Dimension),
        XtOffsetOf(BarChartRec, core.height),
        XtRImmediate, (XtPointer) 120},
    {XtNupdate, XtCInterval, XtRInt, sizeof(int),
        XtOffsetOf(BarChartRec, bar_chart.update),
        XtRImmediate, (XtPointer) 0},
    {XtNforeground, XtCForeground, XtRPixel, sizeof(Pixel),
        XtOffsetOf(BarChartRec, bar_chart.fg),
        XtRString, XtDefaultForeground},
    {XtNbackground, XtCBackground, XtRPixel, sizeof(Pixel),
        XtOffsetOf(BarChartRec, bar_chart.bg),
        XtRString, XtDefaultBackground},
    {XtNgetValue, XtCCallback, XtRCallback, sizeof(XtPointer),
        XtOffsetOf(BarChartRec, bar_chart.get_value),
        XtRImmediate, (XtPointer) NULL},
    {XtNminValue, XtCScale, XtRInt, sizeof(int),
        XtOffsetOf(BarChartRec, bar_chart.min_value),
        XtRImmediate, (XtPointer) 0},
    {XtNmaxValue, XtCScale, XtRInt, sizeof(int),
        XtOffsetOf(BarChartRec, bar_chart.max_value),
        XtRImmediate, (XtPointer) 100},
    {XtNvalue, XtCScale, XtRInt, sizeof(int),
        XtOffsetOf(BarChartRec, bar_chart.value),
        XtRImmediate, (XtPointer) 0},
    {XtNorientation, XtCOrientation, XtROrientation, sizeof(XtOrientation),
        XtOffsetOf(BarChartRec, bar_chart.orientation),
        XtRImmediate, (XtPointer) XtorientHorizontal},
    {XtNlabel, XtCLabel, XtRString, sizeof(String),
        XtOffsetOf(BarChartRec, bar_chart.label_string),
        XtRImmediate, (XtPointer) "BarChart"}
};

#undef offset

static void    Initialize(Widget, Widget, ArgList, Cardinal *);
static void    Destroy(Widget);
static void    Redisplay(Widget, XEvent *, Region);
static void    CreateGC(BarChartWidget);
static void    DestroyGC(BarChartWidget);
static void    DrawBar(XtPointer, XtIntervalId *);
static void    RepaintWindow(BarChartWidget, int, int);
static Boolean SetValues(Widget, Widget, Widget, ArgList, Cardinal *);

static void    update_value(Widget, XtPointer, XtPointer);

BarChartClassRec barChartClassRec = {
    { /* core fields */
    /* superclass               */      (WidgetClass) &simpleClassRec,
    /* class_name               */      "BarChart",
    /* size                     */      sizeof(BarChartRec),
    /* class_initialize         */      XawInitializeWidgetSet,
    /* class_part_initialize    */      NULL,
    /* class_inited             */      FALSE,
    /* initialize               */      Initialize,
    /* initialize_hook          */      NULL,
    /* realize                  */      XtInheritRealize,
    /* actions                  */      NULL,
    /* num_actions              */      0,
    /* resources                */      resources,
    /* num_resources            */      XtNumber(resources),
    /* xrm_class                */      NULLQUARK,
    /* compress_motion          */      TRUE,
    /* compress_exposure        */      XtExposeCompressMultiple |
                                        XtExposeGraphicsExposeMerged,
    /* compress_enterleave      */      TRUE,
    /* visible_interest         */      FALSE,
    /* destroy                  */      Destroy,
    /* resize                   */      NULL,
    /* expose                   */      Redisplay,
    /* set_values               */      SetValues,
    /* set_values_hook          */      NULL,
    /* set_values_almost        */      XtInheritSetValuesAlmost,
    /* get_values_hook          */      NULL,
    /* accept_focus             */      NULL,
    /* version                  */      XtVersion,
    /* callback_private         */      NULL,
    /* tm_table                 */      NULL,
    /* query_geometry           */      XtInheritQueryGeometry,
    /* display_accelerator      */      XtInheritDisplayAccelerator,
    /* extension                */      NULL
    },
    { /* Simple class fields */
    /* change_sensitive         */      XtInheritChangeSensitive
    }
};

WidgetClass barChartWidgetClass = (WidgetClass) &barChartClassRec;

/****************************************************************
 *
 * Private Procedures
 *
 ****************************************************************/

static void
CreateGC(BarChartWidget w)
{
  XGCValues xgcv;

  xgcv.foreground = w->bar_chart.fg;
  xgcv.background = w->bar_chart.bg;
  w->bar_chart.gc = XtGetGC((Widget) w, GCForeground|GCBackground, &xgcv);
}

static void
DestroyGC(BarChartWidget w)
{
  XtReleaseGC((Widget) w, w->bar_chart.gc);
}

static void
Initialize(Widget greq, Widget gnew, ArgList args, Cardinal *num_args)
{
  BarChartWidget w = (BarChartWidget) gnew;

  if (w->bar_chart.update > 0)
    w->bar_chart.interval_id = XtAppAddTimeOut( 
                                 XtWidgetToApplicationContext(gnew),
                                 w->bar_chart.update * MS_PER_SEC, 
                                 DrawBar, (XtPointer) gnew);
  w->bar_chart.last_value = 0;
  w->bar_chart.value_changed = False;
  CreateGC(w);
}
 
static void
Destroy(Widget gw)
{
  BarChartWidget w = (BarChartWidget) gw;

  if (w->bar_chart.update > 0)
    XtRemoveTimeOut (w->bar_chart.interval_id);
  DestroyGC(w);
  if (w->bar_chart.is_chart && w->bar_chart.bc_data)
    se_free(w->bar_chart.bc_data);
}

/* this function gets called for updates of "value" via SetValues */
static void
Redisplay(Widget w, XEvent *event, Region region)
{
  BarChartWidget bw = (BarChartWidget) w;

  /* value change, not just a random redisplay */
  if (bw->bar_chart.value_changed) {
    RepaintWindow(bw, bw->bar_chart.value, bw->bar_chart.last_value);
    bw->bar_chart.value_changed = False;
    /* if this is a BarChart then update the value widget */
    if (bw->bar_chart.is_chart && bw->bar_chart.bc_data)
      update_value(w, (XtPointer) bw->bar_chart.bc_data,
                   (XtPointer) &bw->bar_chart.value);
    return;
  }
  /* force repaint of the whole window */
  RepaintWindow(bw, bw->bar_chart.value, (int) bw->core.width);
}

/* this function only gets called when the "update" resource is set */
static void 
DrawBar(XtPointer client_data, XtIntervalId *id)
{
  BarChartWidget w = (BarChartWidget) client_data;
  int value;
   
  if (w->bar_chart.update > 0)
    w->bar_chart.interval_id = XtAppAddTimeOut(
                                 XtWidgetToApplicationContext((Widget) w),
                                 w->bar_chart.update * MS_PER_SEC,
                                 DrawBar, client_data);
  XtCallCallbacks( (Widget) w, XtNgetValue, (XtPointer) &value );
  w->bar_chart.value = value;
  RepaintWindow(w, value, w->bar_chart.last_value);
}

/* value is in increments, last_value is in pixels */

static void
RepaintWindow(BarChartWidget w, int value, int last_value)
{
  Display *display = XtDisplay((Widget) w);
  Window window = XtWindow((Widget) w);

  /* figure out how much of the window to paint */
  if (w->bar_chart.orientation == XtorientHorizontal)
    value = (int) (((double) value / (double) w->bar_chart.max_value) *
                    (double) w->core.width);
  else
    value = (int) (((double) value / (double) w->bar_chart.max_value) *
                    (double) w->core.height);

  w->bar_chart.last_value = value;

  if (XtIsRealized((Widget) w)) {
    if (value < last_value)
      XClearWindow(display, window);
    if (w->bar_chart.orientation == XtorientHorizontal)
      XFillRectangle(display, window, w->bar_chart.gc, 0, 0,
                     value, w->core.height);
    else
      XFillRectangle(display, window, w->bar_chart.gc,
                     0, w->core.height - value,
                     w->core.width, value);
  }
}

static Boolean
SetValues(Widget current, Widget request, Widget new,
          ArgList args, Cardinal *num_args)
{
  BarChartWidget old = (BarChartWidget) current;
  BarChartWidget w = (BarChartWidget) new;
  Boolean ret_val = False;

  if (w->bar_chart.update != old->bar_chart.update) {
    if (old->bar_chart.update > 0)
      XtRemoveTimeOut (old->bar_chart.interval_id);
    if (w->bar_chart.update > 0)
      w->bar_chart.interval_id =
        XtAppAddTimeOut(XtWidgetToApplicationContext(new),
                        w->bar_chart.update * MS_PER_SEC,
                        DrawBar, (XtPointer) w);
  }

  if ((w->bar_chart.fg != old->bar_chart.fg) ||
      (w->bar_chart.bg != old->bar_chart.bg)) {
    DestroyGC(old);
    CreateGC(w);
    ret_val = True;
  }
  if (w->bar_chart.value != old->bar_chart.value) {
    w->bar_chart.value_changed = True;
    ret_val = True;
  }
  if (w->bar_chart.orientation != old->bar_chart.orientation)
    ret_val = True;

  return ret_val;
}

Widget
XtCreateBar(Widget parent, char *name, ArgList args, Cardinal num_args)
{
  Widget w = XtCreateWidget(name, barChartWidgetClass, parent, args, num_args);
  BarChartWidget x = (BarChartWidget) w;

  x->bar_chart.is_chart = 0;
  return w;
}

/* what supplied resources can I believe were intended for the form */
static int
is_form_resource(char *res)
{
  static char *form_res[] = {
    XmNtopAttachment,
    XmNbottomAttachment,
    XmNleftAttachment,
    XmNrightAttachment,
    XmNtopWidget,
    XmNbottomWidget,
    XmNleftWidget,
    XmNrightWidget,
    0
  };
  int i;

  for(i=0; form_res[i]; i++)
    if (strcmp(res, form_res[i]) == 0)
      return 1;
  return 0;
}

Widget
XtCreateBarChart(Widget parent, char *name, ArgList args, Cardinal num_args)
{
  char digit[16];
  char *label_text;
  int i;
  int j;
  int n;
  int minValue;
  int maxValue;
  int update;
  Widget form;
  Widget bar;
  Widget lower;
  Widget label;
  Widget value;
  Widget upper;
  XmString cs;
  Arg *wargs;
  XtOrientation orientation;
  BarChartChildData *cbp;
  Arg *flp;

  /* copy these into our memory */
  wargs = (Arg *) se_alloc((num_args + 16) * sizeof(Arg));

  /* the only thing that I *do* want to send to the form are constraints */
  for(i=j=0; i<num_args; i++)
    if (is_form_resource(args[i].name))
      wargs[j++] = args[i];

  /* create the form, feel free to pass on contraint resources */
  form = XmCreateForm(parent, "BarChartForm", wargs, j);

  /* mustn't pass on form constraint resources or else havoc will ensue */
  for(flp=0, i=j=0; i<num_args; i++) {
    if (is_form_resource(args[i].name) == 0)
      wargs[j++] = args[i];
     /* while I'm at it, grovel the font resource out */
    if ((flp == 0) && (strcmp(args[i].name, XmNfontList) == 0))
      flp = &args[i];
  }

  /* create the bar */
  bar = XtCreateBar(form, BAR_NAME, wargs, j);
  XtManageChild(bar);

  /* get the values that are needed from the bar */
  n = 0;
  XtSetArg(wargs[n], XtNminValue, &minValue);  n++;
  XtSetArg(wargs[n], XtNmaxValue, &maxValue);  n++;
  XtSetArg(wargs[n], XtNorientation, &orientation);  n++;
  XtSetArg(wargs[n], XtNlabel, &label_text);  n++;
  XtSetArg(wargs[n], XtNupdate, &update);  n++;
  XtGetValues(bar, wargs, n);

  /* create the label label */
  n = 0;
  if (flp) {
    wargs[n] = *flp;  n++;
  }
  cs = XmStringCreateLtoR(label_text, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  if (orientation == XtorientVertical) {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
  } else {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNrightAttachment, XmATTACH_FORM);  n++;
  }
  label = XmCreateLabel(form, LABEL_NAME, wargs, n);
  XmStringFree(cs);
  XtManageChild(label);

  /* create the minValue label */
  n = 0;
  if (flp) {
    wargs[n] = *flp;  n++;
  }
  sprintf(digit, "%d", minValue);
  cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  if (orientation == XtorientVertical) {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, bar);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, label);  n++;
    XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
  } else {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, label);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM);  n++;
  }
  lower = XmCreateLabel(form, LOWER_NAME, wargs, n);
  XmStringFree(cs);
  XtManageChild(lower);

  /* create the maxValue label */
  n = 0;
  if (flp) {
    wargs[n] = *flp;  n++;
  }
  sprintf(digit, "%d", maxValue);
  cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  if (orientation == XtorientVertical) {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, label);  n++;
  } else {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, label);  n++;
    XtSetArg(wargs[n], XmNrightAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, bar);  n++;
  }
  upper = XmCreateLabel(form, UPPER_NAME, wargs, n);
  XmStringFree(cs);
  XtManageChild(upper);

  /* anchor the bar */
  n = 0;
  if (orientation == XtorientVertical) {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, upper);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, label);  n++;
  } else {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, label);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, lower);  n++;
  }
  XtSetValues(bar, wargs, n);

  /* create the value label */
  n = 0;
  if (flp) {
    wargs[n] = *flp;  n++;
  }
  sprintf(digit, "%d", maxValue);
  cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetArg(wargs[n], XmNrecomputeSize, False);  n++;
  if (orientation == XtorientVertical) {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNleftWidget, bar);  n++;
    XtSetArg(wargs[n], XmNrightAttachment, XmATTACH_FORM);  n++;
  } else {
    XtSetArg(wargs[n], XmNtopAttachment, XmATTACH_WIDGET);  n++;
    XtSetArg(wargs[n], XmNtopWidget, bar);  n++;
    XtSetArg(wargs[n], XmNleftAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNrightAttachment, XmATTACH_FORM);  n++;
    XtSetArg(wargs[n], XmNbottomAttachment, XmATTACH_FORM);  n++;
  }
  value = XmCreateLabel(form, VALUE_NAME, wargs, n);
  XmStringFree(cs);
  /* reset the label back to the min value */
  sprintf(digit, "%d", minValue);
  cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
  n = 0;
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetValues(value, wargs, n);
  XmStringFree(cs);
  XtManageChild(value);

  /* allocate and init the callback structure */
  cbp = (BarChartChildData *) se_alloc(sizeof(BarChartChildData));
  cbp->label    = label;
  cbp->value    = value;
  cbp->upper    = upper;
  cbp->lower    = lower;
  cbp->bar      = bar;

  /* spool this away for later use */
  ((BarChartWidget) bar)->bar_chart.bc_data = cbp;
  ((BarChartWidget) bar)->bar_chart.is_chart = 1;

  /* add the update function */
  if (update)
    XtAddCallback(bar, XtNgetValue, update_value, (XtPointer) cbp);

  se_free(wargs);

  return form;
}

static void
update_value(Widget w, XtPointer client_data, XtPointer call_data)
{
  char *label;
  char digit[16];
  int n;
  int minValue;
  int maxValue;
  XmString cs;
  XmString new_cs;
  BarChartChildData *cbp = (BarChartChildData *) client_data;
  Arg args[8];

  /* set the label */
  n = 0;
  XtSetArg(args[n], XmNlabelString, &cs);  n++;
  XtGetValues(cbp->value, args, n);
  sprintf(digit, "%d", *((int *) call_data));
  new_cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
  if (XmStringCompare(cs, new_cs) == False) {
    n = 0;
    XtSetArg(args[n], XmNlabelString, new_cs);  n++;
    XtSetValues(cbp->value, args, n);
  }
  XmStringFree(cs);
  XmStringFree(new_cs);

  /* get the min and max values from the bar */
  n = 0;
  XtSetArg(args[n], XtNminValue, &minValue);  n++;
  XtSetArg(args[n], XtNmaxValue, &maxValue);  n++;
  XtGetValues(w, args, n);

  /* get the label string from lower */
  n = 0;
  XtSetArg(args[n], XmNlabelString, &cs);  n++;
  XtGetValues(cbp->lower, args, n);
  XmStringGetLtoR(cs, XmFONTLIST_DEFAULT_TAG, &label);
  XmStringFree(cs);

  /* if it's different, change it */
  sprintf(digit, "%d", minValue);
  if (strcmp(digit, label)) {
    cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
    n = 0;
    XtSetArg(args[n], XmNlabelString, cs);  n++;
    XtSetValues(cbp->lower, args, n);
    XmStringFree(cs);
  }
  /* don't se_free this, it was allocated by the widget with XtMalloc */
  XtFree(label);

  /* get the label string from upper */
  n = 0;
  XtSetArg(args[n], XmNlabelString, &cs);  n++;
  XtGetValues(cbp->upper, args, n);
  XmStringGetLtoR(cs, XmFONTLIST_DEFAULT_TAG, &label);
  XmStringFree(cs);

  /* if it's different, change it */
  sprintf(digit, "%d", maxValue);
  if (strcmp(digit, label)) {
    cs = XmStringCreateLtoR(digit, XmFONTLIST_DEFAULT_TAG);
    XtSetArg(args[n], XmNlabelString, cs);  n++;
    XtSetValues(cbp->upper, args, n);
    XmStringFree(cs);
  }
  /* don't se_free this, it was allocated by the widget with XtMalloc */
  XtFree(label);
}

Widget
XtBarChartGetChild(Widget parent, BarChartChildName which)
{
  switch(which) {
  case BC_LABEL_CHILD:
    return XtNameToWidget(parent, LABEL_NAME);
  case BC_VALUE_CHILD:
    return XtNameToWidget(parent, VALUE_NAME);
  case BC_UPPER_CHILD:
    return XtNameToWidget(parent, UPPER_NAME);
  case BC_LOWER_CHILD:
    return XtNameToWidget(parent, LOWER_NAME);
  case BC_BAR_CHILD:
    return XtNameToWidget(parent, BAR_NAME);
  default:
    return 0;
  }
}
