/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _BAR_CHART_H_
#define _BAR_CHART_H_

#include <X11/Xmu/Converters.h>

/***********************************************************************
 *
 * BarChart Widget
 *
 ***********************************************************************/

/* BarChart resources:

 Name                Class              RepType         Default Value
 ----                -----              -------         -------------
 accelerators        Accelerators       AcceleratorTable NULL
 ancestorSensitive   AncestorSensitive  Boolean         True 
 background          Background         Pixel           XtDefaultBackground
 backgroundPixmap    Pixmap             Pixmap          XtUnspecifiedPixmap
 borderColor         BorderColor        Pixel           XtDefaultForeground
 borderPixmap        Pixmap             Pixmap          XtUnspecifiedPixmap
 borderWidth         BorderWidth        Dimension       1
 colormap            Colormap           Colormap        parent's colormap
 cursor              Cursor             Cursor          None
 cursorName          Cursor             String          NULL
 depth               Depth              int             parent's depth
 destroyCallback     Callback           XtCallbackList  NULL
 foreground          Foreground         Pixel           XtDefaultForeground
 getValue            Callback           XtCallbackList  NULL
 height              Height             Dimension       120
 insensitiveBorder   Insensitive        Pixmap          GreyPixmap
 label               Label              String          "BarChart"
 mappedWhenManaged   MappedWhenManaged  Boolean         True
 maxValue            Scale              int             100
 minValue            Scale              int             0
 orientation         Orientation        XtOrientation   horizontal
 pointerColor        Foreground         Pixel           XtDefaultForeground
 pointerColorBackground Background      Pixel           XtDefaultBackground
 screen              Screen             Screen          parent's screen
 sensitive           Sensitive          Boolean         True
 translations        Translations       TranslationTable NULL
 update              Interval           int             0 (seconds)
 value               Scale              int             0
 width               Width              Dimension       120
 x                   Position           Position        0
 y                   Position           Position        0

*/

#ifndef _XtStringDefs_h_
#define XtNupdate   "update"
#endif

#define XtNminValue "minValue"
#define XtNmaxValue "maxValue"
#define XtNgetValue "getValue"

#define XtCScale    "Scale"

/* names for XtBarChartGetChild() */
typedef enum {
  BC_LABEL_CHILD,
  BC_VALUE_CHILD,
  BC_UPPER_CHILD,
  BC_LOWER_CHILD,
  BC_BAR_CHILD
} BarChartChildName;
 
typedef struct _BarChartRec *BarChartWidget;
typedef struct _BarChartClassRec *BarChartWidgetClass;

extern WidgetClass barChartWidgetClass;

extern Widget XtCreateBar(Widget, char *, ArgList, Cardinal);
extern Widget XtCreateBarChart(Widget, char *, ArgList, Cardinal);
extern Widget XtBarChartGetChild(Widget, BarChartChildName);

#endif
