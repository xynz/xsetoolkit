/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/* $XConsortium: PointChart.c,v 1.25 94/04/17 20:12:56 kaleb Exp $ */

/***********************************************************

Copyright (c) 1987, 1988, 1994  X Consortium

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT.  IN NO EVENT SHALL THE
X CONSORTIUM BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN
AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

Except as contained in this notice, the name of the X Consortium shall not be
used in advertising or otherwise to promote the sale, use or other dealings
in this Software without prior written authorization from the X Consortium.


Copyright 1987, 1988 by Digital Equipment Corporation, Maynard, Massachusetts.

                        All Rights Reserved

Permission to use, copy, modify, and distribute this software and its 
documentation for any purpose and without fee is hereby granted, 
provided that the above copyright notice appear in all copies and that
both that copyright notice and this permission notice appear in 
supporting documentation, and that the name of Digital not be
used in advertising or publicity pertaining to distribution of the
software without specific, written prior permission.  

DIGITAL DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING
ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO EVENT SHALL
DIGITAL BE LIABLE FOR ANY SPECIAL, INDIRECT OR CONSEQUENTIAL DAMAGES OR
ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS,
WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION,
ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS
SOFTWARE.

******************************************************************/

/* necessary to get the intrinsics to shut up */
#define XT_REVISION 5

#include <stdio.h>
#include <X11/IntrinsicP.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/XawInit.h>
#include "PointCharP.h"
#include <X11/Xfuncs.h>

#define MS_PER_SEC 1000
#define ABS(X) (((X) < 0) ? ((X) * -1) : (X))

/* Private Data */

#define offset(field) XtOffsetOf(PointChartRec, field)

static XtResource resources[] = {
    {XtNwidth, XtCWidth, XtRDimension, sizeof(Dimension),
	offset(core.width), XtRImmediate, (XtPointer) 120},
    {XtNheight, XtCHeight, XtRDimension, sizeof(Dimension),
	offset(core.height), XtRImmediate, (XtPointer) 120},
    {XtNupdate, XtCInterval, XtRInt, sizeof(int),
        offset(point_chart.update), XtRImmediate, (XtPointer) 10},
    {XtNminScale, XtCScale, XtRInt, sizeof(int),
        offset(point_chart.min_scale), XtRImmediate, (XtPointer) 1},
    {XtNforeground, XtCForeground, XtRPixel, sizeof(Pixel),
        offset(point_chart.fgpixel), XtRString, XtDefaultForeground},
    {XtNhighlight, XtCForeground, XtRPixel, sizeof(Pixel),
        offset(point_chart.hipixel), XtRString, XtDefaultForeground},
    {XtNgetValue, XtCCallback, XtRCallback, sizeof(XtPointer),
        offset(point_chart.get_value), XtRImmediate, (XtPointer) NULL},
    {XtNjumpScroll, XtCJumpScroll, XtRInt, sizeof(int),
        offset(point_chart.jump_val), XtRImmediate, (XtPointer) DEFAULT_JUMP},
};

#undef offset

static void Initialize(), Destroy(), Redisplay(), MoveChart(), SetPoints();
static Boolean SetValues();
static int repaint_window();

PointChartClassRec pointChartClassRec = {
    { /* core fields */
    /* superclass		*/	(WidgetClass) &simpleClassRec,
    /* class_name		*/	"PointChart",
    /* size			*/	sizeof(PointChartRec),
    /* class_initialize		*/	XawInitializeWidgetSet,
    /* class_part_initialize	*/	NULL,
    /* class_inited		*/	FALSE,
    /* initialize		*/	Initialize,
    /* initialize_hook		*/	NULL,
    /* realize			*/	XtInheritRealize,
    /* actions			*/	NULL,
    /* num_actions		*/	0,
    /* resources		*/	resources,
    /* num_resources		*/	XtNumber(resources),
    /* xrm_class		*/	NULLQUARK,
    /* compress_motion		*/	TRUE,
    /* compress_exposure	*/	XtExposeCompressMultiple |
	                                XtExposeGraphicsExposeMerged,
    /* compress_enterleave	*/	TRUE,
    /* visible_interest		*/	FALSE,
    /* destroy			*/	Destroy,
    /* resize			*/	SetPoints,
    /* expose			*/	Redisplay,
    /* set_values		*/	SetValues,
    /* set_values_hook		*/	NULL,
    /* set_values_almost	*/	NULL,
    /* get_values_hook		*/	NULL,
    /* accept_focus		*/	NULL,
    /* version			*/	XtVersion,
    /* callback_private		*/	NULL,
    /* tm_table			*/	NULL,
    /* query_geometry		*/	XtInheritQueryGeometry,
    /* display_accelerator	*/	XtInheritDisplayAccelerator,
    /* extension		*/	NULL
    },
    { /* Simple class fields */
    /* change_sensitive		*/	XtInheritChangeSensitive
    }
};

WidgetClass pointChartWidgetClass = (WidgetClass) &pointChartClassRec;

/****************************************************************
 *
 * Private Procedures
 *
 ****************************************************************/

static void draw_it();

/*	Function Name: CreateGC
 *	Description: Creates the GC's
 *	Arguments: w - the point chart widget.
 *                 which - which GC's to create.
 *	Returns: none
 */

static void
CreateGC(w, which)
PointChartWidget w;
unsigned int which;
{
  XGCValues	myXGCV;

  if (which & FOREGROUND) {
    myXGCV.foreground = w->point_chart.fgpixel;
    w->point_chart.fgGC = XtGetGC((Widget) w, GCForeground, &myXGCV);
  }

  if (which & HIGHLIGHT) {
    myXGCV.foreground = w->point_chart.hipixel;
    w->point_chart.hiGC = XtGetGC((Widget) w, GCForeground, &myXGCV);
  }
}

/*	Function Name: DestroyGC
 *	Description: Destroys the GC's
 *	Arguments: w - the point chart widget.
 *                 which - which GC's to destroy.
 *	Returns: none
 */

static void
DestroyGC(w, which)
PointChartWidget w;
unsigned int which;
{
  if (which & FOREGROUND) 
    XtReleaseGC((Widget) w, w->point_chart.fgGC);

  if (which & HIGHLIGHT) 
    XtReleaseGC((Widget) w, w->point_chart.hiGC);
}

/* ARGSUSED */
static void Initialize (greq, gnew, args, num_args)
    Widget greq, gnew;
    ArgList args;
    Cardinal *num_args;
{
    PointChartWidget w = (PointChartWidget)gnew;

    if (w->point_chart.update > 0)
        w->point_chart.interval_id = XtAppAddTimeOut( 
					XtWidgetToApplicationContext(gnew),
					w->point_chart.update * MS_PER_SEC, 
					draw_it, (XtPointer) gnew);
    CreateGC(w, (unsigned int) ALL_GCS);

    w->point_chart.scale = w->point_chart.min_scale;
    w->point_chart.interval = 0;
    w->point_chart.max_value = 0.0;
    w->point_chart.points = NULL;
    SetPoints((Widget) w);
}
 
static void Destroy (gw)
     Widget gw;
{
     PointChartWidget w = (PointChartWidget)gw;

     if (w->point_chart.update > 0)
         XtRemoveTimeOut (w->point_chart.interval_id);
     if (w->point_chart.points)
	 XtFree((char *) w->point_chart.points);
     DestroyGC(w, (unsigned int) ALL_GCS);
}

/*
 * NOTE: This function really needs to recieve graphics exposure 
 *       events, but since this is not easily supported until R4 I am
 *       going to hold off until then.
 */

/* ARGSUSED */
static void Redisplay(w, event, region)
     Widget w;
     XEvent *event;
     Region region;
{
    if (event->type == GraphicsExpose)
	(void) repaint_window ((PointChartWidget)w, event->xgraphicsexpose.x,
			       event->xgraphicsexpose.width);
    else
	(void) repaint_window ((PointChartWidget)w, event->xexpose.x,
			       event->xexpose.width);
}

/* ARGSUSED */
static void 
draw_it(client_data, id)
XtPointer client_data;
XtIntervalId *id;		/* unused */
{
   PointChartWidget w = (PointChartWidget)client_data;
   double value;
   
   if (w->point_chart.update > 0)
       w->point_chart.interval_id =
       XtAppAddTimeOut(XtWidgetToApplicationContext( (Widget) w),
		       w->point_chart.update * MS_PER_SEC,draw_it,client_data);

   if (w->point_chart.interval >= (int)w->core.width)
       MoveChart( (PointChartWidget) w, TRUE);

   /* Get the value, stash the point and draw corresponding line. */

   if (w->point_chart.get_value == NULL)
       return;

   XtCallCallbacks( (Widget)w, XtNgetValue, (XtPointer)&value );

   /* 
    * Keep w->point_chart.max_value up to date, and if this data 
    * point is off the graph, change the scale to make it fit. 
    */
   
   if (value > w->point_chart.max_value) {
       w->point_chart.max_value = value;
       if (XtIsRealized((Widget)w) && 
	   w->point_chart.max_value > w->point_chart.scale) {
	   XClearWindow( XtDisplay (w), XtWindow (w));
	   w->point_chart.interval = repaint_window(w, 0, (int) w->core.width);
       }
   }

   w->point_chart.valuedata[w->point_chart.interval] = value;
   if (XtIsRealized((Widget)w)) {
       int y = (int) (w->core.height
		      - (int)(w->core.height * value) / w->point_chart.scale);
       int last_y;
       double v;

       if (w->point_chart.interval > 0) {
         v = w->point_chart.valuedata[w->point_chart.interval - 1];
         last_y = (int) (w->core.height
                - (int) (w->core.height * v) / w->point_chart.scale);
       }

       if ((w->point_chart.interval == 0) || (ABS(last_y - y) < 2))
         XDrawPoint(XtDisplay(w), XtWindow(w), w->point_chart.fgGC,
                    w->point_chart.interval, y);
       else
         XDrawLine(XtDisplay(w), XtWindow(w), w->point_chart.fgGC,
                    w->point_chart.interval - 1, last_y,
                    w->point_chart.interval, y);
       /*
	* Fill in the graph lines we just painted over.
	*/

       if (w->point_chart.points != NULL) {
	   w->point_chart.points[0].x = w->point_chart.interval;
	   XDrawPoints(XtDisplay(w), XtWindow(w), w->point_chart.hiGC,
		       w->point_chart.points, w->point_chart.scale - 1,
		       CoordModePrevious);
       }

       XFlush(XtDisplay(w));		    /* Flush output buffers */
   }
   w->point_chart.interval++;		    /* Next point */
} /* draw_it */

/* Blts data according to current size, then redraws the pointChart window.
 * Next represents the number of valid points in data.  Returns the (possibly)
 * adjusted value of next.  If next is 0, this routine draws an empty window
 * (scale - 1 lines for graph).  If next is less than the current window width,
 * the returned value is identical to the initial value of next and data is
 * unchanged.  Otherwise keeps half a window's worth of data.  If data is
 * changed, then w->point_chart.max_value is updated to reflect the
 * largest data point.
 */

static int 
repaint_window(w, left, width)
PointChartWidget w;
int left, width;
{
    int i, j;
    int next = w->point_chart.interval;
    int scale = w->point_chart.scale;
    int scalewidth = 0;
    int last_y;

    /* Compute the minimum scale required to graph the data, but don't go
       lower than min_scale. */
    if (w->point_chart.interval != 0 || scale <= (int)w->point_chart.max_value)
      scale = ((int) (w->point_chart.max_value)) + 1;
    if (scale < w->point_chart.min_scale)
      scale = w->point_chart.min_scale;

    if (scale != w->point_chart.scale) {
      w->point_chart.scale = scale;
      left = 0;
      width = next;
      scalewidth = w->core.width;

      SetPoints((Widget) w);

      if (XtIsRealized ((Widget) w)) 
	XClearWindow (XtDisplay (w), XtWindow (w));

    }

    if (XtIsRealized((Widget)w)) {
	Display *dpy = XtDisplay(w);
	Window win = XtWindow(w);

	width += left - 1;
	if (!scalewidth) scalewidth = width;

	if (next < ++width) width = next;

	/* Draw data point lines. */
	for (i = left; i < width; i++) {
	    int y = (int) (w->core.height -
			   (int)(w->core.height * w->point_chart.valuedata[i]) /
			   w->point_chart.scale);

            if ((i == left) || (ABS(last_y - y) < 2))
	      XDrawPoint(dpy, win, w->point_chart.fgGC, i, y);
            else
	      XDrawLine(dpy, win, w->point_chart.fgGC, i - 1, last_y, i, y);
            last_y = y;
	}

	/* Draw graph reference lines */
	for (i = 1; i < w->point_chart.scale; i++) {
	    j = i * ((int)w->core.height / w->point_chart.scale);
	    XDrawLine(dpy, win, w->point_chart.hiGC, left, j, scalewidth, j);
	}
    }
    return(next);
}

/*	Function Name: MoveChart
 *	Description: moves the chart over when it would run off the end.
 *	Arguments: w - the load widget.
 *                 blit - blit the bits? (TRUE/FALSE).
 *	Returns: none.
 */

static void
MoveChart(w, blit)
PointChartWidget w;
Boolean blit;
{
    double old_max;
    int left, i, j;
    int next = w->point_chart.interval;

    if (!XtIsRealized((Widget) w)) return;

    if (w->point_chart.jump_val < 0) w->point_chart.jump_val = DEFAULT_JUMP;
    if (w->point_chart.jump_val == DEFAULT_JUMP)
        j = w->core.width >> 1; /* Half the window width. */
    else {
        j = w->core.width - w->point_chart.jump_val;
	if (j < 0) j = 0;
    }

    (void) memmove((char *)(w->point_chart.valuedata), 
		   (char *)(w->point_chart.valuedata + next - j),
		   j * sizeof(double));
    next = w->point_chart.interval = j;
	
    /*
     * Since we just lost some data, recompute the 
     * w->point_chart.max_value. 
     */

    old_max = w->point_chart.max_value;
    w->point_chart.max_value = 0.0;
    for (i = 0; i < next; i++) {
      if (w->point_chart.valuedata[i] > w->point_chart.max_value) 
	w->point_chart.max_value = w->point_chart.valuedata[i];
    }

    if (!blit) return;		/* we are done... */

    if ( ((int) old_max) != ( (int) w->point_chart.max_value) ) {
      XClearWindow(XtDisplay(w), XtWindow(w));
      repaint_window(w, 0, (int) w->core.width);
      return;
    }

    XCopyArea(XtDisplay((Widget)w), XtWindow((Widget)w), XtWindow((Widget)w),
	      w->point_chart.hiGC, (int) w->core.width - j, 0,
	      (unsigned int) j, (unsigned int) w->core.height,
	      0, 0);

    XClearArea(XtDisplay((Widget)w), XtWindow((Widget)w), 
	       (int) j, 0, 
	       (unsigned int) w->core.width - j, (unsigned int)w->core.height,
	       FALSE);

    /* Draw graph reference lines */
    left = j;
    for (i = 1; i < w->point_chart.scale; i++) {
      j = i * ((int)w->core.height / w->point_chart.scale);
      XDrawLine(XtDisplay((Widget) w), XtWindow( (Widget) w),
		w->point_chart.hiGC, left, j, (int)w->core.width, j);
    }
    return;
}

/* ARGSUSED */
static Boolean SetValues (current, request, new, args, num_args)
    Widget current, request, new;
    ArgList args;
    Cardinal *num_args;
{
    PointChartWidget old = (PointChartWidget)current;
    PointChartWidget w = (PointChartWidget)new;
    Boolean ret_val = FALSE;
    unsigned int new_gc = NO_GCS;

    if (w->point_chart.update != old->point_chart.update) {
	if (old->point_chart.update > 0)
	    XtRemoveTimeOut (old->point_chart.interval_id);
	if (w->point_chart.update > 0)
	    w->point_chart.interval_id =
		XtAppAddTimeOut(XtWidgetToApplicationContext(new),
				w->point_chart.update * MS_PER_SEC,
				draw_it, (XtPointer)w);
    }

    if ( w->point_chart.min_scale > (int) ((w->point_chart.max_value) + 1) )
      ret_val = TRUE;
     
    if ( w->point_chart.fgpixel != old->point_chart.fgpixel ) {
      new_gc |= FOREGROUND;
      ret_val = True;
    }
    
    if ( w->point_chart.hipixel != old->point_chart.hipixel ) {
      new_gc |= HIGHLIGHT;
      ret_val = True;
    }
    
    DestroyGC(old, new_gc);
    CreateGC(w, new_gc);

    return( ret_val );
}

/*	Function Name: SetPoints
 *	Description: Sets up the polypoint that will be used to draw in
 *                   the graph lines.
 *	Arguments: w - the PointChart widget.
 *	Returns: none.
 */

#define HEIGHT ( (unsigned int) w->core.height)

static void
SetPoints(widget)
Widget widget;
{
    PointChartWidget w = (PointChartWidget) widget;
    XPoint * points;
    Cardinal size;
    int i;

    if (w->point_chart.scale <= 1) { /* no scale lines. */
	XtFree ((char *) w->point_chart.points);
	w->point_chart.points = NULL;
	return;
    }
    
    size = sizeof(XPoint) * (w->point_chart.scale - 1);

    points = (XPoint *) XtRealloc( (XtPointer) w->point_chart.points, size);
    w->point_chart.points = points;

    /* Draw graph reference lines into clip mask */

    for (i = 1; i < w->point_chart.scale; i++) {
	points[i - 1].x = 0;
	points[i - 1].y = HEIGHT / w->point_chart.scale;
    }
}
