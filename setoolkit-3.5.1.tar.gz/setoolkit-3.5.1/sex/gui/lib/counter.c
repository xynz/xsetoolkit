/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/Label.h>
#include <Xm/ArrowB.h>
#include <Xm/PushB.h>
#include "gui.h"

static Boolean workProc(XtPointer);
static void down_arrow_arm(Widget, XtPointer, XtPointer);
static void up_arrow_arm(Widget, XtPointer, XtPointer);
static void down_arrow_disarm(Widget, XtPointer, XtPointer);
static void up_arrow_disarm(Widget, XtPointer, XtPointer);

Widget
gui_create_counter(Widget parent, member_t *mp)
{
  char text[128];
  char *fields[8];
  int n;
  int minimum;
  int maximum;
  int initial;
  int arg_count;
  Arg wargs[16];
  cd_t *cdp;
  XmString cs;

  /* parse data for min, max, and initial */
  minimum = 1;
  minimum = 100;
  initial = 1;
  if (mp->m_data) {
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      minimum = atoi(fields[0]);
    if (fields[1])
      maximum = atoi(fields[1]);
    if (minimum >= maximum) {
      minimum = 1;
      maximum = 100;
      XtWarningMsg("Warning", "RangeConstraint", "Constraint",
                   "Minimum Value >= Maximum Value", 0, 0);
    }
    if (fields[2])
      initial = atoi(fields[2]);
  }
  /* set the foreground and background for everything */
  n = 0;
  XtSetArg(wargs[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
  XtSetArg(wargs[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
  XtSetArg(wargs[n], XmNfontList, Gui_AppData.mediumFont);  n++;
  arg_count = n;

  /* se_alloc and set up a new call data structure */
  cdp = (cd_t *) se_alloc(sizeof(cd_t));
  if (cdp == 0) {
    perror("gui_create_counter: se_alloc");
    exit(1);
  }
  cdp->c_button_state = GuiINACTIVE;
  cdp->c_minimum = minimum;
  cdp->c_maximum = maximum;

  /* build the row column parent */
  n = arg_count;
  XtSetArg(wargs[n], XmNorientation, XmHORIZONTAL);  n++;
  cdp->c_row_column = XmCreateRowColumn(parent, "arrows", wargs, n);
 
  /* the label */
  n = arg_count;
  cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  cdp->c_label = XmCreateLabel(cdp->c_row_column, "label", wargs, n);
  XtManageChild(cdp->c_label);
  XmStringFree(cs);

  /* the down arrow */
  n = arg_count;
  XtSetArg(wargs[n], XmNwidth, 20);  n++;
  XtSetArg(wargs[n], XmNarrowDirection, XmARROW_DOWN);  n++;
  XtSetArg(wargs[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  cdp->c_down_arrow =
    XmCreateArrowButton(cdp->c_row_column, "downArrow", wargs, n);
  XtManageChild(cdp->c_down_arrow);

  /* arm and disarm callbacks for the arrows */
  XtAddCallback(cdp->c_down_arrow, XmNarmCallback, down_arrow_arm, cdp);
  XtAddCallback(cdp->c_down_arrow, XmNdisarmCallback, down_arrow_disarm, cdp);

  /* the counter window */
  n = arg_count;
  sprintf(text, "%d", maximum);
  cs = XmStringCreateLtoR(text, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetArg(wargs[n], XmNrecomputeSize, False);  n++;
  cdp->c_counter = XmCreateLabel(cdp->c_row_column, "counter", wargs, n);
  XtManageChild(cdp->c_counter);
  XmStringFree(cs);
  n = arg_count;
  sprintf(text, "%d", initial);
  cs = XmStringCreateLtoR(text, XmFONTLIST_DEFAULT_TAG);
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetValues(cdp->c_counter, wargs, n);
 
  /* the up arrow */
  n = arg_count;
  XtSetArg(wargs[n], XmNwidth, 20);  n++;
  XtSetArg(wargs[n], XmNarrowDirection, XmARROW_UP);  n++;
  XtSetArg(wargs[n], XmNhighlightThickness, GuiHIGHLIGHT_THICKNESS);  n++;
  cdp->c_up_arrow =
    XmCreateArrowButton(cdp->c_row_column, "upArrow", wargs, n);
  XtManageChild(cdp->c_up_arrow);
 
  /* arm and disarm callbacks for the arrows */
  XtAddCallback(cdp->c_up_arrow, XmNarmCallback, up_arrow_arm, cdp);
  XtAddCallback(cdp->c_up_arrow, XmNdisarmCallback, up_arrow_disarm, cdp);
 
  /* activate callbacks for users */
  if (mp->m_callback) {
    XtAddCallback(cdp->c_down_arrow, XmNactivateCallback, gui_cb_cb, mp);
    XtAddCallback(cdp->c_up_arrow,   XmNactivateCallback, gui_cb_cb, mp);
  }

  /* done */
  mp->m_wdata = cdp;
  return cdp->c_row_column;
}

#ifndef _SOLARIS
/* this is as hr as I'm gonna get */
hrtime_t gethrtime(void)
{
  struct timeval tv;

  gettimeofday(&tv, 0);
  return (tv.tv_sec * 1000000) + tv.tv_usec;
}
#endif

static Boolean
workProc(XtPointer client_data)
{
  cd_t *cdp = (cd_t *) client_data;
  hrtime_t now = gethrtime();
  hrtime_t diff = now - cdp->c_timestamp;

  switch(cdp->c_button_state) {
  case GuiINACTIVE:
    cdp->c_timestamp = now;
    return True;
  case GuiDOWN_ARMED:
    if (diff >= GuiPAUSE_INTERVAL) {
      down_arrow_arm(cdp->c_up_arrow, (XtPointer) cdp, 0);
      cdp->c_timestamp = now;
    }
    return False;
  case GuiUP_ARMED:
    if (diff >= GuiPAUSE_INTERVAL) {
      up_arrow_arm(cdp->c_down_arrow, (XtPointer) cdp, 0);
      cdp->c_timestamp = now;
    }
    return False;
  }
}

static void
down_arrow_arm(Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg wargs[2];
  int n;
  char *text = 0;
  char new_text[32];
  XmString cs = 0;
  cd_t *cdp = (cd_t *) client_data;

  n = 0;
  XtSetArg(wargs[n], XmNlabelString, &cs);  n++;
  XtGetValues(cdp->c_counter, wargs, n);
  XmStringGetLtoR(cs, XmFONTLIST_DEFAULT_TAG, &text);
  n = atoi(text);
  if (n > cdp->c_minimum)
    sprintf(new_text, "%d", n - 1);
  else
    strcpy(new_text, text);
  cs = XmStringCreateLtoR(new_text, XmFONTLIST_DEFAULT_TAG);
  n = 0;
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetValues(cdp->c_counter, wargs, n);
  XmStringFree(cs);
  if (cdp->c_button_state != GuiDOWN_ARMED) {
    cdp->c_button_state = GuiDOWN_ARMED;
    XtAppAddWorkProc(Gui_app, workProc, cdp);
    cdp->c_timestamp = gethrtime();
  }
}

static void
up_arrow_arm(Widget w, XtPointer client_data, XtPointer call_data)
{
  Arg wargs[2];
  int n;
  char *text = 0;
  char new_text[32];
  XmString cs = 0;
  cd_t *cdp = (cd_t *) client_data;

  n = 0;
  XtSetArg(wargs[n], XmNlabelString, &cs);  n++;
  XtGetValues(cdp->c_counter, wargs, n);
  XmStringGetLtoR(cs, XmFONTLIST_DEFAULT_TAG, &text);
  n = atoi(text);
  if (n < cdp->c_maximum)
    sprintf(new_text, "%d", n + 1);
  else
    strcpy(new_text, text);
  cs = XmStringCreateLtoR(new_text, XmFONTLIST_DEFAULT_TAG);
  n = 0;
  XtSetArg(wargs[n], XmNlabelString, cs);  n++;
  XtSetValues(cdp->c_counter, wargs, n);
  XmStringFree(cs);
  if (cdp->c_button_state != GuiUP_ARMED) {
    cdp->c_button_state = GuiUP_ARMED;
    XtAppAddWorkProc(Gui_app, workProc, cdp);
    cdp->c_timestamp = gethrtime();
  }
}

static void
down_arrow_disarm(Widget w, XtPointer client_data, XtPointer call_data)
{
  cd_t *cdp = (cd_t *) client_data;

  cdp->c_button_state = GuiINACTIVE;
}

static void
up_arrow_disarm(Widget w, XtPointer client_data, XtPointer call_data)
{
  cd_t *cdp = (cd_t *) client_data;

  cdp->c_button_state = GuiINACTIVE;
}
