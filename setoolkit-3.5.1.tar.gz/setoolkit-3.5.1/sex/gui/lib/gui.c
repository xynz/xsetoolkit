/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <sys/poll.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Shell.h>
#include <X11/cursorfont.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include "gui.h"
#include "gui_defines.h"
#include "../../../avl.h"
#include "../../../se.h"

static XtResource resources[] = {
  {  GuiNboldFont,   XtCFont,       XmRFontList,  sizeof (XmFontList),
     XtOffset(ApplicationDataPtr,   boldFont), XtRString,   GuiBOLD_FONT     },
  {  GuiNmediumFont, XtCFont,       XmRFontList,  sizeof (XmFontList),
     XtOffset(ApplicationDataPtr,   mediumFont), XtRString, GuiMEDIUM_FONT   },
  {  GuiNtextFont,   XtCFont,       XmRFontList,  sizeof (XmFontList),
     XtOffset(ApplicationDataPtr,   textFont),   XtRString, GuiTEXT_FONT     }
};

static XrmOptionDescRec options[] = {
  { "-bf",    "*boldFont",     XrmoptionSepArg, 0 },
  { "-mf",    "*mediumFont",   XrmoptionSepArg, 0 },
  { "-tf",    "*textFont",     XrmoptionSepArg, 0 }
};

/* forward declarations */
static Boolean cvtStringToFontList(
                 Display *,
                 XrmValue *,
                 Cardinal *,
                 XrmValue *,
                 XrmValue *,
                 XtPointer *);
static void      read_line(XtPointer, int *, XtInputId *);
static Pixmap    create_icon(void);
static member_t *create_shell(char *);
static char     *whereami(char *, int);

/* globals */
ApplicationData Gui_AppData;
Widget Gui_output_window;
Widget Gui_toplevel;
int Gui_script_input;
char *Gui_text = 0;
XtAppContext Gui_app;
unsigned long Gui_loop_interval;

/* static globals */
static member_t gui_frame;

typedef struct _gml_cbd gml_cbd;  /* gui main loop call back data */

struct _gml_cbd {
  char      *callback;
  char      *callback_data;
  XtInputId  id;                /* for use with gui_add_input_source */
  gml_cbd   *next;
};

static gml_cbd *gml_cbd_list = 0;

member_t *
gui_init(int argc, char *argv[])
{
  int i;
  int n;
  Arg args[4];

  n = 0;
  XtSetArg(args[n], XmNwinGravity, ForgetGravity);  n++;
  Gui_toplevel = XtAppInitialize(&Gui_app, "Segui",
    options, XtNumber(options), &argc, argv, 0, args, n);

#if 0
  XtSetTypeConverter(XtRString, XmRFontList,
    (XtTypeConverter) cvtStringToFontList,
    0, 0, XtCacheAll, 0);
#endif

  XtGetApplicationResources(Gui_toplevel, &Gui_AppData, resources,
    XtNumber(resources), 0, 0);

  gui_frame.m_primary = Gui_toplevel;
  gui_frame.m_head = &gui_frame;
  return &gui_frame;
}

void
gui_set_title(member_t *mp, char *title)
{
  if ((mp == 0) || (mp->m_primary == 0))
    return;
  XtVaSetValues(mp->m_primary, XtNtitle, title, 0);
}

static void
input_callback(XtPointer data, int *source, XtInputId *id)
{
  gml_cbd *gcp = (gml_cbd *) data;

  se_function_call(gcp->callback, *source, gcp->callback_data, *id);
}

XtInputId
gui_add_input_source(char *callback, char *callback_data, int source)
{
  gml_cbd *gp;
  XtInputId id;

  if (Gui_app == 0)
    return (XtInputId) -1;

  gp = (gml_cbd *) malloc(sizeof(gml_cbd));
  if (gp == 0)
    return (XtInputId) -1;
  memset(gp, '\0', sizeof(gml_cbd));
  gp->callback = callback;
  gp->callback_data = callback_data;
  if (gml_cbd_list)
    gp->next = gml_cbd_list;
  gml_cbd_list = gp;
  id = XtAppAddInput(Gui_app, source,
                     (XtPointer) XtInputReadMask, input_callback, gp);
  gp->id = id;
  return id;
}

void
gui_remove_input_source(XtInputId id)
{
  gml_cbd *gp;
  gml_cbd *last;

  /* handle case it's the first in the list */
  if (gml_cbd_list && (gml_cbd_list->id == id)) {
    gp = gml_cbd_list;
    gml_cbd_list = gml_cbd_list->next;
    XtRemoveInput(gp->id);
    free(gp);
    return;
  }
  for(last=gml_cbd_list, gp=gml_cbd_list->next; gp; gp=gp->next) {
    if (gp->id == id) {
      last->next = gp->next;
      XtRemoveInput(gp->id);
      free(gp);
      return;
    }
    last = gp;
  }
}

#if 0
static Boolean
cvtStringToFontList(Display *display,
                    XrmValue *args,
                    Cardinal *nargs,
                    XrmValue *fromVal,
                    XrmValue *toVal,
                    XtPointer *converterData)
{
  XFontStruct *fontp;
  static XmFontList xmFontp;

  fontp = XLoadQueryFont(display, fromVal->addr);
  if (fontp == 0)
    return False;
  xmFontp = XmFontListCreate(fontp, XmSTRING_DEFAULT_CHARSET);
  if (xmFontp == 0)
    return False;
  if (toVal->addr) {
    if (toVal->size < sizeof(XmFontList)) {
      toVal->size = sizeof(XmFontList);
      return False;
    }
    *((XmFontList *) toVal->addr) = xmFontp;
  } else
    toVal->addr = (XtPointer) &xmFontp;
  toVal->size = sizeof(XmFontList);
  return True;
}
#endif

static char *
whereami(char *cmd, int first)
{
  static char path[BUFSIZ];
  static char *tmp;
  static char *p;

  if (first && strchr(cmd, '/')) {
    p = strcpy(path, cmd);
    *strrchr(path, '/') = '\0';
  } else {
    if (first) {
      tmp = strdup(getenv("PATH"));
      p = strtok(tmp, ":");
    } else
      p = strtok(0, ":");
    for(; p; p=strtok(0, ":")) {
      sprintf(path, "%s/%s", p, cmd);
      if (access(path, F_OK) == 0)
        break;
    }
    if (p == 0)
      free(tmp);
  }
  return p;
}

static char *
canonicalize_ad(void)
{
  extern char *Se_programName;
  static char path[BUFSIZ];
  char *p;
  int first;

  if (access(DEFAULT_SE_LIB "/app-defaults/Segui", F_OK) != 0) {
    for(first = 1;; first = 0) {
      p = whereami(Se_programName, first);
      if (p == 0)
        break;
      sprintf(path, "%s/../lib/app-defaults/Segui", p);
      if (access(path, F_OK) == 0) {
        *strrchr(path, '/') = '\0';
        *strrchr(path, '/') = '\0';
        return path;
      }
    }
  }
  return DEFAULT_SE_LIB;
}

member_t *
gui_create_frame(int argc, char *argv[], resource_t objects[])
{
  char *p = getenv("XFILESEARCHPATH");
  char buf[BUFSIZ];
  char *ad;
  int i;
  member_t *handle;
  member_t *mp;

  /* I don't *WANT* CDE to change my fonts. */
  ad = canonicalize_ad();
  if (p)
    sprintf(buf, "XFILESEARCHPATH=%s:%s/%%T/%%N%%S", p, ad);
  else
    sprintf(buf, "XFILESEARCHPATH=%s/%%T/%%N%%S", ad);
  putenv(buf);
  handle = gui_init(argc, argv);
  for(i=0; objects[i].r_type != R_END; i++) {
    if (handle->m_tail == 0)
      mp = handle;
    else {
      mp = NEW(member_t);
      mp->m_head = handle;
    }
    mp->m_type = objects[i].r_type;
    mp->m_foreground = objects[i].r_foreground;
    mp->m_background = objects[i].r_background;
    mp->m_label = se_string_save(objects[i].r_label);
    mp->m_data = se_string_save(objects[i].r_data);
    mp->m_callback = se_string_save(objects[i].r_callback);
    mp->m_callback_data = se_string_save(objects[i].r_callback_data);
    if (objects[i].r_container) {
      T_VARIABLE *vp;

      vp = se_get_variable(objects[i].r_container);
      if (vp && (vp->var_type == VAR_REGISTER)) {
        vp->var_un.var_array = (void *) mp;
      }
    }
    if (handle->m_tail == 0)
      handle->m_tail = handle;
    else
      handle->m_tail = handle->m_tail->m_next = mp;
    if (mp->m_data) {
      /* pull embedded variables from the structure */
      uchar_t *area;
      T_VARIABLE *vp;

      switch(mp->m_type) {
      case R_MENUBAR:
      case R_VRADIOBOX:
      case R_HRADIOBOX:
      case R_ROW:
      case R_COLUMN:
      case R_CASCADE:
      case R_VPANED:
      case R_HPANED:
        vp = se_get_variable(mp->m_data);
        if (vp == 0)
          break;
        if ((vp->var_type != VAR_USER) ||
             strcmp(vp->var_struct->st_name, "resource_t"))
          break;
        area = se_struct_into_area(vp, 0);
        gui_add_group(mp, (resource_t *) area);
        se_free(area);
        break;
      case R_GROUP:
      case R_BGROUP:
      case R_LGROUP:
        /* these have data in m_data, via gui_group_data() macro */
      default:
        break;
      }
    }
  }
  return handle;
}

member_t *
gui_create_subframe(char *title, resource_t objects[])
{
  int i;
  member_t *handle;
  member_t *mp;

  handle = create_shell(title);
  for(i=0; objects[i].r_type != R_END; i++) {
    if (handle->m_tail == 0)
      mp = handle;
    else {
      mp = NEW(member_t);
      mp->m_head = handle;
    }
    mp->m_type = objects[i].r_type;
    mp->m_foreground = objects[i].r_foreground;
    mp->m_background = objects[i].r_background;
    mp->m_label = se_string_save(objects[i].r_label);
    mp->m_data = se_string_save(objects[i].r_data);
    mp->m_callback = se_string_save(objects[i].r_callback);
    mp->m_callback_data = se_string_save(objects[i].r_callback_data);
    if (objects[i].r_container) {
      T_VARIABLE *vp;

      vp = se_get_variable(objects[i].r_container);
      if (vp && (vp->var_type == VAR_REGISTER))
        vp->var_un.var_array = (void *) mp;
    }
    if (handle->m_tail == 0)
      handle->m_tail = handle;
    else
      handle->m_tail = handle->m_tail->m_next = mp;
    if (mp->m_data) {
      /* pull embedded variables from the structure */
      uchar_t *area;
      T_VARIABLE *vp;

      switch(mp->m_type) {
      case R_GROUP:
      case R_BGROUP:
      case R_LGROUP:
      case R_MENUBAR:
      case R_VRADIOBOX:
      case R_HRADIOBOX:
      case R_ROW:
      case R_COLUMN:
      case R_CASCADE:
      case R_VPANED:
      case R_HPANED:
        vp = se_get_variable(mp->m_data);
        if (vp == 0)
          break;
        if ((vp->var_type != VAR_USER) ||
             strcmp(vp->var_struct->st_name, "resource_t"))
          break;
        area = se_struct_into_area(vp, 0);
        gui_add_group(mp, (resource_t *) area);
        se_free(area);
        break;
      default:
        break;
      }
    }
  }
  return handle;
}

void
gui_clear_list_items(member_t *handle)
{
  char **pp;
  int i;
  int n;
  member_t *mp;

  /* hahaha, you're a real card */
  if (handle == 0)
    return;
  /* no list there yet */
  if (handle->m_agg_head == 0)
    return;
  mp = handle->m_agg_head;
  pp = (char **) mp->m_data;
  n = (int) (long) mp->m_wdata;
  for(i=0; i<n; i++)
    se_free(pp[i]);
  se_free(mp->m_data);
  mp->m_data = 0;
  mp->m_wdata = 0;
}

void
gui_add_list_items(member_t *handle, char **items, int nitems)
{
  char **pp;
  int i;
  int n;
  member_t *mp;

  if (handle == 0)
    return;
  /* if the list is already there, then this is an update */
  if (handle->m_agg_head) {
    mp = handle->m_agg_head;
    n = nitems + (int) (long) mp->m_wdata;
  } else {
    mp = NEW(member_t);
    n = nitems;
  }
  /* how much space do I need? */
  n *= sizeof(char *);

  /* if it's already there, then realloc it */
  if (mp->m_data) {
    mp->m_data = (char *) realloc(mp->m_data, n);
    if (mp->m_data == 0) {
      perror("gui_add_list_items: realloc");
      exit(1);
    }
  } else
    mp->m_data = (char *) se_alloc(n);

  /* point to the list */
  pp = (char **) mp->m_data;

  /* copy into the array */
  for(i=0; i<nitems; i++)
    pp[ ((int) (long) mp->m_wdata) + i] = se_string_save(items[i]);

  /* flag how many in the list inside of the mp node */
  mp->m_wdata = (void *) (n / sizeof(char *));
  handle->m_agg_head = mp;
}

void
gui_add_group(member_t *handle, resource_t subobjects[])
{
  int i;
  member_t *mp;

  if (handle == 0)
    return;
  for(i=0; subobjects[i].r_type != R_END; i++) {
    mp = NEW(member_t);
    mp->m_type = subobjects[i].r_type;
    mp->m_head = handle;
    mp->m_foreground = subobjects[i].r_foreground;
    mp->m_background = subobjects[i].r_background;
    mp->m_label = se_string_save(subobjects[i].r_label);
    mp->m_data = se_string_save(subobjects[i].r_data);
    mp->m_callback = se_string_save(subobjects[i].r_callback);
    mp->m_callback_data = se_string_save(subobjects[i].r_callback_data);
    if (subobjects[i].r_container) {
      T_VARIABLE *vp;

      vp = se_get_variable(subobjects[i].r_container);
      if (vp && (vp->var_type == VAR_REGISTER)) {
        vp->var_un.var_array = (void *) mp;
      }
    }
    if (handle->m_agg_head == 0)
      handle->m_agg_head = handle->m_agg_tail = mp;
    else
      handle->m_agg_tail = handle->m_agg_tail->m_next = mp;

    if (mp->m_data) {
      /* pull embedded variables from the structure */
      uchar_t *area;
      T_VARIABLE *vp;

      switch(mp->m_type) {
      case R_GROUP:
      case R_BGROUP:
      case R_LGROUP:
      case R_MENUBAR:
      case R_VRADIOBOX:
      case R_HRADIOBOX:
      case R_ROW:
      case R_COLUMN:
      case R_CASCADE:
      case R_VPANED:
      case R_HPANED:
        vp = se_get_variable(mp->m_data);
        if (vp == 0)
          break;
        if ((vp->var_type != VAR_USER) ||
             strcmp(vp->var_struct->st_name, "resource_t"))
          break;
        area = se_struct_into_area(vp, 0);
        gui_add_group(mp, (resource_t *) area);
        se_free(area);
        break;
      default:
        break;
      }
    }
  }
}

void
gui_update_object(member_t *handle, resource_t *mp)
{
  if (handle == 0)
    return;
  handle->m_type = mp->r_type;
  handle->m_foreground = mp->r_foreground;
  handle->m_background = mp->r_background;
  se_new_string(&handle->m_label, mp->r_label);
  se_new_string(&handle->m_data, mp->r_data);
  se_new_string(&handle->m_callback, mp->r_callback);
  se_new_string(&handle->m_callback_data, mp->r_callback_data);
  gui_update_widget(handle);
}

void
gui_update_group(member_t *handle, resource_t subobjects[])
{
  int i;
  member_t *member;

  for(i=0; subobjects[i].r_type != R_END; i++) {
    member = gui_get_object(handle, i);
    gui_update_object(member, &subobjects[i]);
  }
}

static void
timeout_proc(XtPointer data, XtIntervalId *id)
{
  gml_cbd *gcp = (gml_cbd *) data;
  static long last_time;
  long now = time((long *) 0) * 1000;

  /* multiple TimeOuts causing incorrect callback times */
  if ((Gui_loop_interval == 0) ||
     ((now - last_time) < Gui_loop_interval) || (gcp->callback == 0))
    return;
  se_function_call(gcp->callback, &gui_frame, gcp->callback_data, 0);
  XtAppAddTimeOut(Gui_app, Gui_loop_interval, timeout_proc, data);
  last_time = now;
}

void
gui_realize_frame(member_t *frame)
{
  int n;
  int orientation;
  Widget top_panel;
  Arg args[4];

  if (frame == 0)
    return;

  /* already realized? */
  if (frame->m_secondary)
    return;

  orientation = (frame->m_type == R_HFRAME) ? GuiHORIZONTAL : GuiVERTICAL;
  n = 0;
  XtSetArg(args[n], XmNallowOverlap, False);  n++;
  top_panel = XmCreateForm(frame->m_primary, "TopForm", args, n);
  top_panel = gui_create_top_panel(frame, top_panel, orientation);
  frame->m_secondary = top_panel;
  XtManageChild(top_panel);
}

void
gui_main_loop(char *callback, char *callback_data, int interval)
{
  static gml_cbd gc;

  gui_realize_frame(&gui_frame);
  XtRealizeWidget(Gui_toplevel);
  Gui_loop_interval = interval * 1000;
  if (callback) {
    /* the initializing call */
    se_function_call(callback, &gui_frame, callback_data, 0);
    if (interval > 0) {
      gc.callback = callback;
      gc.callback_data = callback_data;
      XtAppAddTimeOut(Gui_app, Gui_loop_interval, timeout_proc, &gc);
    }
  }
  XtAppMainLoop(Gui_app);
}

void
gui_set_loop_interval(char *callback, char *callback_data, int interval)
{
  static gml_cbd gc;

  gc.callback = callback;
  gc.callback_data = callback_data;
  Gui_loop_interval = interval * 1000;
  if (Gui_loop_interval > 0)
    XtAppAddTimeOut(Gui_app, Gui_loop_interval, timeout_proc, &gc);
}

static void
timer_callback(XtPointer data, XtIntervalId *id)
{
  gml_cbd *gcp = (gml_cbd *) data;

  se_function_call(gcp->callback, gcp->callback_data, 0);
  se_free(gcp);
}

void
gui_timer_callback(char *callback, char *callback_data, int interval)
{
  gml_cbd *gcp;

  if (interval <= 0)
    return;
  gcp = NEW(gml_cbd);
  gcp->callback = callback;
  gcp->callback_data = callback_data;
  XtAppAddTimeOut(Gui_app, interval * 1000, timer_callback, gcp);
}

member_t *
gui_get_object(member_t *head, int index)
{
  int i;
  member_t *mp;

  if (head == 0)
    return 0;
  switch(head->m_type) {
  case R_HFRAME:
  case R_VFRAME:
    for(mp=head, i=0; i<index && mp; i++, mp=mp->m_next)
      ;
    return mp;
  case R_GROUP:
  case R_BGROUP:
  case R_LGROUP:
  case R_MENUBAR:
  case R_VRADIOBOX:
  case R_HRADIOBOX:
  case R_ROW:
  case R_COLUMN:
  case R_CASCADE:
  case R_VPANED:
  case R_HPANED:
    for(mp=head->m_agg_head, i=0; i<index && mp; i++, mp=mp->m_next)
      ;
    return mp;
  default:
    fprintf(stderr, "gui_get_object: unknown type: %d\n", head->m_type);
    return 0;
  }
}

static member_t *
create_shell(char *title)
{
  int n;
  Widget toplevel;
  Arg args[16];
  member_t *mp;

  n = 0;
  XtSetArg(args[n], XmNtitle, title);  n++;
  XtSetArg(args[n], XmNdeleteResponse, XmDO_NOTHING);  n++;
  toplevel = XtCreatePopupShell("subframeShell", transientShellWidgetClass,
                                Gui_toplevel, args, n);

  mp = NEW(member_t);
  mp->m_primary = toplevel;
  return mp;
}

void
gui_get_geometry(member_t *frame, int *x, int *y, int *width, int *height)
{
  Position X;
  Position Y;
  Dimension Width;
  Dimension Height;

  if (frame == 0 || frame->m_primary == 0) {
    *x = *y = *width = *height = 0;
    return;
  }
  XtVaGetValues(frame->m_primary,
                XmNx, &X, XmNy, &Y,
                XmNwidth, &Width, XmNheight, &Height, 0);
  *x = (int) X;
  *y = (int) Y;
  *width = (int) Width;
  *height = (int) Height;
}

void
gui_popup_geometry(member_t *frame, int x, int y)
{
  if (XtIsRealized(frame->m_primary) == False) {
    gui_realize_frame(frame);
    XtSetMappedWhenManaged(frame->m_primary, False);
    XtManageChild(frame->m_primary);
    XtVaSetValues(frame->m_primary,
      XmNx, (Position) x, XmNy, (Position) y, 0);
    XtUnmanageChild(frame->m_primary);
    XtSetMappedWhenManaged(frame->m_primary, True);
  } else
    XtVaSetValues(frame->m_primary,
      XmNx, (Position) x, XmNy, (Position) y, 0);
}

void
gui_popup_subframe(member_t *frame)
{
  Position x;
  Position y;
  Dimension height;
  Dimension width;
  Dimension child_height;
  Dimension child_width;

  if (XtIsRealized(frame->m_primary) == False) {
    gui_realize_frame(frame);

    XtSetMappedWhenManaged(frame->m_primary, False);
    XtManageChild(frame->m_primary);
    XtVaGetValues(frame->m_primary, XmNx, &x, XmNy, &y, 0);
    if (x == 0 && y == 0) {
      XtVaGetValues(Gui_toplevel,
        XmNx, &x, XmNy, &y,
        XmNheight, &height, XmNwidth, &width, 0);

      XtVaGetValues(frame->m_primary,
        XmNheight, &child_height, XmNwidth, &child_width, 0);

      x += ((Position) (width - child_width) / 2);
      y += ((Position) (height - child_height) / 2);

      XtVaSetValues(frame->m_primary, XmNx, x, XmNy, y, 0);
    }

    XtSetMappedWhenManaged(frame->m_primary, True);
  } else
    XtManageChild(frame->m_primary);
}

void
gui_popdown_subframe(member_t *frame)
{
  XtUnmanageChild(frame->m_primary);
}

member_t *
gui_get_frame(member_t *handle)
{
  member_t *mp;

  for(mp=handle; XtIsShell(mp->m_primary) == False; mp=mp->m_head)
    ;
  return mp;
}

void
gui_grey_option(member_t *handle, int grey)
{
  XtSetSensitive(handle->m_primary, (grey == 0));
}
