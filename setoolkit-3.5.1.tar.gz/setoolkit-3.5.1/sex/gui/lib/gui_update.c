/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>
#include <X11/Xaw/StripChart.h>
#include <Xm/Xm.h>
#include <Xm/TextF.h>
#include <Xm/PushB.h>
#include <Xm/Scale.h>
#include <Xm/Label.h>
#include <Xm/FileSB.h>
#include <Xm/SelectioB.h>
#include "Clock.h"
#include "gui.h"
#include "gui_defines.h"
#include "BarChart.h"

static void update_label       (member_t *);
static void update_scale       (member_t *, int);
static void update_counter     (member_t *);
static void update_bar         (member_t *);
static void update_tfield      (member_t *);
static void update_fsbox       (member_t *);
static void update_selbox      (member_t *);
static void update_strip_chart (member_t *);
static void update_clock       (member_t *);
static void update_text        (member_t *);
static void update_fg_bg       (member_t *);

static char *no_label = "NO LABEL";

void
gui_update_widget(member_t *mp)
{
  switch(mp->m_type) {
  case R_BUTTON:
  case R_LABEL:
  case R_BGROUP:
  case R_LGROUP:
  case R_CASCADE:
  case R_OPTION:
    update_label(mp);
    break;
  case R_HSCALE:
    update_scale(mp, XmHORIZONTAL);
    break;
  case R_VSCALE:
    update_scale(mp, XmVERTICAL);
    break;
  case R_COUNTER:
    update_counter(mp);
    break;
  case R_VBAR:
  case R_HBAR:
  case R_VBAR_CHART:
  case R_HBAR_CHART:
    update_bar(mp);
    break;
  case R_TEXT:
    update_text(mp);
    break;
  case R_TFIELD:
    update_tfield(mp);
    break;
  case R_FSBOX:
    update_fsbox(mp);
    break;
  case R_SELBOX:
    update_selbox(mp);
    break;
  case R_STRIPCHART:
  case R_POINTCHART:
    update_strip_chart(mp);
    break;
  case R_CLOCK:
    update_clock(mp);
    break;
  case R_GROUP:
  case R_MENUBAR:
  case R_HRADIOBOX:
  case R_VRADIOBOX:
  case R_TBUTTON:
  case R_ROW:
  case R_COLUMN:
  case R_SEPARATOR:
    update_fg_bg(mp);
    break;
  default:
    break;
  }
}

/* background widgets here: none */
static void
update_label(member_t *mp)
{
  char *p = 0;
  int n;
  XmString cs;
  XmString new_cs = 0;
  Arg args[8];
  Pixmap pixmap;
  Dimension width;
  Dimension height;

  /* use common code */
  update_fg_bg(mp);

  /* get initial values */
  n = 0;
  XtSetArg(args[n], XmNlabelString, &cs);  n++;
  XtGetValues(mp->m_primary, args, n);

  /* check for labelString update */
  n = 0;
  if (mp->m_label)
    p = mp->m_label;
  else
    if (mp->m_data) {
      if (gui_read_bitmap(mp, &pixmap, &width, &height) == False)
        p = no_label;
    } else
      p = no_label;
  if (p) {
    new_cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
    if (XmStringCompare(cs, new_cs) == False) {
      XtSetArg(args[n], XmNlabelString, new_cs);  n++;
    }
  } else {
    XtSetArg(args[n], XmNlabelPixmap, pixmap); n++;
    XtSetArg(args[n], XmNwidth, width + 6);  n++;
    XtSetArg(args[n], XmNheight, height + 6);  n++;
  }

  if (n)
    XtSetValues(mp->m_primary, args, n);

  XmStringFree(cs);
  if (new_cs)
    XmStringFree(new_cs);
}

/* background widgets here: none */
static void
update_scale(member_t *mp, int new_orientation)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  int min;
  int max;
  int new_min;
  int new_max;
  int init;
  int new_init;
  int orientation;
  XmString cs;
  XmString new_cs;
  Arg args[16];

  /* use common code */
  update_fg_bg(mp);

  /* get initial values */
  n = 0;
  XtSetArg(args[n], XmNminimum, &min);  n++;
  XtSetArg(args[n], XmNmaximum, &max);  n++;
  XtSetArg(args[n], XmNorientation, &orientation);  n++;
  XtSetArg(args[n], XmNvalue, &init);  n++;
  XtSetArg(args[n], XmNtitleString, &cs);  n++;
  XtGetValues(mp->m_primary, args, n);

  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      new_min = atoi(fields[0]);
    if (fields[1])
      new_max = atoi(fields[1]);
    if (fields[2])
      new_init = atoi(fields[2]);

    if (min != new_min) {
      XtSetArg(args[n], XmNminimum, new_min);  n++;
    }
    if (max != new_max) {
      XtSetArg(args[n], XmNmaximum, new_max);  n++;
    }
    if (init != new_init) {
      XtSetArg(args[n], XmNvalue, new_init);  n++;
    }
  }
  if (mp->m_label)
    new_cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
  else
    new_cs = XmStringCreateLtoR(no_label, XmFONTLIST_DEFAULT_TAG);
  if (XmStringCompare(cs, new_cs) == False) {
    XtSetArg(args[n], XmNtitleString, cs);  n++;
  }
  if (orientation != new_orientation) {
    XtSetArg(args[n], XmNorientation, new_orientation);
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
  XmStringFree(cs);
  XmStringFree(new_cs);
}

/* background widgets here: mp->m_primary is a RowColumn */
static void
update_counter(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  char *p;
  int n;
  cd_t *cdp = (cd_t *) mp->m_wdata;
  Arg args[2];
  Widget w;
  XmString cs;
  XmString new_cs;

  /* use common code to update all the widgets */
  update_fg_bg(mp);
  w = mp->m_primary;
  mp->m_primary = cdp->c_label;
  update_fg_bg(mp);
  mp->m_primary = cdp->c_up_arrow;
  update_fg_bg(mp);
  mp->m_primary = cdp->c_counter;
  update_fg_bg(mp);
  mp->m_primary = cdp->c_down_arrow;
  update_fg_bg(mp);
  mp->m_primary = w;

  /* do updates to min and max.  counter does not get updated! */
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0])
      cdp->c_minimum = atoi(fields[0]);
    if (fields[1])
      cdp->c_maximum = atoi(fields[1]);
    if (cdp->c_minimum >= cdp->c_maximum) {
      cdp->c_minimum = 1;
      cdp->c_maximum = 100;
      XtWarningMsg("Warning", "RangeConstraint", "Constraint",
                   "Minimum Value >= Maximum Value", 0, 0);
    }
  }

  /* get initial values for the label */
  n = 0;
  XtSetArg(args[n], XmNlabelString, &cs);  n++;
  XtGetValues(cdp->c_label, args, n);

  /* create the new label and see if they're the same */
  if (mp->m_label)
    p = mp->m_label;
  else
    p = no_label;
  new_cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
  if (XmStringCompare(cs, new_cs) == False) {
    n = 0;
    XtSetArg(args[n], XmNlabelString, new_cs);  n++;
    XtSetValues(cdp->c_label, args, n);
  }
  XmStringFree(cs);
  XmStringFree(new_cs);
}

/* background widgets here:            *
 * for bar, none                       *
 * for barchart, mp->m_primary is Form */

static void
update_bar(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  int min;
  int max;
  int new_min;
  int new_max;
  int value;
  int new_value;
  int chart = ((mp->m_type == R_VBAR_CHART) || (mp->m_type == R_HBAR_CHART));
  Arg args[8];
  Widget w;
  Dimension width;
  Dimension height;
  Dimension new_width;
  Dimension new_height;
  XmString cs;
  XmString new_cs;
  bd_t *bdp = (bd_t *) mp->m_wdata;

  /* use common code */
  if (chart) {
    w = mp->m_primary;
    mp->m_primary = bdp->b_bar;
    update_fg_bg(mp);
    mp->m_primary = w;
  } else
    update_fg_bg(mp);

  n = 0;
  XtSetArg(args[n], XtNwidth, &width);  n++;
  XtSetArg(args[n], XtNheight, &height);  n++;
  XtSetArg(args[n], XtNminValue, &min);  n++;
  XtSetArg(args[n], XtNmaxValue, &max);  n++;
  XtSetArg(args[n], XtNvalue, &value);  n++;
  if (chart)
    XtGetValues(bdp->b_bar, args, n);
  else
    XtGetValues(mp->m_primary, args, n);
  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0]) {
      new_width = atoi(fields[0]);
      if (new_width != width) {
        XtSetArg(args[n], XtNwidth, new_width);  n++;
      }
    }
    if (fields[1]) {
      new_height = atoi(fields[1]);
      if (new_height != height) {
        XtSetArg(args[n], XtNheight, new_height);  n++;
      }
    }
    if (fields[2]) {
      new_min = atoi(fields[2]);
      if (new_min != min) {
        XtSetArg(args[n], XtNminValue, new_min);  n++;
      }
    }
    if (fields[3]) {
      new_max = atoi(fields[3]);
      if (new_min >= new_max) {
        new_min = 0;
        new_max = 100;
        XtWarningMsg("Warning", "RangeConstraint", "Constraint",
                     "Minimum Value >= Maximum Value", 0, 0);
      }
      if (new_max != max) {
        XtSetArg(args[n], XtNmaxValue, new_max);  n++;
      }
    }
    if (fields[4]) {
      new_value = atoi(fields[4]);
      if (new_value != value) {
        XtSetArg(args[n], XtNvalue, new_value);  n++;
      }
    }
  }
  if (n)
    if (chart)
      XtSetValues(bdp->b_bar, args, n);
    else
      XtSetValues(mp->m_primary, args, n);

  if (chart) {
    n = 0;
    XtSetArg(args[n], XmNlabelString, &cs);  n++;
    XtGetValues(bdp->b_label, args, n);
    if (mp->m_label)
      new_cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
    else
      new_cs = XmStringCreateLtoR(no_label, XmFONTLIST_DEFAULT_TAG);
    if (XmStringCompare(cs, new_cs) == False) {
      n = 0;
      XtSetArg(args[n], XmNlabelString, new_cs);  n++;
      XtSetValues(bdp->b_label, args, n);
    }
    XmStringFree(cs);
    XmStringFree(new_cs);
  }
}

/* background widgets here: none */
static void
update_tfield(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  Arg args[2];
  Dimension width;
  Dimension new_width;

  /* use common code */
  update_fg_bg(mp);

  n = 0;
  XtSetArg(args[n], XmNcolumns, &width);  n++;
  XtGetValues(mp->m_primary, args, n);
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0]) {
      new_width = atoi(fields[0]);
      if (new_width != width) {
        n = 0;
        XtSetArg(args[n], XmNcolumns, new_width);  n++;
        XtSetValues(mp->m_primary, args, n);
      }
    }
  }
}

/* background widgets here: none */
static void
update_fsbox(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  char *text;
  unsigned char file_type;
  int i;
  int n;
  Arg args[16];
  XmString cs;
  XmString c_dir;
  XmString c_pattern;
  struct stat old_st;
  struct stat new_st;

  /* use common code */
  update_fg_bg(mp);

  /* grab the old values */
  n = 0;
  XtSetArg(args[n], XmNdirectory, &c_dir);  n++;
  XtSetArg(args[n], XmNpattern, &c_pattern);  n++;
  XtSetArg(args[n], XmNfileTypeMask, &file_type);  n++;
  XtGetValues(mp->m_primary, args, n);

  /* for anything that changed, update */
  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0]) {
      /* "." is equal to "`pwd`" isn't it? */
      XmStringGetLtoR(c_dir, XmFONTLIST_DEFAULT_TAG, &text);
      stat(text, &old_st);
      XtFree(text);
      XmStringFree(c_dir);
      stat(fields[0], &new_st);
      if (old_st.st_ino != new_st.st_ino) {
        c_dir = XmStringCreateLtoR(fields[0], XmFONTLIST_DEFAULT_TAG);
        XtSetArg(args[n], XmNdirectory, c_dir);  n++;
      } else
        c_dir = 0;
    }
    if (fields[1]) {
      cs = XmStringCreateLtoR(fields[1], XmFONTLIST_DEFAULT_TAG);
      i = XmStringCompare(cs, c_pattern);
      XmStringFree(c_pattern);
      if (i == True) {
        XmStringFree(cs);
        c_pattern = 0;
      } else {
        XtSetArg(args[n], XmNpattern, cs);  n++;
        c_pattern = cs;
      }
    }
    if (fields[2]) {
      switch(atoi(fields[2])) {
      case F_REGULAR:
        if (file_type != XmFILE_REGULAR) {
          XtSetArg(args[n], XmNfileTypeMask, XmFILE_REGULAR);  n++;
        }
        break;
      case F_DIRECTORY:
        if (file_type != XmFILE_DIRECTORY) {
          XtSetArg(args[n], XmNfileTypeMask, XmFILE_DIRECTORY);  n++;
        }
        break;
      case F_ANY:
        if (file_type != XmFILE_ANY_TYPE) {
          XtSetArg(args[n], XmNfileTypeMask, XmFILE_ANY_TYPE);  n++;
        }
        break;
      default:
        break;
      }
    }
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
  if (c_dir)
    XmStringFree(c_dir);
  if (c_pattern)
    XmStringFree(c_pattern);
}

/* background widgets here: none */
static void
update_selbox(member_t *mp)
{
  char **pp;
  int i;
  int n;
  int count;
  Arg args[4];
  XmString cs;
  XmString new_cs = 0;
  XmStringTable cst = 0;

  /* use common code */
  update_fg_bg(mp);

  /* get the initial values */
  n = 0;
  XtSetArg(args[n], XmNlistLabelString, &cs);  n++;
  XtGetValues(mp->m_primary, args, n);

  n = 0;
  if (mp->m_agg_head) {
    pp = (char **) mp->m_agg_head->m_data;
    count = (int) (long) mp->m_agg_head->m_wdata;
    cst = (XmStringTable) se_alloc(count * sizeof(XmString));
    for(i=0; i<count; i++)
      cst[i] = XmStringCreateLtoR(pp[i], XmFONTLIST_DEFAULT_TAG);
    XtSetArg(args[n], XmNlistItems, cst);  n++;
    XtSetArg(args[n], XmNlistItemCount, count);  n++;
  }
  if (mp->m_label) {
    new_cs = XmStringCreateLtoR(mp->m_label, XmFONTLIST_DEFAULT_TAG);
    if (XmStringCompare(cs, new_cs) == False) {
      XtSetArg(args[n], XmNlistLabelString, new_cs);  n++;
    }
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
  XmStringFree(cs);
  if (new_cs)
    XmStringFree(new_cs);
  if (cst) {
    for(i=0; i<count; i++)
      XmStringFree(cst[i]);
    se_free(cst);
  }
}

/* background widgets here: none */
static void
update_text(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  Arg args[4];
  Dimension width;
  Dimension height;
  Dimension new_width;
  Dimension new_height;
  XmString cs;

  /* use common code */
  update_fg_bg(mp);

  cs = XmStringCreateLtoR("X", XmFONTLIST_DEFAULT_TAG);

  n = 0;
  XtSetArg(args[n], XtNwidth, &width);  n++;
  XtSetArg(args[n], XtNheight, &height);  n++;
  XtGetValues(mp->m_primary, args, n);
  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0]) {
      new_width = atoi(fields[0]);
      new_width *= XmStringWidth(Gui_AppData.textFont, cs);
      if (new_width != width) {
        XtSetArg(args[n], XtNwidth, new_width);  n++;
      }
    }
    if (fields[1]) {
      new_height = atoi(fields[1]);
      new_height *= XmStringHeight(Gui_AppData.textFont, cs);
      if (new_height != height) {
        XtSetArg(args[n], XtNheight, new_height);  n++;
      }
    }
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
  XmStringFree(cs);
}

static void
update_strip_chart (member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  Arg args[8];
  int scale;
  int jump_pixels;
  int interval;
  int new_scale;
  int new_jump_pixels;
  int new_interval;
#if 0
  Dimension width;
  Dimension height;
  Dimension new_width;
  Dimension new_height;
#endif

  /* use common code */
  update_fg_bg(mp);

  n = 0;
#if 0
  XtSetArg(args[n], XtNwidth,      &width);       n++;
  XtSetArg(args[n], XtNheight,     &height);      n++;
  /* SetValues doesn't check for change in width or height and fails */
#endif
  XtSetArg(args[n], XtNminScale,   &scale);       n++;
  XtSetArg(args[n], XtNjumpScroll, &jump_pixels); n++;
  XtSetArg(args[n], XtNupdate,     &interval);    n++;
  XtGetValues(mp->m_primary, args, n);
  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
#if 0
    if (fields[0]) {
      new_width = atoi(fields[0]);
      if (width != new_width) {
        XtSetArg(args[n], XtNwidth, new_width); n++;
      }
    }
    if (fields[1]) {
      new_height = atoi(fields[1]);
      if (height != new_height) {
        XtSetArg(args[n], XtNheight, new_height); n++;
      }
    }
#endif
    if (fields[2]) {
      new_scale = atoi(fields[2]);
      if (scale != new_scale) {
        XtSetArg(args[n], XtNminScale, new_scale); n++;
      }
    }
    if (fields[3]) {
      new_jump_pixels = atoi(fields[3]);
      if (jump_pixels != new_jump_pixels) {
        XtSetArg(args[n], XtNjumpScroll, new_jump_pixels); n++;
      }
    }
    if (fields[4]) {
      new_interval = atoi(fields[4]);
      if (interval != new_interval) {
        XtSetArg(args[n], XtNupdate,  new_interval); n++;
      }
    }
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
}

static void
update_clock(member_t *mp)
{
  char *fields[GuiMAX_FIELDS];
  int n;
  Arg args[8];
  int update;
  int new_update;
  int chime;
  int new_chime;
  Dimension width;
  Dimension height;
  Dimension new_width;
  Dimension new_height;
  Pixel fg;
  Pixel new_fg;

  /* use common code */
  update_fg_bg(mp);

  n = 0;
  XtSetArg(args[n], XtNforeground, &fg);      n++;
  XtSetArg(args[n], XtNwidth,      &width);   n++;
  XtSetArg(args[n], XtNheight,     &height);  n++;
  XtSetArg(args[n], XtNupdate,     &update);  n++;
  XtSetArg(args[n], XtNchime,      &chime);   n++;
  XtGetValues(mp->m_primary, args, n);
  new_fg = gui_get_pixel(mp->m_foreground);
  if (fg != new_fg) {
    XtSetArg(args[n], XtNhand, new_fg); n++;
  }
  n = 0;
  if (mp->m_data) {
    memset(fields, '\0', sizeof fields);
    gui_record_split(mp->m_data, fields);
    if (fields[0]) {
      new_width = atoi(fields[0]);
      if (width != new_width) {
        XtSetArg(args[n], XtNwidth, new_width); n++;
      }
    }
    if (fields[1]) {
      new_height = atoi(fields[1]);
      if (height != new_height) {
        XtSetArg(args[n], XtNheight, new_height); n++;
      }
    }
    if (fields[2]) {
      new_update = atoi(fields[2]);
      if (update != new_update) {
        XtSetArg(args[n], XtNupdate, new_update); n++;
      }
    }
    if (fields[3]) {
      new_chime = atoi(fields[3]);
      if (chime != new_chime) {
        XtSetArg(args[n], XtNchime, new_chime); n++;
      }
    }
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
}

static void
update_fg_bg(member_t *mp)
{
  int n;
  Pixel fg;
  Pixel bg;
  Pixel new_fg;
  Pixel new_bg;
  Arg args[4];

  n = 0;
  XtSetArg(args[n], XmNforeground, &fg);  n++;
  XtSetArg(args[n], XmNbackground, &bg);  n++;
  XtGetValues(mp->m_primary, args, n);
  new_fg = gui_get_pixel(mp->m_foreground);
  new_bg = gui_get_pixel(mp->m_background);
  n = 0;
  if (fg != new_fg) {
    XtSetArg(args[n], XmNforeground, new_fg);  n++;
  }
  if (bg != new_bg) {
    XtSetArg(args[n], XmNbackground, new_bg);  n++;
  }
  if (n)
    XtSetValues(mp->m_primary, args, n);
}

static void
set_font(Widget w, char *font_name)
{
  if (w == 0)
    return;
  XtVaSetValues(w, XtVaTypedArg, XmNfontList, XmRString, font_name, 4, 0);
}

void
gui_set_medium_font(member_t *mp, char *font_name)
{
  Widget (*gc)(Widget,
#if NeedWidePrototypes
                       uint_t)
#else
                       uchar_t)
#endif
                                = XmSelectionBoxGetChild;

  if (mp == 0)
    return;
  switch(mp->m_type) {
  case R_BUTTON:
  case R_LABEL:
  case R_HSCALE:
  case R_VSCALE:
  case R_CASCADE:
  case R_OPTION:
  case R_TBUTTON:
    set_font(mp->m_primary, font_name);
    break;
  case R_COUNTER:
    set_font(((cd_t *) mp->m_wdata)->c_label, font_name);
    break;
  case R_VBAR_CHART:
  case R_HBAR_CHART:
    set_font(XtBarChartGetChild(mp->m_primary, BC_LABEL_CHILD), font_name);
    set_font(XtBarChartGetChild(mp->m_primary, BC_VALUE_CHILD), font_name);
    set_font(XtBarChartGetChild(mp->m_primary, BC_UPPER_CHILD), font_name);
    set_font(XtBarChartGetChild(mp->m_primary, BC_LOWER_CHILD), font_name);
    break;
  case R_FSBOX:
    gc = XmFileSelectionBoxGetChild;
    /* falls through */
  case R_SELBOX:
    set_font((*gc)(mp->m_primary, XmDIALOG_OK_BUTTON), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_APPLY_BUTTON), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_CANCEL_BUTTON), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_DIR_LIST_LABEL), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_FILTER_LABEL), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_LIST_LABEL), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_SELECTION_LABEL), font_name);
    break;
  default:
    break;
  }
}

void
gui_set_bold_font(member_t *mp, char *font_name)
{
  if (mp == 0)
    return;
  switch(mp->m_type) {
  case R_BGROUP:
  case R_LGROUP:
    break;
  default:
    return;
  }
  set_font(mp->m_primary, font_name);
}

void
gui_set_text_font(member_t *mp, char *font_name)
{
  Widget (*gc)(Widget,
#if NeedWidePrototypes
                       uint_t)
#else
                       uchar_t)
#endif
                                = XmSelectionBoxGetChild;
  Widget w;
  XrmValue to;
  XrmValue from;
  XmFontList xmFontp;

  if (mp == 0)
    return;
  switch(mp->m_type) {
  case R_TEXT:
  case R_EDITOR:
    /* XtVaTypedArg doesn't like XmRFontList with ScrolledText */
    to.size = 0;
    to.addr = 0;
    from.size = 4;
    from.addr = font_name;
    XtConvertAndStore(mp->m_primary, XmRString, &from, XmRFontList, &to);
    if (to.addr == 0)
      return;
    xmFontp = *((XmFontList *) to.addr);
    XtVaSetValues(mp->m_primary, XmNfontList, xmFontp, 0);
    break;
  case R_TFIELD:
    set_font(mp->m_primary, font_name);
    break;
  case R_FSBOX:
    gc = XmFileSelectionBoxGetChild;
    set_font((*gc)(mp->m_primary, XmDIALOG_DIR_LIST), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_FILTER_TEXT), font_name);
    /* falls through */
  case R_SELBOX:
    set_font((*gc)(mp->m_primary, XmDIALOG_LIST), font_name);
    set_font((*gc)(mp->m_primary, XmDIALOG_TEXT), font_name);
    break;
  default:
    break;
  }
}
