/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <ctype.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include "gui_defines.h"
#include "gui.h"

Pixmap
gui_load_bitmap(char *file_name, int foreground, int background)
{
  unsigned int width;
  unsigned int height;
  unsigned char *data;
  Display *display;
  Drawable d;
  Pixmap pixmap;
  Pixel fg;
  Pixel bg;

  if (Gui_toplevel == 0)
    return 0;
  if (XReadBitmapFileData(file_name,
                          &width, &height, &data, 0, 0) != BitmapSuccess)
    return 0;
  if ((foreground != ST_WHITE) && (foreground != ST_BLACK))
    foreground = ST_BLACK;
  if ((background != ST_WHITE) && (background != ST_BLACK))
    background = ST_WHITE;
  fg = gui_get_pixel(foreground);
  bg = gui_get_pixel(background);
  display = XtDisplay(Gui_toplevel);
  d = DefaultRootWindow(display);
  pixmap =
    XCreatePixmapFromBitmapData(display, d, (char *) data, width, height, fg, bg, 1);
  se_free(data);
  return pixmap;
}

void
gui_set_icon(Pixmap icon, Pixmap mask)
{
  Arg args[2];
  int n;

  if ((icon == 0) || (Gui_toplevel == 0))
    return;
  n = 0;
  XtSetArg(args[n], XmNiconPixmap, icon);  n++;
  if (mask) {
    XtSetArg(args[n], XmNiconMask, mask);  n++;
  }
  XtSetValues(Gui_toplevel, args, n);
}

typedef struct {
  Pixmap icon;
  Pixmap mask;
} b_icon;

static XtIntervalId interval_id;

static void
timeout_proc(XtPointer data, XtIntervalId *id)
{
  b_icon *bip = (b_icon *) data;
  Pixmap icon;
  Pixmap mask;
  Arg args[2];
  int n;

  if (interval_id == 0)
    return;
  n = 0;
  XtSetArg(args[n], XmNiconPixmap, &icon);  n++;
  XtSetArg(args[n], XmNiconMask, &mask);  n++;
  XtGetValues(Gui_toplevel, args, n);
  gui_set_icon(bip->icon, bip->mask);
  bip->icon = icon;
  bip->mask = mask;
  interval_id = XtAppAddTimeOut(Gui_app, 1000, timeout_proc, data);
}

void
gui_blink_icon(Pixmap blink_icon, Pixmap blink_mask, int on_off)
{
  static b_icon bi;

  if (on_off == 1) {
    if (interval_id)
      return;
    bi.icon = blink_icon;
    bi.mask = blink_mask;
    interval_id = XtAppAddTimeOut(Gui_app, 1000, timeout_proc, &bi);
  } else {
    if (interval_id == 0)
      return;
    XtRemoveTimeOut(interval_id);
    gui_set_icon(blink_icon, blink_mask);
    interval_id = 0;
  }
}

/* this code was lifted from xc/lib/X11/RdBitF.c in the R6 distribution */

#define MAX_SIZE 255

/* shared data for the image read/parse logic */
static short hexTable[256];		/* conversion value */
static Bool initialized = False;	/* easier to fill in at run time */


/*
 *	Table index for the hex values. Initialized once, first time.
 *	Used for translation value or delimiter significance lookup.
 */
static void initHexTable()
{
    /*
     * We build the table at run time for several reasons:
     *
     *     1.  portable to non-ASCII machines.
     *     2.  still reentrant since we set the init flag after setting table.
     *     3.  easier to extend.
     *     4.  less prone to bugs.
     */
    hexTable['0'] = 0;	hexTable['1'] = 1;
    hexTable['2'] = 2;	hexTable['3'] = 3;
    hexTable['4'] = 4;	hexTable['5'] = 5;
    hexTable['6'] = 6;	hexTable['7'] = 7;
    hexTable['8'] = 8;	hexTable['9'] = 9;
    hexTable['A'] = 10;	hexTable['B'] = 11;
    hexTable['C'] = 12;	hexTable['D'] = 13;
    hexTable['E'] = 14;	hexTable['F'] = 15;
    hexTable['a'] = 10;	hexTable['b'] = 11;
    hexTable['c'] = 12;	hexTable['d'] = 13;
    hexTable['e'] = 14;	hexTable['f'] = 15;

    /* delimiters of significance are flagged w/ negative value */
    hexTable[' '] = -1;	hexTable[','] = -1;
    hexTable['}'] = -1;	hexTable['\n'] = -1;
    hexTable['\t'] = -1;
	
    initialized = True;
}

/*
 *	read next hex value in the input stream, return -1 if EOF
 */
static int NextInt (FILE *fstream)
{
    int	ch;
    int	value = 0;
    int gotone = 0;
    int done = 0;
    
    /* loop, accumulate hex value until find delimiter  */
    /* skip any initial delimiters found in read stream */

    while (!done) {
	ch = getc(fstream);
	if (ch == EOF) {
	    value	= -1;
	    done++;
	} else {
	    /* trim high bits, check type and accumulate */
	    ch &= 0xff;
	    if (isascii(ch) && isxdigit(ch)) {
		value = (value << 4) + hexTable[ch];
		gotone++;
	    } else if ((hexTable[ch]) < 0 && gotone)
	      done++;
	}
    }
    return value;
}
