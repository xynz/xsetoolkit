/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

/*
 * menu_bar.c - Menu bar and drop down menu utilities
 *
 * Written by: Rich Pettit, SMCC Consultant
 *             Richard.Pettit@West.Sun.COM
 *
 */

#include <stdio.h>
#include <ctype.h>
#include <X11/Intrinsic.h>
#include <Xm/Xm.h>
#include <Xm/RowColumn.h>
#include <Xm/CascadeBG.h>
#include <Xm/PushBG.h>
#include <Xm/Separator.h>
#include "gui.h"
#include "gui_defines.h"

static char get_mnemonic(char *);

static char *no_label = "NO LABEL";

static void
createPulldownItems(Widget parent, member_t *menu)
{
  char label[BUFSIZ];
  char accel[BUFSIZ];
  char *p;
  char mnemonic;
  int n;
  Arg args[16];
  XmString cs = 0;
  XmString as = 0;
  Pixmap pixmap;
  Dimension width;
  Dimension height;
  member_t *mp;

  /* bogus */
  if (menu == 0)
    return;
  /* create the buttons */
  if (menu->m_type == R_MENUBAR)
    mp = menu->m_agg_head;
  else
    mp = menu;
  for(; mp; mp=mp->m_next) {
    n = 0;
    XtSetArg(args[n], XmNforeground, gui_get_pixel(mp->m_foreground));  n++;
    XtSetArg(args[n], XmNbackground, gui_get_pixel(mp->m_background));  n++;
    switch(mp->m_type) {
    case R_CASCADE:
      XtSetArg(args[n], XmNtearOffModel, XmTEAR_OFF_ENABLED);
      mp->m_secondary = XmCreatePulldownMenu(parent,
                          GuiNAME(mp->m_label, "PullDown"), args, n+1);
      XtSetArg(args[n], XmNsubMenuId, mp->m_secondary);  n++;
      break;
    case R_SEPARATOR:
      XtSetArg(args[n], XmNorientation, XmHORIZONTAL);  n++;
      mp->m_primary = XmCreateSeparator(parent, "menu_sep", args, n);
      XtManageChild(mp->m_primary);
      continue;
    default:
      break;
    }
    p = 0;
    mnemonic = 0;
    if (mp->m_label) {
      strcpy(label, mp->m_label);
      mnemonic = get_mnemonic(label);
      p = label;
    } else {
      if (mp->m_data) {
        if (gui_read_bitmap(mp, &pixmap, &width, &height) == False)
          p = no_label;
      } else
        p = no_label;
    }
    if (p) {
      cs = XmStringCreateLtoR(p, XmFONTLIST_DEFAULT_TAG);
      XtSetArg(args[n], XmNlabelString, cs);  n++;
      XtSetArg(args[n], XmNfontList, Gui_AppData.mediumFont);  n++;
      if (mnemonic) {
        XtSetArg(args[n], XmNmnemonic, mnemonic);  n++;
        if (menu->m_type == R_OPTION) {
          sprintf(accel, "Ctrl+%c",
                  islower(mnemonic) ? toupper(mnemonic) : mnemonic);
          as = XmStringCreateLtoR(accel, XmFONTLIST_DEFAULT_TAG);
          sprintf(accel, "Ctrl<Key>%c",
                  islower(mnemonic) ? toupper(mnemonic) : mnemonic);
          XtSetArg(args[n], XmNaccelerator, accel);  n++;
          XtSetArg(args[n], XmNacceleratorText, as);  n++;
        }
      }
    } else {
      XtSetArg(args[n], XmNlabelType, XmPIXMAP);  n++;
      XtSetArg(args[n], XmNlabelPixmap, pixmap);  n++;
      XtSetArg(args[n], XmNwidth, width + 6);  n++;
      XtSetArg(args[n], XmNheight, height + 6);  n++;
    }
    if (as && (mp->m_type != R_CASCADE))
      mp->m_primary =
        XmCreatePushButtonGadget(parent, GuiNAME(p, mp->m_data), args, n);
    else
      mp->m_primary =
        XmCreateCascadeButtonGadget(parent, GuiNAME(p, mp->m_data), args, n);
    if (cs)
      XmStringFree(cs);
    if (as)
      XmStringFree(as);
    if (mp->m_type == R_CASCADE)
      createPulldownItems(mp->m_secondary, mp->m_agg_head);
    else if (mp->m_callback) {
      XtAddCallback(mp->m_primary, XmNactivateCallback, gui_cb_cb, mp);
    }
    XtManageChild(mp->m_primary);
  }
}

Widget
gui_create_menu_bar(Widget parent, member_t *menu)
{
  Widget menuBar;
  Arg args[4];
  int n;

  n = 0;
  XtSetArg(args[n], XmNforeground, gui_get_pixel(menu->m_foreground));  n++;
  XtSetArg(args[n], XmNbackground, gui_get_pixel(menu->m_background));  n++;
  menuBar = XmCreateMenuBar(parent, menu->m_label, args, n);
  createPulldownItems(menuBar, menu);
  return menuBar;
}

static char
get_mnemonic(char *buf)
{
  char *p;
  char mnemonic = 0;

  for(p=buf; *p; p++, buf++) {
    switch(*p) {
    case '&':
      mnemonic = *(p+1);
      strcpy(buf, buf+1);
      break;
    case '\\':
      if (*(p+1) == '&') {
        *buf = '&';
        p++;
      }
      break;
    default:
      *buf = *p;
      break;
    }
  }
  *buf = '\0';
  return mnemonic;
}
