/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <X11/StringDefs.h>
#include <X11/Intrinsic.h>
#include <X11/Xresource.h>
#include <Xm/Xm.h>
#include <Xm/Form.h>
#include <Xm/PushB.h>
#include <Xm/Text.h>
#include <Xm/TextF.h>
#include <Xm/DialogS.h>
#include "gui_defines.h"
#include "gui.h"

/* yikes! */
#define MAX_TEXT_SIZE  (64*1024)

/* this is for the text widget, not the text_file stuff above */
void
gui_append_text(member_t *handle, char *text)
{
  char buf[MAX_TEXT_SIZE];
  char *s = 0;
  char *p;
  int n;
  int len;
  int text_len;
  Arg args[2];
  Widget w = handle->m_primary;

  if ((text == 0) || ((XmIsText(w) == False) && (XmIsTextField(w) == False)))
    return;
  text_len = strlen(text);
  if (text_len > MAX_TEXT_SIZE) {
    text += (text_len - MAX_TEXT_SIZE);
    text_len = (text_len - MAX_TEXT_SIZE);
  }
  n = 0;
  XtSetArg(args[n], XmNvalue, &s);  n++;
  XtGetValues(w, args, n);
  if (s)
    len = strlen(s) + text_len + 1;
  else
    len = text_len + 1;
  if (len >= MAX_TEXT_SIZE) {
    for(p=s+(len - MAX_TEXT_SIZE); *p; p++)
      if (*p == '\n') {
        p++;
        break;
      }
    strcpy(buf, p);
    len = MAX_TEXT_SIZE;
  } else
    strcpy(buf, s);
  free(s);
  strcat(buf, text);
  n = 0;
  XtSetArg(args[n], XmNvalue, buf);  n++;
  XtSetArg(args[n], XmNcursorPosition, len);  n++;
  XtSetValues(w, args, n);
}

void
gui_get_text(member_t *handle, char *buf, int bufsiz)
{
  char *p;

  if ((XmIsText(handle->m_primary) == False) &&
      (XmIsTextField(handle->m_primary) == False))
    return;
  p = XmTextGetString(handle->m_primary);
  memccpy(buf, p, '\0', bufsiz);
  XtFree(p);
}

void
gui_set_text(member_t *handle, char *buf)
{
  if ((XmIsText(handle->m_primary) == False) &&
      (XmIsTextField(handle->m_primary) == False))
    return;
  XmTextSetString(handle->m_primary, buf);
}

void
gui_load_text_file(member_t *handle, char *file_name)
{
  char *p;
  int input;
  struct stat st_buf;

  if ((XmIsText(handle->m_primary) == False) &&
      (XmIsTextField(handle->m_primary) == False))
    return;

  /* read the file into memory */
  input = open(file_name, O_RDONLY);
  if (input == -1) {
    gui_warning_dialog("Cannot open %s", file_name);
    return;
  }
  if (fstat(input, &st_buf) == -1) {
    gui_warning_dialog("Cannot fstat %s", file_name);
    close(input);
    return;
  }
  p = se_alloc(st_buf.st_size + 1);
  if (p == 0) {
    perror("gui_load_text_file: se_alloc");
    exit(1);
  }
  memset(p, '\0', st_buf.st_size + 1);
  if (read(input, p, st_buf.st_size) != st_buf.st_size) {
    gui_warning_dialog("Could not read %d bytes from %s",
                        st_buf.st_size, file_name);
    close(input);
    se_free(p);
    return;
  }
  close(input);
  XmTextSetString(handle->m_primary, p);
  se_free(p);
}

void
gui_save_text_file(member_t *handle, char *file_name)
{
  char *p;
  int n;
  int output;

  if ((XmIsText(handle->m_primary) == False) &&
      (XmIsTextField(handle->m_primary) == False))
    return;
  output = open(file_name, O_WRONLY|O_CREAT|O_TRUNC, 0644);
  if (output == -1) {
    gui_warning_dialog("Cannot open %s", file_name);
    return;
  }
  p = XmTextGetString(handle->m_primary);
  n = strlen(p);
  if (write(output, p, n) != n) {
    gui_warning_dialog("Cannot write %s", file_name);
    close(output);
  } else if (close(output) == -1)
    gui_warning_dialog("Close of %s failed", file_name);
  XtFree(p);
}
