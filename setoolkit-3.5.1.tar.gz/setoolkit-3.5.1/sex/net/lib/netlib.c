/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>
#include <signal.h>
#include <fcntl.h>
#include <errno.h>
#include <signal.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/wait.h>
#include <sys/time.h>
#include <sys/resource.h>
#include <sys/uio.h>
#include <sys/file.h>
#include <netdb.h>
#include "netlib.h"

int NiErrno = 0;
int NiSocket = -1;                 /* easy access to our endpoint  */
char *NiProgramName = "unknown";   /* for reporting                */

static struct hostent hostStructure;
static struct hostent *hostPointer = 0;

extern void *se_function_call(char *func, ...);

/*
 * Standard "copy string into dynamic memory" function.
 * Returns malloced string which should be freed when no longer used.
 */

static char *
stringSave(char *s)
{
  int n = strlen(s) + 1;
  char *p = (char *) malloc(n);

  if (p == 0)
    return 0;

  strcpy(p, s);
  return p;
}

/*
 * Copy hostent structure and all its members.  This is needed since
 * gethostbyname() returns a pointer to a local structure.
 */

static int
hostentCopy(struct hostent *dest, struct hostent *src)
{
  register int i;
  register char **p;

  /* host name */
  dest->h_name = stringSave(src->h_name);
  if (dest->h_name == 0)
    return 1;

  /* count the number of aliaes */
  for (i = 1, p = src->h_aliases; p && *p; p++, i++)
    ;

  /* none */
  if (i == 1)
    dest->h_aliases = 0;
  else {
    /* malloc area for array */
    dest->h_aliases = (char **) malloc(i * sizeof(char *));
    if (dest->h_aliases == 0)
      return 1;

    /* copy each alias */
    for (i = 0, p = src->h_aliases; *p; p++, i++) {
      dest->h_aliases[i] = stringSave(*p);
      if (dest->h_aliases[i] == 0)
        return 1;
    }

    /* null terminate */
    dest->h_aliases[i] = 0;
  }

  /* address type */
  dest->h_addrtype = src->h_addrtype;

  /* count the addresses */
  for (i = 1, p = src->h_addr_list; p && *p; p++, i++)
    ;

  /* none -- improbable */
  if (i == 1)
    dest->h_addr_list = 0;
  else {
    /* malloc the area for the array */
    dest->h_addr_list = (char **) malloc(i * sizeof(char *));
    if (dest->h_addr_list == 0)
      return 1;

    /* copy each address */
    for (i = 0, p = src->h_addr_list; *p; i++, p++) {
      dest->h_addr_list[i] = (char *) malloc(src->h_length);
      if (dest->h_addr_list[i] == 0)
        return 1;
  
      memcpy(dest->h_addr_list[i], *p, src->h_length);
    }
  
  /* null terminate */
  dest->h_addr_list[i] = 0;
  }
  
  /* copy the length */
  dest->h_length = src->h_length;
  
  return 0;
}
  
/* dumb sigcld catcher */
static void
reap_child(int sig)
{
  wait((int *) 0);
  signal(sig, reap_child);
}

/*
 * Perform all the initial actions which only need to be done once per
 * application instance.  This will be called by net_initialize which is
 * called by just about everything.
 */

static int
NiWakeup(void)
{
  char buf[64];

  /* first time through */
  if (hostPointer)
    return NiSUCCESS;

  /* no network, use loopback driver */
#ifdef STANDALONE
  strcpy(buf, "localhost");
#else
  /* only need to do this stuff once */
  if (gethostname(buf, sizeof buf) == -1) {
    NiErrno = NiHOSTNAME_ERROR;
    return NiFAILURE;
  }
#endif
  
  /* get host information */
  hostPointer = gethostbyname(buf);
  if (hostPointer == 0) {
    NiErrno = NiHOSTBYNAME_ERROR;
    return NiFAILURE;
  }
  
  /* copy it into our local area */
  if (hostentCopy(&hostStructure, hostPointer)) {
    NiErrno = NiHOSTBYNAME_ERROR;
    return NiFAILURE;
  }
  
  /* this will denote that we've already done the initialization */
  hostPointer = &hostStructure;
  
  signal(SIGCLD, reap_child);
  
  return NiSUCCESS;
}
  
/*+
 * net_initialize
 *
 *  Initialize a network context handle for use on a connection-mode
 *  service over the transport provider.
 *
 *  NiNetworkContext *
 *  net_initialize()
 *
 *  Returns:    A pointer to a network context structure.
 *          or  zero if there was an error.
 *
 *  Notes:      Uses malloc() -- use net_terminate to release handle.
 *              Sets NiErrno upon error.
-*/
/*&
 * Assure initialization is done.
 * CALL malloc() to get memory for a network context handle.
 * Set appropriate values in NiNetworkContext structure.
 * Initialize signals.
 * RETURN the handle.
&*/

NiNetworkContext   *
net_initialize(void)
{
  NiNetworkContext *nch;

  /* make sure we're on top of things */
  if (hostPointer == 0)
    if (NiWakeup() == NiFAILURE)
      return 0;

  /* allocate handle */
  nch = (NiNetworkContext *) malloc(sizeof(NiNetworkContext));
  if (nch == 0)
    return 0;

  /* zero it out */
  memset(nch, '\0', sizeof(NiNetworkContext));

  /* initialize */
  nch->ncSocket = -1;
  nch->ncAcceptSocket = -1;
  
  /* done */
  return nch;
}

/*+
 * net_bind_service
 *
 *  Establish a connection-mode service on a specified port.
 *
 *  int
 *  net_bind_service(nch, port, count)
 *    NiNetworkContext *nch; The network context handle
 *    int port;              The port number
 *    int count;             The maximum number of connect indications to queue
 *
 *  Returns:    NiSUCCESS if everything is ok
 *              NiFAILURE if something happened
-*/
/*&
 * Initialize the network context handle.
 * CALL socket() to retrieve a connection-mode endpoint.
 * CALL bind() to bind the endpoint to an address on the transport provider.
 * CALL listen() to listen on that address.
 * RETURN NiSUCCESS.
&*/

int
net_bind_service(NiNetworkContext *nch, int port, int count)
{
  if ((hostPointer == 0) || (nch == 0)) {
    NiErrno = NiNOT_INITIALIZED;
    return NiFAILURE;
  }

  /* set up the address, port, and address family */

  /* memcpy(&nch->ncSocketAddress.sin_addr.s_addr, hostPointer->h_addr,
   *        hostPointer->h_length);
   */

  nch->ncSocketAddress.sin_addr.s_addr = htonl(INADDR_ANY);
  nch->ncSocketAddress.sin_port = htons((unsigned short) port);
  nch->ncSocketAddress.sin_family = hostPointer->h_addrtype;

  /* establish an IP connection-mode socket */
  nch->ncSocket = socket(AF_INET, SOCK_STREAM, PF_UNSPEC);
  if (nch->ncSocket == -1) {
    NiErrno = NiSOCKET_ERROR;
    return NiFAILURE;
  }

  /* bind this endpoint to an address on the transport provider */
  if (bind(nch->ncSocket, (struct sockaddr *) &(nch->ncSocketAddress),
    sizeof nch->ncSocketAddress) == -1) {
      NiErrno = NiBIND_ERROR;
      return NiFAILURE;
  }

  /* make the endpoint passive with the specified queue count */
  if (listen(nch->ncSocket, count) == -1) {
    NiErrno = NiLISTEN_ERROR;
    return NiFAILURE;
  }

  /* done */
  return NiSUCCESS;
}

/*+
 * net_accept_connection
 *
 *  Accept a connect indication from the transport provider.
 *
 *  net_accept_connection(nch)
 *    NiNetworkContext *nch;   The network context handle
 *
 *  Returns:    socket descriptor if everything went ok.
 *              -1 if something happened
-*/
/*&
 * DO until a connection is indicated
 *   CALL accept() to accept the connect indication.
 * ENDDO
 * Return the socket descriptor.
&*/

int
net_accept_connection(NiNetworkContext *nch)
{
  int n = sizeof nch->ncSocketAddress;

  if (nch == 0) {
    NiErrno = NiNOT_INITIALIZED;
    return -1;
  }

  for(;;) {
    /* accept the connect indication */
    nch->ncAcceptSocket =
      accept(nch->ncSocket, (struct sockaddr *) &nch->ncSocketAddress, &n);
  
    /* save this off */
    NiSocket = nch->ncAcceptSocket;

    /* got it */
    if (NiSocket != -1)
      break;
  }

  return nch->ncAcceptSocket;
}

/*+
 * net_spawn_server
 *
 *  Spawn a child server to handle the new connection.
 *
 *  net_spawn_server(nch, flags)
 *    NiNetworkContext *nch;   The network context handle
 *    int flags;               Currently, can be 0 or NiNOFORK
 *
 *  Returns:    NiFAILURE - it didn't work
 *              NiSUCCESS - it did
-*/
/*&
 * IF not initialized
 *   RETURN NiFAILURE
 * ENDIF
 * IF the new socket descriptor is not valid
 *   RETURN NiFAILURE
 * ENDIF
 * IF NiNOFORK flag is set
 *   Assign 0 to result.
 * ELSE
 *   Assign the call to fork() to result.
 * SWITCH on result
 * CASE 0
 *   IF the server function pointer is null
 *     Close the connection.
 *     RETURN NiFAILURE
 *   ENDIF
 *   IF NiNOFORK is not set
 *     Close the connection for the parent.
 *   ENDIF
 *   CALL the server function with the new socket connection.
 *   IF NiNOFORK is not set
 *     Exit this process.
 *   ELSE
 *     Close the new socket connection.
 *   ENDIF
 *   RETURN NiSUCCESS
 *   BREAKSWITCH
 * CASE -1
 *   RETURN NiFAILURE
 *   BREAKSWITCH
 * DEFAULT
 *   Close the new socket connection.
 *   RETURN NiSUCCESS
 *   BREAKSWITCH
 * ENDSWITCH
&*/

int
net_spawn_server(NiNetworkContext *nch, int flags)
{
  int way;

  if (nch == 0) {
    NiErrno = NiNOT_INITIALIZED;
    return NiFAILURE;
  }
  
  /* need a valid socket descriptor for the new connection */
  if (nch->ncAcceptSocket == -1) {
    NiErrno = NiNOT_INITIALIZED;
    return NiFAILURE;
  }
  
  /* if NiNOFORK then let the parent do the child's work */
  if (flags & NiNOFORK)
    way = 0;
  else
    way = fork();
  
  switch(way) {
  case -1:        /* failed fork */
    NiErrno = NiFORK_ERROR;
    return NiFAILURE;
  
  case 0:         /* child or (parent if NiNOFORK) */
    /* no callback function */
    if (nch->ncCallback == 0) {
      close(nch->ncAcceptSocket);
      NiErrno = NiNOT_INITIALIZED;
      return NiFAILURE;
    }
  
    /* if we're the child, close the listening socket */
    if ((flags & NiNOFORK) == 0)
      close(nch->ncSocket);
  
    /* call the callback with the new socket connection */
    se_function_call(nch->ncCallback, nch->ncAcceptSocket);
  
    /* if we're the child, exit quietly, else close the new connection */
    if ((flags & NiNOFORK) == 0)
      _exit(0);
    else
      close(nch->ncAcceptSocket);
  
    return NiSUCCESS;
  
  default:        /* parent, just return */
    /* close the new connection, parent only needs to listen */
    close(nch->ncAcceptSocket);
    return NiSUCCESS;
  }
}

/*+
 * net_hostname
 *
 *  Return the name of the host upon which this program is running.
 *
 *  char *
 *  net_hostname()
 *
 *  Returns:    The name of the current host
 *              or zero if not initialized.
-*/
/*&
 * IF hostPointer is zero
 *   IF NiWakeup() RETURNS NiFAILURE
 *     RETURN zero
 *   ENDIF
 * ENDIF
 * RETURN the host name
&*/

char    *
net_hostname(void)
{
  if (hostPointer == 0)
    if (NiWakeup() == NiFAILURE)
      return 0;

  return hostPointer->h_name;
}

/*+
 * net_server_main
 *
 *  Canned main program for a connection-mode server.
 *
 *  int
 *  net_server_main(programName, port, count, func, flags)
 *    char *programName;  The name of the server program
 *    int  port;          Address on the transport provider
 *    int  count;         Maximum number of child servers
 *    int  (*func)();     Server function to call upon connection
 *    int  flags;         Currently, just NiNOFORK
 *
 *  Returns:    NiFAILURE - something went wrong
 *              NiSUCCESS - ok
-*/
/*&
 * Initialize a new network context.
 * IF the initialization failed
 *   RETURN NiFAILURE
 * ENDIF
 * Bind the context as a server on the endpoint.
 * IF the bind failed
 *   RETURN NiFAILURE
 * ENDIF
 * DO while net_accept_connection() returns a socket descriptor
 *   Spawn a new child to handle the connect indication.
 *   IF the spawn failed
 *     RETURN NiFAILURE
 *   ENDIF
 * ENDDO
 * RETURN NiSUCCESS
&*/

int
net_server_main (int argc, char *argv[], int port, int count,
                 char *func, int flags)
{
  NiNetworkContext *nch;
  int n;

  NiProgramName = argv[0];
  
  /* get a new network context */
  nch = net_initialize();
  if (nch == 0)
    return NiFAILURE;
  
  /* bind this context as a server on the endpoint */
  n = net_bind_service(nch, port, count);
  if (n != NiSUCCESS)
    return NiFAILURE;
  
  /* initialize the server function */
  nch->ncCallback = func;
  
  /* keep getting connections */
  while (net_accept_connection(nch) != -1) {
    /* spawn a new child to handle the new connection */
    n = net_spawn_server(nch, flags);
    if (n != NiSUCCESS)
      return NiFAILURE;
  }
  
  /* probably won't get here */
  return NiSUCCESS;
}

/*+
 * net_server_init
 *
 *  Init module for a connection-mode server.
 *
 *  int
 *  net_server_init(programName, port, count, flags)
 *    char *programName;  The name of the server program
 *    int  port;          Address on the transport provider
 *    int  count;         Maximum number of child servers
 *    int  flags;         Currently, just NiNOFORK
 *
 *  Returns:    The socket descriptor of the connection
 *              -1 if failure
-*/
/*&
 * Initialize a new network context.
 * IF the initialization failed
 *   RETURN -1
 * ENDIF
 * Bind the context as a server on the endpoint.
 * IF the bind failed
 *   RETURN -1
 * ENDIF
 * DO while net_accept_connection() returns a socket descriptor
 *   Spawn a new child to handle the connect indication.
 *   IF the spawn failed
 *     RETURN -1
 *   ENDIF
 *   IF I'm the parent
 *     Close the new socket descriptor.
 *     CONTINUE
 *   ELSE
 *     Close the listen descriptor.
 *     RETURN the new socket descriptor.
 *   ENDIF
 * ENDDO
 * RETURN -1.
&*/

int
net_server_init (int argc, char *argv[], int port, int count, int flags)
{
  NiNetworkContext *nch;
  int way;
  int n;
  int sd;

  NiProgramName = argv[0];

  /* get a new network context */
  nch = net_initialize();
  if (nch == 0)
    return -1;
  
  /* bind this context as a server on the endpoint */
  n = net_bind_service(nch, port, count);
  if (n != NiSUCCESS) {
    net_terminate(nch);
    return -1;
  }
  
  /* keep getting connections */
  while (net_accept_connection(nch) != -1) {
    /* spawn a new child to handle the new connection      *
     * if NiNOFORK then let the parent do the child's work */
    if (flags & NiNOFORK)
      way = 0;
    else
      way = fork();
  
    switch(way) {
    case -1: /* failed fork */
      NiErrno = NiFORK_ERROR;
      net_terminate(nch);
      return -1;
  
    case 0: /* child (or parent if NiNOFORK) */
      /* close the listen handle */
      close(nch->ncSocket);
  
      /* get the new socket out of the structure */
      sd = nch->ncAcceptSocket;
  
      /* free the memory */
      free((char *) nch);
  
      /* return the accept handle */
      return sd;
  
    default: /* parent, just continue */
      close(nch->ncAcceptSocket);
      continue;
    }
  }
  
  /* accept failed */
  net_terminate(nch);
  return -1;
}

/*+
 * net_connect_to_service
 *
 *  Establish an endpoint to a connection-mode service.
 *
 *  int
 *  net_connect_to_service(nch, node, port)
 *    NiNetworkContext *nch;  The client's network context
 *    char *node;             The node which the server resides on
 *    int  port;              The ip port where the server resides
 *
 *  Returns:    The socket descriptor of the connection
 *              -1 for failure
 *
 *  Notes:      This function does not return NiSUCCESS and NiFAILURE
 *              An error indication is a return value of -1
-*/
/*&
 * Retrieve information about the target host.
 * IF it failed
 *   RETURN -1
 * ENDIF
 * Retrive a handle to the transport provider.
 * IF it failed
 *   RETURN -1
 * ENDIF
 * Establish an endpoint to the server through the transport provider.
 * IF it failed
 *   RETURN -1
 * ENDIF
 * RETURN the socket descriptor
&*/

int
net_connect_to_service (NiNetworkContext *nch, char *node, int port)
{
    struct hostent  *hp;

  /* no zero pointers allowed */
  if (nch == 0) {
    NiErrno = NiNOT_INITIALIZED;
    return -1;
  }
  
  /* get information about the host on which the service resides */
  hp = gethostbyname(node);
  if (hp == 0) {
    NiErrno = NiHOSTBYNAME_ERROR;
    return -1;
  }
  
  /* set up the address, port, and address family */
  memcpy(&nch->ncSocketAddress.sin_addr.s_addr, hp->h_addr, hp->h_length);
  nch->ncSocketAddress.sin_port = htons((unsigned short) port);
  nch->ncSocketAddress.sin_family = hp->h_addrtype;
  
  /* retrieve a handle to the transport provider */
  nch->ncSocket = socket(AF_INET, SOCK_STREAM, PF_UNSPEC);
  if (nch->ncSocket == -1) {
    NiErrno = NiSOCKET_ERROR;
    return -1;
  }
  
  /* establish an endpoint to the server through the transport provider */
  if (connect(nch->ncSocket, (struct sockaddr *) &nch->ncSocketAddress,
    sizeof nch->ncSocketAddress) == -1) {
      NiErrno = NiCONNECT_ERROR;
      return -1;
  }
  
  /* save this off */
  NiSocket = nch->ncSocket;
  
  /* done */
  return nch->ncSocket;
}

/*+
 * net_client_main
 *
 *  Canned main program for a connection-mode client.
 *
 *  int
 *  net_client_main(programName, node, port, func)
 *    char *programName;   The name of the client program
 *    char *node;          The node which the server is on
 *    int  port;           The ip port where the service resides
 *    int  (*func)();      The client function
 *
 *  Returns:    NiFAILURE - something went wrong
 *              NiSUCCESS - ok
-*/
/*&
 * CALL net_initialize() to retrieve a network context.
 * IF it failed
 *   RETURN NiFAILURE
 * ENDIF
 * Establish a connection to the server.
 * IF it failed
 *   RETURN NiFAILURE
 * ENDIF
 * CALL NiClient() with the connected context.
 * RETURN with the value from the call to NiClient()
&*/

int
net_client_main (int argc, char *argv[], char *node, int port, char *func)
{
  NiNetworkContext *nch;
  int n;

  NiProgramName = argv[0];
  
  /* new network context */
  nch = net_initialize();
  if (nch == 0)
    return NiFAILURE;
  
  /* default to this node */
  if (node == 0)
    node = hostPointer->h_name;
  
  /* establish an endpoint with the server */
  n = net_connect_to_service(nch, node, port);
  if (n < 0)
    return NiFAILURE;
  
  /* free the memory */
  free((char *) nch);
  
  /* call the client function */
  if (func)
    se_function_call(func, n);
  
  return NiSUCCESS;
}

/*+
 * net_client_init
 *
 *  Init module for a connection-mode client.
 *
 *  int
 *  net_client_init(programName, node, port)
 *    char *programName;   The name of the client program
 *    char *node;          The node which the server is on
 *    int  port;           The ip port where the service resides
 *
 *  Returns:    The socket descriptor of the new connection
 *              -1 if failure
-*/
/*&
 * CALL net_initialize() to retrieve a network context.
 * IF it failed
 *   RETURN -1
 * ENDIF
 * Establish a connection to the server.
 * IF it failed
 *   RETURN -1
 * ENDIF
 * RETURN the new socket descriptor.
&*/

int
net_client_init (int argc, char *argv[], char *node, int port)
{
  NiNetworkContext *nch;
  int n;

  NiProgramName = argv[0];
  
  /* new network context */
  nch = net_initialize();
  if (nch == 0)
    return -1;
  
  /* default to this node */
  if (node == 0)
    node = hostPointer->h_name;
  
  /* establish an endpoint with the server */
  n = net_connect_to_service(nch, node, port);
  if (n < 0) {
    net_terminate(nch);
    return -1;
  }
  
  /* free the memory */
  free((char *) nch);
  
  return n;
}

/*+
 * net_getportbyname
 *
 *  Yield the port number of a service by the name of the service as
 *  specified in the /etc/services (or equivalent) file.
 *
 *  int
 *  net_getportbyname(name)
 *    char *name;  The name of the service
 *
 *  Returns:    -1 if the service was not found as inet or udp
 *              or the port number of the service
 *  Note:       This function could possibly return the port number of
 *              a service which is established as connectionless-mode.
 *              Care should be taken to not mix this up.
-*/
/*&
 * CALL getservbyname() to see if this is a tcp (connection-mode) service
 * IF it returned zero
 *   CALL getservbyname() to see if this is a udp (connectionless-mode) service
 *   IF if returned zero
 *     RETURN -1
 *   ENDIF
 * ENDIF
 * RETURN the port number
&*/

int
net_getportbyname(char *name)
{
  struct servent  *sp;

  /* connection mode */
  sp = getservbyname(name, "tcp");
  if (sp == 0) {
    /* connectionless-mode */
    sp = getservbyname(name, "udp");
    if (sp == 0) {
      NiErrno = NiSERVBYNAME_ERROR;
      return -1;
    }
  }

  return ntohs(sp->s_port);
}

/*+
 * net_error
 *
 *  NiLib version of perror(). errno equivalent is NiErrno.
 *
 *  void
 *  net_error(preamble)
 *    char *preamble;  The message to speak before specifying the error.
 *
 *  Returns:    None
-*/
/*&
 * IF NiErrno is not less than zero
 *   RETURN
 * ENDIF
 * Print out the NiLib message preceded by the preamble.
 * CALL perror() to dump out what errno says
&*/

void
net_error(char *preamble)
{
  static char *errorTable[] = {
    0,
    "system not initialized",    /* NiNOT_INITIALIZED    */
    "socket error",              /* NiSOCKET_ERROR       */
    "bind error",                /* NiBIND_ERROR         */
    "listen error",              /* NiLISTEN_ERROR       */
    "accept error",              /* NiACCEPT_ERROR       */
    "gethostname error",         /* NiHOSTNAME_ERROR     */
    "gethostbyname error",       /* NiHOSTBYNAME_ERROR   */
    "fork error",                /* NiFORK_ERROR         */
    "connect error",             /* NiCONNECT_ERROR      */
    "getservbyname error",       /* NiSERVBYNAME_ERROR   */
    "fcntl error"                /* NiFCNTL_ERROR        */
  };

  if (NiErrno >= 0) {
    if (errno == 0) {
      fprintf(stderr, "%s: No error detected\n", preamble);
      return;
    } else {
      perror(preamble);
      return;
    }
  } else {
    fprintf(stderr, "%s: %s: ", preamble, errorTable[-NiErrno]);
    perror("");
  }
}

/*+
 * net_terminate
 *
 *  Release a network context.
 *
 *  void
 *  net_terminate(nch)
 *    NiNetworkContext *nch;   The network context to release.
 *
 *  Returns:    None
-*/
/*&
 * IF the context handle is null
 *   RETURN
 * ENDIF
 * CALL close() to terminate the parent transport provider services.
 * CALL close() to terminate the child transport provider services.
 * CALL free() to return dynamic memory to system.
&*/

void
net_terminate(NiNetworkContext *nch)
{
  extern int errno;
  int n;

  if (nch == 0)
    return;
  n = errno;
  close(nch->ncSocket);
  close(nch->ncAcceptSocket);
  free((char *) nch);
  errno = n;
}

/*+
 * net_peer_host
 *
 *  Retrieve the name of host where the other side of the endpoint resides.
 *
 *  char *
 *  net_peer_host(sd)
 *    int sd;  The endpoint whose peer is to be determined
 *
 *  Returns:    incorrect value returned from net_read_nbytes
 *           or 0 if the peer host name could not be determined
-*/
/*&
 * CALL getpeername() to get the address of the peer
 * IF 0 is returned
 *   RETURN 0
 * ENDIF
 * CALL gethostbyaddr() to retrieve host info based on the address
 * IF 0 is returned
 *   RETURN 0
 * ENDIF
 * RETURN the host name
&*/

char *
net_peer_host(int sd)
{
  struct sockaddr_in socketAddress;
  struct hostent *hostEntry;
  int n = sizeof(struct sockaddr_in);

  /* get info on peer */
  if (getpeername(sd, (struct sockaddr *) &socketAddress, &n) == -1)
    return 0;

  /* get host info based on address */
  hostEntry =
    gethostbyaddr((char *) &socketAddress.sin_addr.s_addr, 4, AF_INET);
  if (hostEntry == 0)
    return 0;

  /* this is their name */
  return hostEntry->h_name;
}

/*+
 * net_port_number
 *
 *  Determine the port number which this endpoint is bound to
 *
 *  int net_port_number(sd)
 *    int sd;  The endpoint in question
 *
 *  Returns:  -1: Can't figure it out
 *           or the port number that the endpoint is bound to
-*/
/*&
 * CALL getsockname() to get info about the endpoint
 * IF it failed
 *   RETURN -1
 * ENDIF
 * RETURN the port number
&*/


int net_port_number(int sd)
{
  int n = sizeof(struct sockaddr_in);
  int r;
  struct sockaddr_in address;

  r = getsockname(sd, (struct sockaddr *) &address, &n);
  if (r == -1)
    return -1;

  return (int) ntohs(address.sin_port);
}

/*+
 * net_writev_nbytes
 *
 *  Like net_write_nbytes, but with iovecs
 *
 *  net_writev_nbytes(sd, v, cnt)
 *    int sd;           The socket
 *    struct iovec *v;  The iovec vector
 *    int cnt;          The number of iovecs in v
 *
 *  Returns:    incorrect value returned from net_read_nbytes
 *           or total number of bytes written
-*/
/*&
 * DO for each of the iovecs
 *   IF this iovec won't fit into the static buffer
 *     CALL net_write_nbytes() to send the contents of the buffer
 *     IF the write failed
 *       RETURN the count of bytes that did get written
 *     ENDIF
 *   ENDIF
 *   IF this iovec is larger than the entire static buffer
 *     CALL net_write_nbytes() to write this iovec
 *     IF the write failed
 *       RETURN the count of bytes that did get written
 *     ENDIF
 *   ELSE
 *     CALL memcpy() and copy this iovec into the static buffer
 *   ENDIF
 * ENDDO
 * IF there's data left in the static buffer to be written
 *   CALL net_write_nbytes() to write the static buffer
 *   IF the write failed
 *     RETURN the count of bytes that did get written
 *   ENDIF
 * ENDIF
 * RETURN the total number of bytes written
&*/

int
net_writev_nbytes (int sd, struct iovec *v, int cnt)
{
  static char buf[8192];
  register int i;
  register int n;
  register int total = 0;
  int totalWritten = 0;

  for (i = 0; i < cnt; i++) {
    if ((total + v[i].iov_len) > sizeof buf) {
      n = net_write_nbytes(sd, buf, total);
      if (n != total)
        return n;
      total = 0;
      totalWritten += n;
    }

    /* IT'S HUGE! */
    if (v[i].iov_len > sizeof buf) {
      n = net_write_nbytes(sd, v[i].iov_base, v[i].iov_len);
      if (n != v[i].iov_len)
        return n;
      totalWritten += n;
    } else {
      memcpy(&buf[total], v[i].iov_base, v[i].iov_len);
      total += v[i].iov_len;
    }
  }

  if (total) {
    n = net_write_nbytes(sd, buf, total);
    if (n != total)
      return n;
    totalWritten += n;
  }

  return totalWritten;
}

/*+
 * net_ping
 *
 *  Attempt to ascertain whether a host is alive in a pretty ugly fashion.
 *
 *  net_ping(node)
 *    char *node;   The node to ping
 *
 *  Returns:   0: The host is not alive
 *             1: The host is alive
 *            -1: An error occurred
-*/
/*&
 * CALL net_initialize() to retrieve a new endpoint
 * IF it failed
 *   RETURN -1
 * ENDIF
 * CALL gethostbyname() to get info on the host in question
 * IF it failed
 *   RETURN -1
 * ENDIF
 * CALL net_getportbyname() to retrieve the port number of the service
 * IF it failed
 *   RETURN -1
 * ENDIF
 * Establish a non-blocking endpoint
 * CALL connect() to attempt a connect
 * IF -1 is returned
 *   IF errno specifies that the connect is in progress
 *     CALL select() to wait for 1 second
 *     IF select returns 0 or -1
 *       RETURN 0
 *     ELSE
 *       RETURN 1
 *     ENDIF
 *   ELSE
 *     RETURN -1
 *   ENDIF
 * ENDIF
 * RETURN 1
&*/

#define SERVICE_OF_CHOICE  "echo"

int net_ping(char *node)
{
  extern int errno;
  int n;
  int flags;
  short port;
  struct hostent *hp;
  NiNetworkContext *nch;

  /* no zero pointers allowed */
  nch = net_initialize();
  if (nch == 0) {
    NiErrno = NiNOT_INITIALIZED;
    return -1;
  }
  
  /* get information about the host on which the service resides */
  hp = gethostbyname(node);
  if (hp == 0) {
    net_terminate(nch);
    NiErrno = NiHOSTBYNAME_ERROR;
    return -1;
  }
  
  /* grrr.... lousy kludge...yech, caca */
  port = net_getportbyname(SERVICE_OF_CHOICE);
  if (port == -1) {
    net_terminate(nch);
    return -1;
  }
  
  /* set up the address, port, and address family */
  memcpy(&nch->ncSocketAddress.sin_addr.s_addr, hp->h_addr, hp->h_length);
  nch->ncSocketAddress.sin_port = htons((unsigned short) port);
  nch->ncSocketAddress.sin_family = hp->h_addrtype;

  /* retrieve a handle to the transport provider */
  nch->ncSocket = socket(AF_INET, SOCK_STREAM, PF_UNSPEC);
  if (nch->ncSocket == -1) {
    NiErrno = NiSOCKET_ERROR;
    return -1;
  }
  
  /* set no block */
  flags = fcntl(nch->ncSocket, F_GETFL, 0);
  if (flags == -1) {
    net_terminate(nch);
    NiErrno = NiFCNTL_ERROR;
    return -1;
  }
  
  if (fcntl(nch->ncSocket, F_SETFL, flags | FNDELAY) == -1) {
    net_terminate(nch);
    NiErrno = NiFCNTL_ERROR;
    return -1;
  }
  
  /* establish an endpoint to the server through the transport provider */
  n = connect(nch->ncSocket, (struct sockaddr *) &nch->ncSocketAddress,
              sizeof nch->ncSocketAddress);
  
  /* is it really not there ? */
  if (n == -1) {
    if (errno == EINPROGRESS) {
      fd_set mask;
      struct timeval tv;
      int s;
  
      FD_ZERO(&mask);
      FD_SET(nch->ncSocket, &mask);
      tv.tv_sec = 1;
      tv.tv_usec = 0;

      switch(s = select(32, FD_NULL, &mask, FD_NULL, &tv)) {
      case 0:
      case -1:
        net_terminate(nch);
        return 0;
      default:
        net_terminate(nch);
        return 1;
      }
    } else {
      net_terminate(nch);
      NiErrno = NiCONNECT_ERROR;
      return -1;
    }
  }
    
  net_terminate(nch);
  return 1;
}
