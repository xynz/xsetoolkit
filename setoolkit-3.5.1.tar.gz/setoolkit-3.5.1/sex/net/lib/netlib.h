/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#ifndef _NETLIBH_
#define _NETLIBH_

#include <sys/types.h>
#include <netinet/in.h>

/* tell the server not to fork */
#define NiNOFORK              1

/* success and failure codes */
#define NiSUCCESS             1
#define NiFAILURE             0

/* possible values of NiErrno */
#define NiNOT_INITIALIZED     -1
#define NiSOCKET_ERROR        -2
#define NiBIND_ERROR          -3
#define NiLISTEN_ERROR        -4
#define NiACCEPT_ERROR        -5
#define NiHOSTNAME_ERROR      -6
#define NiHOSTBYNAME_ERROR    -7
#define NiFORK_ERROR          -8
#define NiCONNECT_ERROR       -9
#define NiSERVBYNAME_ERROR    -10
#define NiFCNTL_ERROR         -11

/* maximum length to be written in one shot */
#define NiMAX_WRITE   4096

/* a value not provided by the include file */
#define FD_NULL       ((fd_set *) 0)

/* a network context */
typedef struct {
  int ncSocket;
  int ncAcceptSocket;
  char *ncCallback;
  struct sockaddr_in ncSocketAddress;
} NiNetworkContext;

extern NiNetworkContext *net_initialize(void);
extern int   net_bind_service(NiNetworkContext *, int, int);
extern int   net_accept_connection(NiNetworkContext *);
extern int   net_spawn_server(NiNetworkContext *, int);
extern char *net_hostname(void);
extern int   NiServerMain (int, char *[], int, int, char *, int);
extern int   net_server_init (int, char *[], int, int, int);
extern int   net_connect_to_service (NiNetworkContext *, char *, int);
extern int   net_client_main (int, char *[], char *, int, char *);
extern int   net_client_init (int, char *[], char *, int);
extern int   net_getportbyname(char *);
extern void  net_error(char *);
extern void  net_terminate(NiNetworkContext *);
extern char *net_peer_host(int);
extern int   net_port_number(int);
extern int   net_read_nbytes(int, char *, int);
extern int   net_write_nbytes(int, char *, int);
extern int   net_writev_nbytes (int, struct iovec *, int);

extern char *NiProgramName;
extern int   NiSocket;
extern int   NiErrno;

#endif
