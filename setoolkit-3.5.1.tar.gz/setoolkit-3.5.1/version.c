/* The SE Toolkit
 * Copyright (c) 1993-2007 Richard Pettit
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

#include "config.h"
#define SE_VERSION  "@(#)se - Version " VERSION
double                Se_version = DBL_VERSION;

#include <stdio.h>
#include <string.h>
#include <sys/types.h>
#include <sys/systeminfo.h>

void
version(void)
{
  char v[128];
  char processor[128];
  extern double Se_version;

#ifdef _LP64
#ifdef SI_ARCHITECTURE_64
  sysinfo(SI_ARCHITECTURE_64, processor, sizeof processor);
#else
  strcpy(processor, "sparcv9");
#endif
#else
  sysinfo(SI_ARCHITECTURE, processor, sizeof processor);
#endif
  snprintf(v, sizeof v, "%s (%s) for %s", SE_VERSION, NOW, processor);
  puts(&v[4]);
}
